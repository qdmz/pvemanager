import axios from 'axios';
import type { VirtualMachine } from '../types';

const api = axios.create({
  baseURL: '/api/vms',
  headers: {
    'Content-Type': 'application/json',
  },
});

// 添加请求拦截器，自动添加token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const vmService = {
  // 获取所有虚拟机
  async getVMs(params?: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    node?: string;
  }): Promise<{
    vms: VirtualMachine[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      pages: number;
    };
  }> {
    const response = await api.get('/', { params });
    return response.data;
  },

  // 获取单个虚拟机
  async getVM(id: string): Promise<{ vm: VirtualMachine }> {
    const response = await api.get(`/${id}`);
    return response.data;
  },

  // 创建虚拟机
  async createVM(data: {
    name: string;
    node: string;
    cpus: number;
    memory: number;
    disk: number;
    storage: string;
    network?: {
      model?: string;
      bridge?: string;
      firewall?: boolean;
      ip?: string;
    };
    os: {
      type: string;
      iso?: string;
    };
    cloudInit?: Record<string, unknown>;
  }): Promise<{ message: string; vm: VirtualMachine }> {
    const response = await api.post('/', data);
    return response.data;
  },

  // 更新虚拟机
  async updateVM(id: string, data: {
    name?: string;
    cpus?: number;
    memory?: number;
    description?: string;
  }): Promise<{ message: string; vm: VirtualMachine }> {
    const response = await api.put(`/${id}`, data);
    return response.data;
  },

  // 删除虚拟机
  async deleteVM(id: string): Promise<{ message: string }> {
    const response = await api.delete(`/${id}`);
    return response.data;
  },

  // 启动虚拟机
  async startVM(id: string): Promise<{ message: string }> {
    const response = await api.post(`/${id}/start`);
    return response.data;
  },

  // 停止虚拟机
  async stopVM(id: string): Promise<{ message: string }> {
    const response = await api.post(`/${id}/stop`);
    return response.data;
  },

  // 重启虚拟机
  async restartVM(id: string): Promise<{ message: string }> {
    const response = await api.post(`/${id}/restart`);
    return response.data;
  },

  // 暂停虚拟机
  async pauseVM(id: string): Promise<{ message: string }> {
    const response = await api.post(`/${id}/pause`);
    return response.data;
  },

  // 恢复虚拟机
  async resumeVM(id: string): Promise<{ message: string }> {
    const response = await api.post(`/${id}/resume`);
    return response.data;
  },

  // 获取虚拟机快照
  async getVMSnapshots(id: string): Promise<{ snapshots: any[] }> {
    const response = await api.get(`/${id}/snapshots`);
    return response.data;
  },

  // 创建虚拟机快照
  async createVMSnapshot(
    id: string,
    data: { name: string; description?: string }
  ): Promise<{ message: string; snapshot: any }> {
    const response = await api.post(`/${id}/snapshots`, data);
    return response.data;
  },

  // 获取VNC连接信息
  async getVNCTicket(id: string): Promise<{ vncInfo: any }> {
    const response = await api.get(`/${id}/vnc`);
    return response.data;
  },

  // 删除虚拟机快照
  async deleteVMSnapshot(id: string, snapname: string): Promise<{ message: string }> {
    const response = await api.delete(`/${id}/snapshots/${snapname}`);
    return response.data;
  },

  // 恢复虚拟机快照
  async restoreVMSnapshot(id: string, snapname: string): Promise<{ message: string }> {
    const response = await api.post(`/${id}/snapshots/${snapname}/restore`);
    return response.data;
  },

  // 克隆虚拟机
  async cloneVM(id: string, data: { name?: string; targetNode?: string }): Promise<{ message: string; vm: VirtualMachine }> {
    const response = await api.post(`/${id}/clone`, data);
    return response.data;
  },

  // 迁移虚拟机
  async migrateVM(id: string, data: { 
    targetNode: string; 
    withLocalDisks?: boolean; 
    online?: boolean;
    targetStorage?: string;
  }): Promise<{ message: string; vm: VirtualMachine }> {
    const response = await api.post(`/${id}/migrate`, data);
    return response.data;
  },

  // 暂停虚拟机
  async suspendVM(id: string): Promise<{ message: string }> {
    const response = await api.post(`/${id}/suspend`);
    return response.data;
  },

  // 恢复虚拟机
  async resumeVM(id: string): Promise<{ message: string }> {
    const response = await api.post(`/${id}/resume`);
    return response.data;
  },
};