import { useState, useEffect } from 'react';
import { vmService } from '../services/vmService';

interface BackupManagerProps {
  vmId: string;
  vmName: string;
  isOpen: boolean;
  onClose: () => void;
}

interface Backup {
  id: string;
  name: string;
  filename: string;
  size: number;
  node: string;
  storage: string;
  type: string;
  status: string;
  createdAt: string;
}

const BackupManager = ({ vmId, vmName, isOpen, onClose }: BackupManagerProps) => {
  const [backups, setBackups] = useState<Backup[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // 加载备份列表
  useEffect(() => {
    if (isOpen) {
      loadBackups();
    }
  }, [isOpen, vmId]);

  const loadBackups = async () => {
    try {
      setLoading(true);
      // 从 VM 详情中获取备份列表
      const response = await vmService.getVM(vmId);
      setBackups(response.vm.backups || []);
      setError(null);
    } catch (err) {
      setError('Failed to load backups');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // 格式化文件大小
  const formatSize = (bytes: number) => {
    if (bytes >= 1073741824) return `${(bytes / 1073741824).toFixed(2)} GB`;
    if (bytes >= 1048576) return `${(bytes / 1048576).toFixed(2)} MB`;
    if (bytes >= 1024) return `${(bytes / 1024).toFixed(2)} KB`;
    return `${bytes} B`;
  };

  // 格式化时间
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // 获取状态文本
  const getStatusText = (status: string) => {
    switch (status) {
      case 'COMPLETED': return '已完成';
      case 'IN_PROGRESS': return '进行中';
      case 'FAILED': return '失败';
      case 'PENDING': return '等待中';
      default: return status;
    }
  };

  // 获取状态样式
  const getStatusClass = (status: string) => {
    switch (status) {
      case 'COMPLETED': return 'completed';
      case 'IN_PROGRESS': return 'in-progress';
      case 'FAILED': return 'failed';
      case 'PENDING': return 'pending';
      default: return '';
    }
  };

  if (!isOpen) return null;

  return (
    <div className="dialog-overlay">
      <div className="dialog-content backup-manager">
        <div className="dialog-header">
          <h2>备份管理 - {vmName}</h2>
          <button 
            className="close-button"
            onClick={onClose}
          >
            ×
          </button>
        </div>

        <div className="dialog-body">
          {/* 错误提示 */}
          {error && (
            <div className="error-message">
              {error}
            </div>
          )}

          {/* 操作按钮 */}
          <div className="backup-actions">
            <button 
              className="btn btn-secondary"
              onClick={loadBackups}
              disabled={loading}
            >
              刷新
            </button>
          </div>

          {/* 备份列表 */}
          <div className="backup-list">
            {loading ? (
              <div className="loading">加载中...</div>
            ) : backups.length === 0 ? (
              <div className="empty-state">
                没有备份
              </div>
            ) : (
              <table className="backup-table">
                <thead>
                  <tr>
                    <th>名称</th>
                    <th>文件名</th>
                    <th>大小</th>
                    <th>节点</th>
                    <th>存储</th>
                    <th>类型</th>
                    <th>状态</th>
                    <th>创建时间</th>
                  </tr>
                </thead>
                <tbody>
                  {backups.map((backup) => (
                    <tr key={backup.id} className="backup-row">
                      <td className="backup-name">
                        <span className="backup-icon">💾</span>
                        {backup.name}
                      </td>
                      <td className="backup-filename">
                        {backup.filename}
                      </td>
                      <td className="backup-size">
                        {formatSize(backup.size)}
                      </td>
                      <td className="backup-node">
                        {backup.node}
                      </td>
                      <td className="backup-storage">
                        {backup.storage}
                      </td>
                      <td className="backup-type">
                        {backup.type}
                      </td>
                      <td className="backup-status">
                        <span className={`status-badge ${getStatusClass(backup.status)}`}>
                          {getStatusText(backup.status)}
                        </span>
                      </td>
                      <td className="backup-time">
                        {formatTime(backup.createdAt)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* 备份说明 */}
          <div className="backup-info">
            <h3>备份说明</h3>
            <ul>
              <li>备份由 PVE 自动创建和管理</li>
              <li>备份文件存储在指定的存储位置</li>
              <li>可以通过 PVE 管理界面恢复备份</li>
              <li>建议定期创建快照作为额外的保护</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BackupManager;
