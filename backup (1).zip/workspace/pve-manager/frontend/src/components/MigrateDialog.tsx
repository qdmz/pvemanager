import { useState } from 'react';
import { vmService } from '../services/vmService';

interface MigrateDialogProps {
  vmId: string;
  vmName: string;
  currentNode: string;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const MigrateDialog = ({ vmId, vmName, currentNode, isOpen, onClose, onSuccess }: MigrateDialogProps) => {
  const [targetNode, setTargetNode] = useState('');
  const [withLocalDisks, setWithLocalDisks] = useState(false);
  const [migrationType, setMigrationType] = useState<'online' | 'offline'>('offline');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // 模拟可用节点列表（实际应从后端获取）
  const availableNodes = ['pve', 'pve2', 'pve3'].filter(node => node !== currentNode);

  const handleMigrate = async () => {
    if (!targetNode) {
      setError('请选择目标节点');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      await vmService.migrateVM(vmId, {
        targetNode,
        withLocalDisks,
        online: migrationType === 'online'
      });

      onSuccess();
      onClose();
    } catch (err) {
      setError('迁移失败，请重试');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="dialog-overlay">
      <div className="dialog-content migrate-dialog">
        <div className="dialog-header">
          <h2>迁移虚拟机 - {vmName}</h2>
          <button 
            className="close-button"
            onClick={onClose}
          >
            ×
          </button>
        </div>

        <div className="dialog-body">
          {/* 错误提示 */}
          {error && (
            <div className="error-message">
              {error}
            </div>
          )}

          {/* 当前节点信息 */}
          <div className="current-node-info">
            <label>当前节点：</label>
            <span className="node-badge">{currentNode}</span>
          </div>

          {/* 目标节点选择 */}
          <div className="form-group">
            <label htmlFor="targetNode">目标节点 *</label>
            <select
              id="targetNode"
              value={targetNode}
              onChange={(e) => setTargetNode(e.target.value)}
              disabled={loading}
            >
              <option value="">请选择目标节点</option>
              {availableNodes.map((node) => (
                <option key={node} value={node}>
                  {node}
                </option>
              ))}
            </select>
          </div>

          {/* 迁移类型 */}
          <div className="form-group">
            <label>迁移类型</label>
            <div className="radio-group">
              <label className="radio-label">
                <input
                  type="radio"
                  value="offline"
                  checked={migrationType === 'offline'}
                  onChange={(e) => setMigrationType(e.target.value as 'offline')}
                  disabled={loading}
                />
                <span>
                  <strong>离线迁移</strong>
                  <small>虚拟机将停止，迁移完成后自动启动</small>
                </span>
              </label>
              <label className="radio-label">
                <input
                  type="radio"
                  value="online"
                  checked={migrationType === 'online'}
                  onChange={(e) => setMigrationType(e.target.value as 'online')}
                  disabled={loading}
                />
                <span>
                  <strong>在线迁移</strong>
                  <small>虚拟机保持运行状态（需要共享存储）</small>
                </span>
              </label>
            </div>
          </div>

          {/* 迁移选项 */}
          <div className="form-group">
            <label>迁移选项</label>
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={withLocalDisks}
                onChange={(e) => setWithLocalDisks(e.target.checked)}
                disabled={loading}
              />
              <span>
                迁移本地磁盘
                <small>将虚拟机的本地磁盘也迁移到目标节点（需要更多时间）</small>
              </span>
            </label>
          </div>

          {/* 迁移说明 */}
          <div className="migration-info">
            <h3>迁移说明</h3>
            <ul>
              <li>离线迁移：虚拟机将停止，迁移完成后自动启动</li>
              <li>在线迁移：虚拟机保持运行状态，需要共享存储支持</li>
              <li>迁移本地磁盘会增加迁移时间和网络负载</li>
              <li>确保目标节点有足够的资源（CPU、内存、存储）</li>
            </ul>
          </div>
        </div>

        <div className="dialog-footer">
          <button 
            className="btn btn-secondary"
            onClick={onClose}
            disabled={loading}
          >
            取消
          </button>
          <button 
            className="btn btn-primary"
            onClick={handleMigrate}
            disabled={loading || !targetNode}
          >
            {loading ? '迁移中...' : '开始迁移'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default MigrateDialog;
