import { useState, useEffect } from 'react';
import { vmService } from '../services/vmService';

interface SnapshotManagerProps {
  vmId: string;
  vmName: string;
  isOpen: boolean;
  onClose: () => void;
}

interface Snapshot {
  name: string;
  snaptime: number;
  description?: string;
}

const SnapshotManager = ({ vmId, vmName, isOpen, onClose }: SnapshotManagerProps) => {
  const [snapshots, setSnapshots] = useState<Snapshot[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // 创建快照表单
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [snapshotFormData, setSnapshotFormData] = useState({
    name: '',
    description: ''
  });

  // 加载快照列表
  useEffect(() => {
    if (isOpen) {
      loadSnapshots();
    }
  }, [isOpen, vmId]);

  const loadSnapshots = async () => {
    try {
      setLoading(true);
      const response = await vmService.getVMSnapshots(vmId);
      setSnapshots(response.snapshots || []);
      setError(null);
    } catch (err) {
      setError('Failed to load snapshots');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // 创建快照
  const handleCreateSnapshot = async () => {
    if (!snapshotFormData.name.trim()) {
      setError('Snapshot name is required');
      return;
    }

    try {
      setLoading(true);
      await vmService.createVMSnapshot(vmId, snapshotFormData);
      await loadSnapshots();
      setSnapshotFormData({ name: '', description: '' });
      setIsCreateDialogOpen(false);
      setError(null);
    } catch (err) {
      setError('Failed to create snapshot');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // 删除快照
  const handleDeleteSnapshot = async (snapname: string) => {
    if (!window.confirm(`确定要删除快照 "${snapname}" 吗？`)) {
      return;
    }

    try {
      setLoading(true);
      await vmService.deleteVMSnapshot(vmId, snapname);
      await loadSnapshots();
      setError(null);
    } catch (err) {
      setError('Failed to delete snapshot');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // 恢复快照
  const handleRestoreSnapshot = async (snapname: string) => {
    if (!window.confirm(`确定要恢复到快照 "${snapname}" 吗？虚拟机将被重启。`)) {
      return;
    }

    try {
      setLoading(true);
      await vmService.restoreVMSnapshot(vmId, snapname);
      setError(null);
      alert(`快照 "${snapname}" 恢复成功`);
    } catch (err) {
      setError('Failed to restore snapshot');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // 格式化时间
  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp * 1000);
    return date.toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!isOpen) return null;

  return (
    <div className="dialog-overlay">
      <div className="dialog-content snapshot-manager">
        <div className="dialog-header">
          <h2>快照管理 - {vmName}</h2>
          <button 
            className="close-button"
            onClick={onClose}
          >
            ×
          </button>
        </div>

        <div className="dialog-body">
          {/* 错误提示 */}
          {error && (
            <div className="error-message">
              {error}
            </div>
          )}

          {/* 操作按钮 */}
          <div className="snapshot-actions">
            <button 
              className="btn btn-primary"
              onClick={() => setIsCreateDialogOpen(true)}
            >
              创建快照
            </button>
            <button 
              className="btn btn-secondary"
              onClick={loadSnapshots}
              disabled={loading}
            >
              刷新
            </button>
          </div>

          {/* 快照列表 */}
          <div className="snapshot-list">
            {loading ? (
              <div className="loading">加载中...</div>
            ) : snapshots.length === 0 ? (
              <div className="empty-state">
                没有快照
              </div>
            ) : (
              <table className="snapshot-table">
                <thead>
                  <tr>
                    <th>名称</th>
                    <th>创建时间</th>
                    <th>描述</th>
                    <th>操作</th>
                  </tr>
                </thead>
                <tbody>
                  {snapshots.map((snapshot) => (
                    <tr key={snapshot.name} className="snapshot-row">
                      <td className="snapshot-name">
                        <span className="snapshot-icon">📸</span>
                        {snapshot.name}
                      </td>
                      <td className="snapshot-time">
                        {formatTime(snapshot.snaptime)}
                      </td>
                      <td className="snapshot-description">
                        {snapshot.description || '-'}
                      </td>
                      <td className="snapshot-actions">
                        <div className="action-buttons">
                          <button 
                            className="action-button restore"
                            onClick={() => handleRestoreSnapshot(snapshot.name)}
                            title="恢复"
                          >
                            🔄
                          </button>
                          <button 
                            className="action-button delete"
                            onClick={() => handleDeleteSnapshot(snapshot.name)}
                            title="删除"
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* 创建快照对话框 */}
        {isCreateDialogOpen && (
          <div className="dialog-overlay nested">
            <div className="dialog-content">
              <div className="dialog-header">
                <h2>创建新快照</h2>
                <button 
                  className="close-button"
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  ×
                </button>
              </div>

              <div className="dialog-body">
                <div className="form-section">
                  <label className="form-label">快照名称</label>
                  <input
                    type="text"
                    value={snapshotFormData.name}
                    onChange={(e) => setSnapshotFormData({ ...snapshotFormData, name: e.target.value })}
                    className="form-input"
                    placeholder="输入快照名称"
                    autoFocus
                  />
                </div>

                <div className="form-section">
                  <label className="form-label">描述（可选）</label>
                  <textarea
                    value={snapshotFormData.description}
                    onChange={(e) => setSnapshotFormData({ ...snapshotFormData, description: e.target.value })}
                    className="form-textarea"
                    placeholder="输入快照描述"
                    rows={3}
                  />
                </div>
              </div>

              <div className="dialog-footer">
                <button 
                  className="btn btn-secondary"
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  取消
                </button>
                <button 
                  className="btn btn-primary"
                  onClick={handleCreateSnapshot}
                  disabled={loading}
                >
                  {loading ? '创建中...' : '创建快照'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SnapshotManager;
