import { useState, useEffect } from 'react';
import { vmService } from '../services/vmService';
import type { VirtualMachine } from '../types';
import SnapshotManager from '../components/SnapshotManager';
import BackupManager from '../components/BackupManager';
import MigrateDialog from '../components/MigrateDialog';

const VMPage = () => {
  const [vms, setVms] = useState<VirtualMachine[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // 搜索和筛选
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [nodeFilter, setNodeFilter] = useState('all');
  
  // 创建虚拟机对话框
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [vmFormData, setVmFormData] = useState({
    name: '',
    node: 'pve',
    cpus: 2,
    memory: 4096,
    disk: 50,
    storage: 'local-lvm'
  });

  // 快照管理器
  const [isSnapshotManagerOpen, setIsSnapshotManagerOpen] = useState(false);
  const [selectedVM, setSelectedVM] = useState<{ id: string; name: string } | null>(null);

  // 备份管理器
  const [isBackupManagerOpen, setIsBackupManagerOpen] = useState(false);
  const [backupVM, setBackupVM] = useState<{ id: string; name: string } | null>(null);

  // 迁移对话框
  const [isMigrateDialogOpen, setIsMigrateDialogOpen] = useState(false);
  const [migrateVM, setMigrateVM] = useState<{ id: string; name: string; node: string } | null>(null);
  
  // 模拟节点数据
  const nodes = [
    { id: '1', name: 'pve', status: 'online' },
    { id: '2', name: 'pve2', status: 'online' },
    { id: '3', name: 'pve3', status: 'offline' }
  ];
  
  // 加载虚拟机列表
  useEffect(() => {
    const fetchVMs = async () => {
      try {
        setLoading(true);
        const response = await vmService.getVMs();
        setVms(response.vms);
        setError(null);
      } catch (err) {
        setError('Failed to fetch virtual machines');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchVMs();
  }, []);
  
  // 筛选虚拟机
  const filteredVMs = vms.filter(vm => {
    const matchesSearch = vm.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (vm.ip && vm.ip.includes(searchTerm));
    const matchesStatus = statusFilter === 'all' || vm.status === statusFilter;
    const matchesNode = nodeFilter === 'all' || vm.node === nodeFilter;
    return matchesSearch && matchesStatus && matchesNode;
  });
  
  // 格式化字节数
  const formatBytes = (bytes: number) => {
    if (bytes >= 1073741824) return `${(bytes / 1073741824).toFixed(1)} GB`;
    if (bytes >= 1048576) return `${(bytes / 1048576).toFixed(1)} MB`;
    return `${bytes} KB`;
  };
  
  // 获取状态文本
  const getStatusText = (status: string) => {
    switch (status) {
      case 'RUNNING': return '运行中';
      case 'STOPPED': return '已停止';
      case 'PAUSED': return '已暂停';
      case 'SUSPENDED': return '已挂起';
      default: return '未知';
    }
  };
  
  // 执行虚拟机操作
  const performVMAction = async (id: string, action: string) => {
    try {
      switch (action) {
        case 'start':
          await vmService.startVM(id);
          break;
        case 'stop':
          await vmService.stopVM(id);
          break;
        case 'restart':
          await vmService.restartVM(id);
          break;
        case 'delete':
          if (window.confirm('确定要删除此虚拟机吗？')) {
            await vmService.deleteVM(id);
            // 从列表中移除
            setVms(vms.filter(vm => vm.id !== id));
          }
          return;
        default:
          break;
      }
      
      // 刷新虚拟机列表
      const response = await vmService.getVMs();
      setVms(response.vms);
    } catch (err) {
      setError(`Failed to ${action} VM`);
      console.error(err);
    }
  };
  
  // 创建虚拟机
  const handleCreateVM = async () => {
    try {
      setLoading(true);
      await vmService.createVM({
        ...vmFormData,
        os: { type: 'linux' },
        network: {}
      });
      
      // 刷新虚拟机列表
      const response = await vmService.getVMs();
      setVms(response.vms);
      
      // 重置表单
      setVmFormData({
        name: '',
        node: 'pve',
        cpus: 2,
        memory: 4096,
        disk: 50,
        storage: 'local-lvm'
      });
      
      setIsCreateDialogOpen(false);
      setError(null);
    } catch (err) {
      setError('Failed to create VM');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="vm-page">
      {/* 页面标题 */}
      <div className="page-header">
        <div>
          <h1 className="page-title">虚拟机管理</h1>
          <p className="page-subtitle">管理所有虚拟机实例</p>
        </div>
        <button 
          className="btn btn-primary"
          onClick={() => setIsCreateDialogOpen(true)}
        >
          创建虚拟机
        </button>
      </div>
      
      {/* 错误提示 */}
      {error && (
        <div className="error-message">
          {error}
        </div>
      )}
      
      {/* 搜索和筛选 */}
      <div className="search-filter-section">
        <div className="search-box">
          <input
            type="text"
            placeholder="搜索虚拟机名称、IP或所有者..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
        
        <div className="filter-section">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">所有状态</option>
            <option value="running">运行中</option>
            <option value="stopped">已停止</option>
            <option value="paused">已暂停</option>
            <option value="suspended">已挂起</option>
          </select>
          
          <select
            value={nodeFilter}
            onChange={(e) => setNodeFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">所有节点</option>
            {nodes.map(node => (
              <option 
                key={node.id} 
                value={node.name}
                disabled={node.status !== 'online'}
              >
                {node.name} {node.status !== 'online' && '(离线)'}
              </option>
            ))}
          </select>
        </div>
      </div>
      
      {/* 虚拟机列表 */}
      <div className="vm-list-section">
        {loading ? (
          <div className="loading">加载中...</div>
        ) : filteredVMs.length === 0 ? (
          <div className="empty-state">
            没有找到匹配的虚拟机
          </div>
        ) : (
          <div className="vm-table-container">
            <table className="vm-table">
              <thead>
                <tr>
                  <th>虚拟机</th>
                  <th>状态</th>
                  <th>节点</th>
                  <th>所有者</th>
                  <th>资源配置</th>
                  <th>IP地址</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredVMs.map((vm) => (
                  <tr key={vm.id} className="vm-row">
                    <td className="vm-name">
                      <div className="vm-name-info">
                        <span className="vm-icon">🖥️</span>
                        <div>
                          <div className="vm-display-name">{vm.name}</div>
                          <div className="vm-vmid">VMID: {vm.vmid}</div>
                        </div>
                      </div>
                    </td>
                    
                    <td className="vm-status">
                      <div className="status-indicator">
                        <div className={`status-dot ${vm.status}`}></div>
                        <span className="status-text">{getStatusText(vm.status)}</span>
                      </div>
                    </td>
                    
                    <td className="vm-node">
                      <div className="node-info">
                        <span className="node-icon">🏢</span>
                        <span>{vm.node}</span>
                      </div>
                    </td>
                    
                    <td className="vm-owner">
                      <span className="owner-badge">
                        未分配
                      </span>
                    </td>
                    
                    <td className="vm-resources">
                      <div className="resource-item">
                        <span className="resource-label">CPU:</span>
                        <span className="resource-value">{vm.cpus}核</span>
                      </div>
                      <div className="resource-item">
                        <span className="resource-label">内存:</span>
                        <span className="resource-value">{formatBytes(vm.memory * 1024 * 1024)}</span>
                      </div>
                      <div className="resource-item">
                        <span className="resource-label">磁盘:</span>
                        <span className="resource-value">{formatBytes(vm.disk * 1024 * 1024 * 1024)}</span>
                      </div>
                    </td>
                    
                    <td className="vm-ip">
                      {vm.ip || '-'}
                    </td>
                    
                    <td className="vm-actions">
                      <div className="action-buttons">
                        {vm.status !== 'RUNNING' && (
                          <button 
                            className="action-button start"
                            onClick={() => performVMAction(vm.id, 'start')}
                            title="启动"
                          >
                            ▶️
                          </button>
                        )}
                        
                        {vm.status === 'RUNNING' && (
                          <>
                            <button 
                              className="action-button stop"
                              onClick={() => performVMAction(vm.id, 'stop')}
                              title="停止"
                            >
                              ⏹️
                            </button>
                            <button 
                              className="action-button restart"
                              onClick={() => performVMAction(vm.id, 'restart')}
                              title="重启"
                            >
                              🔄
                            </button>
                          </>
                        )}
                        
                        <button 
                          className="action-button snapshot"
                          onClick={() => {
                            setSelectedVM({ id: vm.id, name: vm.name });
                            setIsSnapshotManagerOpen(true);
                          }}
                          title="快照管理"
                        >
                          📸
                        </button>
                        
                        <button 
                          className="action-button backup"
                          onClick={() => {
                            setBackupVM({ id: vm.id, name: vm.name });
                            setIsBackupManagerOpen(true);
                          }}
                          title="备份管理"
                        >
                          💾
                        </button>
                        
                        <button 
                          className="action-button migrate"
                          onClick={() => {
                            setMigrateVM({ id: vm.id, name: vm.name, node: vm.node });
                            setIsMigrateDialogOpen(true);
                          }}
                          title="迁移虚拟机"
                        >
                          🚀
                        </button>
                        
                        <button 
                          className="action-button delete"
                          onClick={() => performVMAction(vm.id, 'delete')}
                          title="删除"
                        >
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      
      {/* 创建虚拟机对话框 */}
      {isCreateDialogOpen && (
        <div className="dialog-overlay">
          <div className="dialog-content">
            <div className="dialog-header">
              <h2>创建新虚拟机</h2>
              <button 
                className="close-button"
                onClick={() => setIsCreateDialogOpen(false)}
              >
                ×
              </button>
            </div>
            
            <div className="dialog-body">
              <div className="form-section">
                <label className="form-label">虚拟机名称</label>
                <input
                  type="text"
                  value={vmFormData.name}
                  onChange={(e) => setVmFormData({ ...vmFormData, name: e.target.value })}
                  className="form-input"
                  placeholder="输入虚拟机名称"
                />
              </div>
              
              <div className="form-section">
                <label className="form-label">节点</label>
                <select
                  value={vmFormData.node}
                  onChange={(e) => setVmFormData({ ...vmFormData, node: e.target.value })}
                  className="form-select"
                >
                  {nodes.map(node => (
                    <option 
                      key={node.id} 
                      value={node.name}
                      disabled={node.status !== 'online'}
                    >
                      {node.name} {node.status !== 'online' && '(离线)'}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="form-row">
                <div className="form-section half">
                  <label className="form-label">CPU 核心数</label>
                  <input
                    type="number"
                    value={vmFormData.cpus}
                    onChange={(e) => setVmFormData({ ...vmFormData, cpus: parseInt(e.target.value) || 1 })}
                    className="form-input"
                    min="1"
                    max="64"
                  />
                </div>
                
                <div className="form-section half">
                  <label className="form-label">内存 (MB)</label>
                  <input
                    type="number"
                    value={vmFormData.memory}
                    onChange={(e) => setVmFormData({ ...vmFormData, memory: parseInt(e.target.value) || 512 })}
                    className="form-input"
                    min="512"
                    step="512"
                  />
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-section half">
                  <label className="form-label">磁盘 (GB)</label>
                  <input
                    type="number"
                    value={vmFormData.disk}
                    onChange={(e) => setVmFormData({ ...vmFormData, disk: parseInt(e.target.value) || 10 })}
                    className="form-input"
                    min="10"
                    step="10"
                  />
                </div>
                
                <div className="form-section half">
                  <label className="form-label">存储</label>
                  <select
                    value={vmFormData.storage}
                    onChange={(e) => setVmFormData({ ...vmFormData, storage: e.target.value })}
                    className="form-select"
                  >
                    <option value="local-lvm">local-lvm</option>
                    <option value="local">local</option>
                  </select>
                </div>
              </div>
            </div>
            
            <div className="dialog-footer">
              <button 
            className="btn btn-secondary"
            onClick={() => setIsCreateDialogOpen(false)}
          >
            取消
          </button>
          <button 
            className="btn btn-primary"
            onClick={handleCreateVM}
            disabled={loading}
          >
            {loading ? '创建中...' : '创建虚拟机'}
          </button>
            </div>
          </div>
        </div>
      )}

      {/* 快照管理器 */}
      {selectedVM && (
        <SnapshotManager
          vmId={selectedVM.id}
          vmName={selectedVM.name}
          isOpen={isSnapshotManagerOpen}
          onClose={() => {
            setIsSnapshotManagerOpen(false);
            setSelectedVM(null);
          }}
        />
      )}

      {/* 备份管理器 */}
      {backupVM && (
        <BackupManager
          vmId={backupVM.id}
          vmName={backupVM.name}
          isOpen={isBackupManagerOpen}
          onClose={() => {
            setIsBackupManagerOpen(false);
            setBackupVM(null);
          }}
        />
      )}

      {/* 迁移对话框 */}
      {migrateVM && (
        <MigrateDialog
          vmId={migrateVM.id}
          vmName={migrateVM.name}
          currentNode={migrateVM.node}
          isOpen={isMigrateDialogOpen}
          onClose={() => {
            setIsMigrateDialogOpen(false);
            setMigrateVM(null);
          }}
          onSuccess={() => {
            loadVMs();
          }}
        />
      )}
    </div>
  );
};

export default VMPage;