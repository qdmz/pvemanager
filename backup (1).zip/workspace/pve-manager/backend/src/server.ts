import dotenv from 'dotenv';
dotenv.config();

import { createServer } from 'http';
import { Server } from 'socket.io';
import app from './app';
import { connectDatabase } from './utils/database';
import { createAdminUser } from './scripts/createAdmin';
import { handleVNCConnect, handleSSHConnect, startVMMonitoring } from './utils/websocketHandlers';
import { PVEClient } from './utils/pveClient';

const PORT = process.env.PORT || 5000;

// Create HTTP server for Express
const httpServer = createServer(app);

// Create Socket.IO server for WebSocket connections
const io = new Server(httpServer, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true
  },
  path: '/socket.io'
});

// WebSocket connection handling
io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`);

  // Join VM monitoring room
  socket.on('join-vm', (vmId: string) => {
    socket.join(`vm:${vmId}`);
    console.log(`Socket ${socket.id} joined VM ${vmId}`);
    
    // Start VM monitoring
    try {
      const pveClient = new PVEClient(
        process.env.PVE_HOST || '',
        process.env.PVE_USER || '',
        process.env.PVE_PASSWORD || ''
      );
      startVMMonitoring(socket, vmId, pveClient, 5000);
    } catch (error) {
      console.error('Failed to start VM monitoring:', error);
    }
  });

  // Leave VM monitoring room
  socket.on('leave-vm', (vmId: string) => {
    socket.leave(`vm:${vmId}`);
    console.log(`Socket ${socket.id} left VM ${vmId}`);
  });

  // Handle VNC connection
  socket.on('vnc-connect', async (data: { vmId: string, node: string, vmid: number }) => {
    await handleVNCConnect(socket, data);
  });

  // Handle SSH connection
  socket.on('ssh-connect', async (data: { vmId: string, ip: string, username: string, password?: string }) => {
    await handleSSHConnect(socket, data);
  });

  // Handle disconnect
  socket.on('disconnect', () => {
    console.log(`Client disconnected: ${socket.id}`);
  });
});

// Export io instance for use in other modules
export { io };

async function startServer() {
  try {
    // Try to connect to database, but don't fail if it can't connect
    try {
      await connectDatabase();
      console.log('✅ Database connected');

      // Try to create admin user if database is connected
      try {
        await createAdminUser();
        console.log('✅ Admin user checked');
      } catch (error) {
        console.error('⚠️  Failed to check/create admin user:', error);
      }
    } catch (error) {
      console.error('⚠️  Failed to connect to database:', error);
    }

    // Start server regardless of database connection status
    httpServer.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`📖 API Documentation: http://localhost:${PORT}/api-docs`);
      console.log(`🔌 WebSocket server ready on /socket.io`);
    });
  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
