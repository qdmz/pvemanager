import { Socket } from 'socket.io';
import { PVEClient } from './pveClient';
import { metrics } from './metrics';

// VNC 连接处理
export async function handleVNCConnect(
  socket: Socket,
  data: { vmId: string; node: string; vmid: number }
) {
  try {
    console.log(`VNC connection request for VM ${data.vmid} on node ${data.node}`);
    
    // 更新 WebSocket 连接指标
    metrics.websocketConnections.inc();
    
    // 创建 PVE 客户端实例
    const pveClient = new PVEClient(
      process.env.PVE_HOST || '',
      process.env.PVE_USER || '',
      process.env.PVE_PASSWORD || ''
    );
    
    // 获取 VNC 代理信息
    const vncInfo = await pveClient.getVNCProxy(data.node, data.vmid, 'websockify');
    
    // 发送 VNC 连接信息给客户端
    socket.emit('vnc-connected', {
      status: 'connected',
      port: vncInfo.port,
      ticket: vncInfo.ticket,
      host: vncInfo.host || process.env.PVE_HOST,
      cert: vncInfo.cert
    });
    
    // 记录成功的 VNC 连接
    metrics.websocketMessagesTotal.inc({ direction: 'out', type: 'vnc-connected' });
    
    console.log(`VNC connection established for VM ${data.vmid}`);
  } catch (error) {
    console.error('VNC connection error:', error);
    socket.emit('vnc-error', { 
      error: error instanceof Error ? error.message : 'Failed to connect to VNC' 
    });
    metrics.websocketMessagesTotal.inc({ direction: 'out', type: 'vnc-error' });
  }
}

// SSH 连接处理
export async function handleSSHConnect(
  socket: Socket,
  data: { vmId: string; ip: string; username: string; password?: string }
) {
  try {
    console.log(`SSH connection request for VM ${data.vmId} (${data.ip})`);
    
    // 更新 WebSocket 连接指标
    metrics.websocketConnections.inc();
    
    // 发送 SSH 连接状态
    socket.emit('ssh-connected', {
      status: 'connected',
      vmId: data.vmId,
      ip: data.ip,
      username: data.username
    });
    
    // 记录成功的 SSH 连接
    metrics.websocketMessagesTotal.inc({ direction: 'out', type: 'ssh-connected' });
    
    console.log(`SSH connection established for VM ${data.vmId}`);
    
    // 设置 SSH 数据处理
    socket.on('ssh-data', (sshData: string) => {
      // 这里应该将 SSH 数据转发到实际的 SSH 连接
      // 由于这是一个简化实现，我们只是记录数据
      console.log(`SSH data received for VM ${data.vmId}:`, sshData.substring(0, 50));
      metrics.websocketMessagesTotal.inc({ direction: 'in', type: 'ssh-data' });
    });
    
  } catch (error) {
    console.error('SSH connection error:', error);
    socket.emit('ssh-error', { 
      error: error instanceof Error ? error.message : 'Failed to connect to SSH' 
    });
    metrics.websocketMessagesTotal.inc({ direction: 'out', type: 'ssh-error' });
  }
}

// VM 监控数据推送
export async function handleVMMonitoring(
  socket: Socket,
  vmId: string,
  pveClient: PVEClient
) {
  try {
    // 获取 VM 状态
    const vmStatus = await pveClient.getVMStatus('pve', parseInt(vmId));
    
    // 推送 VM 状态更新
    socket.emit('vm-status-update', {
      vmId,
      status: vmStatus.status,
      cpu: vmStatus.cpu,
      memory: vmStatus.mem,
      disk: vmStatus.disk,
      uptime: vmStatus.uptime
    });
    
    metrics.websocketMessagesTotal.inc({ direction: 'out', type: 'vm-status-update' });
  } catch (error) {
    console.error('VM monitoring error:', error);
  }
}

// 定期推送 VM 监控数据
export function startVMMonitoring(
  socket: Socket,
  vmId: string,
  pveClient: PVEClient,
  interval: number = 5000
) {
  const intervalId = setInterval(async () => {
    await handleVMMonitoring(socket, vmId, pveClient);
  }, interval);
  
  // 清理定时器
  socket.on('disconnect', () => {
    clearInterval(intervalId);
    metrics.websocketConnections.dec();
  });
  
  return intervalId;
}
