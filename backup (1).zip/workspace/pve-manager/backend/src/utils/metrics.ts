import promClient from 'prom-client';

// 创建默认指标（Node.js 内存、CPU 等）
const collectDefaultMetrics = promClient.collectDefaultMetrics;
collectDefaultMetrics({ register: promClient.register });

// 自定义指标
export const metrics = {
  // 用户相关指标
  usersTotal: new promClient.Gauge({
    name: 'users_total',
    help: 'Total number of users',
  }),

  // 虚拟机相关指标
  vmsTotal: new promClient.Gauge({
    name: 'vms_total',
    help: 'Total number of virtual machines',
  }),

  vmsRunning: new promClient.Gauge({
    name: 'vms_running',
    help: 'Number of running virtual machines',
  }),

  vmsByStatus: new promClient.Gauge({
    name: 'vms_by_status',
    help: 'Number of virtual machines by status',
    labelNames: ['status'],
  }),

  // API 请求相关指标
  httpRequestDurationSeconds: new promClient.Histogram({
    name: 'http_request_duration_seconds',
    help: 'Duration of HTTP requests in seconds',
    labelNames: ['method', 'route', 'status_code'],
    buckets: [0.1, 0.5, 1, 2, 5, 10],
  }),

  httpRequestsTotal: new promClient.Counter({
    name: 'http_requests_total',
    help: 'Total number of HTTP requests',
    labelNames: ['method', 'route', 'status_code'],
  }),

  // PVE API 调用相关指标
  pveApiCallsTotal: new promClient.Counter({
    name: 'pve_api_calls_total',
    help: 'Total number of PVE API calls',
    labelNames: ['endpoint', 'method', 'status'],
  }),

  pveApiCallDurationSeconds: new promClient.Histogram({
    name: 'pve_api_call_duration_seconds',
    help: 'Duration of PVE API calls in seconds',
    labelNames: ['endpoint', 'method'],
    buckets: [0.1, 0.5, 1, 2, 5, 10],
  }),

  // 数据库相关指标
  dbQueryDurationSeconds: new promClient.Histogram({
    name: 'db_query_duration_seconds',
    help: 'Duration of database queries in seconds',
    labelNames: ['operation', 'table'],
    buckets: [0.01, 0.05, 0.1, 0.5, 1, 5],
  }),

  dbQueriesTotal: new promClient.Counter({
    name: 'db_queries_total',
    help: 'Total number of database queries',
    labelNames: ['operation', 'table'],
  }),

  // WebSocket 连接相关指标
  websocketConnections: new promClient.Gauge({
    name: 'websocket_connections',
    help: 'Number of active WebSocket connections',
  }),

  websocketMessagesTotal: new promClient.Counter({
    name: 'websocket_messages_total',
    help: 'Total number of WebSocket messages',
    labelNames: ['direction', 'type'],
  }),

  // 防火墙规则相关指标
  firewallRulesTotal: new promClient.Gauge({
    name: 'firewall_rules_total',
    help: 'Total number of firewall rules',
  }),

  firewallRulesEnabled: new promClient.Gauge({
    name: 'firewall_rules_enabled',
    help: 'Number of enabled firewall rules',
  }),

  // 端口转发相关指标
  portForwardsTotal: new promClient.Gauge({
    name: 'port_forwards_total',
    help: 'Total number of port forwarding rules',
  }),

  portForwardsEnabled: new promClient.Gauge({
    name: 'port_forwards_enabled',
    help: 'Number of enabled port forwarding rules',
  }),
};

// 获取所有指标的函数
export const getMetrics = async () => {
  return promClient.register.metrics();
};

// 获取指标内容的函数（用于调试）
export const getMetricsContentType = () => {
  return promClient.register.contentType;
};

// 重置所有指标（用于测试）
export const resetMetrics = () => {
  promClient.register.resetMetrics();
};
