-- Initialize database
-- This script runs when PostgreSQL container starts for the first time

-- Create database if not exists
SELECT 'CREATE DATABASE pvemanager'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'pvemanager');

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
