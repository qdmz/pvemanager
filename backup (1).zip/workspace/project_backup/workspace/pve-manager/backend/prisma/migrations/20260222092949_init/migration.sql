-- AlterTable
ALTER TABLE "PveNode" ADD COLUMN "description" TEXT;
