const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function fixAdminStatus() {
  try {
    console.log('🔍 Finding admin user...');
    
    // Find the admin user
    const adminUser = await prisma.user.findFirst({
      where: { role: 'ADMIN' }
    });
    
    if (!adminUser) {
      console.error('❌ Admin user not found');
      return;
    }
    
    console.log(`📋 Found admin user: ${adminUser.email}, Status: ${adminUser.status}`);
    
    // Update the status to ACTIVE if it's not already
    if (adminUser.status !== 'ACTIVE') {
      console.log('🔄 Updating admin status to ACTIVE...');
      await prisma.user.update({
        where: { id: adminUser.id },
        data: { status: 'ACTIVE' }
      });
      console.log('✅ Admin status updated to ACTIVE');
    } else {
      console.log('✅ Admin status is already ACTIVE');
    }
    
    // Also update emailVerified to true
    if (!adminUser.emailVerified) {
      console.log('🔄 Updating emailVerified to true...');
      await prisma.user.update({
        where: { id: adminUser.id },
        data: { emailVerified: true }
      });
      console.log('✅ emailVerified updated to true');
    } else {
      console.log('✅ emailVerified is already true');
    }
    
  } catch (error) {
    console.error('❌ Error fixing admin status:', error);
  } finally {
    await prisma.$disconnect();
  }
}

fixAdminStatus();
