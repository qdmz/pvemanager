import axios, { AxiosInstance } from 'axios';
import https from 'https';

class PVEClient {
  private api: AxiosInstance;
  private ticket: string | null = null;
  private csrfToken: string | null = null;

  constructor(
    private host: string,
    private username: string,
    private passwordOrToken: string,
    private realm: string = 'pam',
    private isTokenAuth: boolean = false
  ) {
    this.api = axios.create({
      baseURL: `https://${host}:8006/api2/json`,
      httpsAgent: new https.Agent({
        rejectUnauthorized: false // For self-signed certificates
      }),
      timeout: 30000,
    });
  }

  async authenticate() {
    // If using token authentication, no need to get ticket
    if (this.isTokenAuth) {
      // For token auth, we don't need ticket, we can use the token directly
      return { ticket: null, csrfToken: null };
    }

    try {
      const response = await this.api.post('/access/ticket', {
        username: this.username,
        password: this.passwordOrToken,
        realm: this.realm
      });

      const { ticket, CSRFPreventionToken } = response.data.data;
      this.ticket = ticket;
      this.csrfToken = CSRFPreventionToken;

      // Set default headers for password auth
      this.api.defaults.headers.common['Cookie'] = `PVEAuthCookie=${ticket}`;
      this.api.defaults.headers.common['CSRFPreventionToken'] = CSRFPreventionToken;

      return { ticket, csrfToken: CSRFPreventionToken };
    } catch (error) {
      throw new Error('PVE authentication failed');
    }
  }

  // Node management
  async getNodes() {
    const response = await this.api.get('/nodes');
    return response.data.data;
  }

  async getNodeStatus(node: string) {
    const response = await this.api.get(`/nodes/${node}/status`);
    return response.data.data;
  }

  // VM management
  async getVMs(node?: string): Promise<any[]> {
    if (node) {
      const response = await this.api.get(`/nodes/${node}/qemu`);
      return response.data.data;
    }
    
    const nodes = await this.getNodes();
    const allVMs: any[] = [];
    
    for (const nodeInfo of nodes) {
      try {
        const node = nodeInfo.node;
        const vms: any[] = await this.getVMs(node);
        allVMs.push(...vms.map((vm: any) => ({ ...vm, node })));
      } catch (error) {
        console.error(`Failed to get VMs from node ${nodeInfo.node}:`, error);
      }
    }
    
    return allVMs;
  }

  async getVM(node: string, vmid: number) {
    const response = await this.api.get(`/nodes/${node}/qemu/${vmid}`);
    return response.data.data;
  }

  async getVMStatus(node: string, vmid: number) {
    const response = await this.api.get(`/nodes/${node}/qemu/${vmid}/status/current`);
    return response.data.data;
  }

  async createVM(node: string, config: any) {
    const response = await this.api.post(`/nodes/${node}/qemu`, config);
    return response.data.data;
  }

  async startVM(node: string, vmid: number) {
    const response = await this.api.post(`/nodes/${node}/qemu/${vmid}/status/start`);
    return response.data.data;
  }

  async stopVM(node: string, vmid: number) {
    const response = await this.api.post(`/nodes/${node}/qemu/${vmid}/status/stop`);
    return response.data.data;
  }

  async shutdownVM(node: string, vmid: number) {
    const response = await this.api.post(`/nodes/${node}/qemu/${vmid}/status/shutdown`);
    return response.data.data;
  }

  async rebootVM(node: string, vmid: number) {
    const response = await this.api.post(`/nodes/${node}/qemu/${vmid}/status/reboot`);
    return response.data.data;
  }

  async suspendVM(node: string, vmid: number) {
    const response = await this.api.post(`/nodes/${node}/qemu/${vmid}/status/suspend`);
    return response.data.data;
  }

  async resumeVM(node: string, vmid: number) {
    const response = await this.api.post(`/nodes/${node}/qemu/${vmid}/status/resume`);
    return response.data.data;
  }

  async deleteVM(node: string, vmid: number, purge: boolean = true) {
    const response = await this.api.delete(`/nodes/${node}/qemu/${vmid}`, {
      params: { purge }
    });
    return response.data.data;
  }

  async cloneVM(node: string, vmid: number, config: any) {
    const response = await this.api.post(`/nodes/${node}/qemu/${vmid}/clone`, config);
    return response.data.data;
  }

  async migrateVM(node: string, vmid: number, targetNode: string) {
    const response = await this.api.post(`/nodes/${node}/qemu/${vmid}/migrate`, {
      target: targetNode
    });
    return response.data.data;
  }

  async updateVMConfig(node: string, vmid: number, config: any) {
    const response = await this.api.put(`/nodes/${node}/qemu/${vmid}/config`, config);
    return response.data.data;
  }

  // VM Configuration
  async getVMConfig(node: string, vmid: number) {
    const response = await this.api.get(`/nodes/${node}/qemu/${vmid}/config`);
    return response.data.data;
  }

  // Snapshots
  async getVMSnapshots(node: string, vmid: number) {
    const response = await this.api.get(`/nodes/${node}/qemu/${vmid}/snapshot`);
    return response.data.data;
  }

  async createVMSnapshot(node: string, vmid: number, name: string, description?: string) {
    const response = await this.api.post(`/nodes/${node}/qemu/${vmid}/snapshot`, {
      snapname: name,
      description
    });
    return response.data.data;
  }

  async rollbackVMSnapshot(node: string, vmid: number, snapname: string) {
    const response = await this.api.post(`/nodes/${node}/qemu/${vmid}/snapshot/${snapname}/rollback`);
    return response.data.data;
  }

  async deleteVMSnapshot(node: string, vmid: number, snapname: string) {
    const response = await this.api.delete(`/nodes/${node}/qemu/${vmid}/snapshot/${snapname}`);
    return response.data.data;
  }

  // Backups
  async createVMBackup(node: string, vmid: number, config: any) {
    const response = await this.api.post(`/nodes/${node}/vzdump`, {
      vmid,
      ...config
    });
    return response.data.data;
  }

  // Firewall
  async getVMFirewall(node: string, vmid: number) {
    const response = await this.api.get(`/nodes/${node}/qemu/${vmid}/firewall`);
    return response.data.data;
  }

  async getVMFirewallRules(node: string, vmid: number) {
    const response = await this.api.get(`/nodes/${node}/qemu/${vmid}/firewall/rules`);
    return response.data.data;
  }

  async createVMFirewallRule(node: string, vmid: number, rule: any) {
    const response = await this.api.post(`/nodes/${node}/qemu/${vmid}/firewall/rules`, rule);
    return response.data.data;
  }

  async updateVMFirewallRule(node: string, vmid: number, pos: number, rule: any) {
    const response = await this.api.put(`/nodes/${node}/qemu/${vmid}/firewall/rules/${pos}`, rule);
    return response.data.data;
  }

  async deleteVMFirewallRule(node: string, vmid: number, pos: number) {
    const response = await this.api.delete(`/nodes/${node}/qemu/${vmid}/firewall/rules/${pos}`);
    return response.data.data;
  }

  // VNC/Terminal
  async getVNCProxy(node: string, vmid: number) {
    const response = await this.api.post(`/nodes/${node}/qemu/${vmid}/vncproxy`);
    return response.data.data;
  }

  async getVNCTicket(node: string, vmid: number) {
    const response = await this.api.post(`/nodes/${node}/qemu/${vmid}/vncproxy`, {
      websocket: 1
    });
    return response.data.data;
  }

  // Storage
  async getStorage(node?: string) {
    if (node) {
      const response = await this.api.get(`/nodes/${node}/storage`);
      return response.data.data;
    }
    
    const response = await this.api.get('/storage');
    return response.data.data;
  }

  async getStorageContent(node: string, storage: string) {
    const response = await this.api.get(`/nodes/${node}/storage/${storage}/content`);
    return response.data.data;
  }

  // Network
  async getNetworks(node: string) {
    const response = await this.api.get(`/nodes/${node}/network`);
    return response.data.data;
  }

  // Cluster
  async getClusterStatus() {
    const response = await this.api.get('/cluster/status');
    return response.data.data;
  }

  async getClusterResources() {
    const response = await this.api.get('/cluster/resources');
    return response.data.data;
  }

  // Tasks
  async getTaskStatus(node: string, upid: string) {
    const response = await this.api.get(`/nodes/${node}/tasks/${upid}/status`);
    return response.data.data;
  }

  async getTaskLog(node: string, upid: string) {
    const response = await this.api.get(`/nodes/${node}/tasks/${upid}/log`);
    return response.data.data;
  }
}

export default PVEClient;
