import bcrypt from 'bcryptjs';
import { prisma } from '../utils/database';

async function resetAdminPassword() {
  try {
    // Check if admin user exists
    const existingAdmin = await prisma.user.findFirst({
      where: { role: 'ADMIN' }
    });

    if (!existingAdmin) {
      console.log('❌ Admin user not found');
      return;
    }

    // Reset password to admin123
    const hashedPassword = await bcrypt.hash('admin123', 12);
    
    await prisma.user.update({
      where: { id: existingAdmin.id },
      data: {
        password: hashedPassword,
        status: 'ACTIVE'
      }
    });

    console.log('✅ Admin user password reset successfully');
    console.log('📧 Email: admin@example.com');
    console.log('🔑 Password: admin123');
    console.log('⚠️  Please change the default password immediately!');

  } catch (error) {
    console.error('❌ Failed to reset admin user password:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

// Run if called directly
if (require.main === module) {
  resetAdminPassword();
}

export { resetAdminPassword };