import { Request, Response, NextFunction } from 'express';
import { z, ZodError } from 'zod';

export const validateRequest = (schema: z.ZodSchema): ((req: Request, res: Response, next: NextFunction) => void) => {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      schema.parse(req.body);
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({
          error: 'Validation error',
          details: error.errors
        });
        return;
      }
      next(error);
    }
  };
};

// Auth validation schemas
export const registerSchema = z.object({
  email: z.string().email('Invalid email address'),
  username: z.string().min(3, 'Username must be at least 3 characters'),
  password: z.string().min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
  confirmPassword: z.string()
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"]
});

export const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password is required')
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Current password is required'),
  newPassword: z.string().min(8, 'New password must be at least 8 characters'),
  confirmPassword: z.string()
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"]
});

// VM validation schemas
export const createVMSchema = z.object({
  name: z.string().min(1, 'VM name is required').max(50, 'VM name too long'),
  node: z.string().min(1, 'Node is required'),
  vmid: z.number().int().positive().optional(),
  cpus: z.number().int().min(1).max(128),
  memory: z.number().int().min(512).max(1048576), // MB
  disk: z.number().int().min(10).max(10000), // GB
  storage: z.string().min(1, 'Storage is required'),
  network: z.object({
    bridge: z.string().optional(),
    model: z.enum(['e1000', 'virtio', 'rtl8139', 'vmxnet3']).optional(),
    firewall: z.boolean().optional()
  }).optional(),
  os: z.object({
    type: z.enum(['linux', 'windows', 'other']),
    template: z.string().optional(),
    iso: z.string().optional()
  }),
  cloudInit: z.object({
    hostname: z.string().optional(),
    user: z.string().optional(),
    password: z.string().optional(),
    sshKeys: z.array(z.string()).optional()
  }).optional()
});

export const updateVMSchema = z.object({
  name: z.string().min(1).max(50).optional(),
  cpus: z.number().int().min(1).max(128).optional(),
  memory: z.number().int().min(512).max(1048576).optional(),
  description: z.string().max(500).optional()
});

// API Key validation schema
export const createApiKeySchema = z.object({
  name: z.string().min(1, 'Name is required').max(100),
  permissions: z.array(z.string()).min(1, 'At least one permission is required'),
  expiresIn: z.number().int().min(1).max(365).optional() // days
});

// Firewall validation schema
export const firewallRuleSchema = z.object({
  type: z.enum(['in', 'out']),
  action: z.enum(['ACCEPT', 'DROP', 'REJECT']),
  protocol: z.enum(['tcp', 'udp', 'icmp', 'any']),
  source: z.string().optional(), // CIDR
  sourcePort: z.string().optional(),
  dest: z.string().optional(), // CIDR
  destPort: z.string().optional(), // port or range
  comment: z.string().max(200).optional()
});

// Port forwarding validation schema
export const portForwardSchema = z.object({
  name: z.string().min(1).max(50),
  protocol: z.enum(['tcp', 'udp']),
  sourcePort: z.number().int().min(1).max(65535),
  destIP: z.string().ip('Invalid IP address'),
  destPort: z.number().int().min(1).max(65535),
  comment: z.string().max(200).optional()
});
