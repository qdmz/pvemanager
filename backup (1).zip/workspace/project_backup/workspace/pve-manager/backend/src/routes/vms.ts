import express from 'express';
import { prisma } from '../utils/database';
import { authenticateToken, requireUser, AuthenticatedRequest } from '../middleware/auth';
import { validateRequest, createVMSchema, updateVMSchema } from '../middleware/validation';
import { asyncHandler } from '../middleware/errorHandler';
import PVEClient from '../utils/pveClient';

const router = express.Router();

// Initialize PVE client
const pveClient = new PVEClient(
  process.env.PVE_HOST || 'localhost',
  process.env.PVE_USERNAME || 'root',
  process.env.PVE_PASSWORD || '',
  process.env.PVE_REALM || 'pam'
);

// Authenticate PVE client
pveClient.authenticate().catch(console.error);

// Apply authentication to all routes
router.use(authenticateToken);

// Get all VMs
router.get('/', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { page = 1, limit = 10, search, status, node } = req.query;
  
  const skip = (Number(page) - 1) * Number(limit);
  
  const where: any = {};
  
  // Regular users can only see their own VMs
  if (req.user!.role === 'user') {
    where.userId = req.user!.id;
  }
  
  if (search) {
    where.OR = [
      { name: { contains: search as string, mode: 'insensitive' } },
      { ip: { contains: search as string } }
    ];
  }
  
  if (status) where.status = status;
  if (node) where.node = node;
  
  const [vms, total] = await Promise.all([
    prisma.virtualMachine.findMany({
      where,
      include: {
        user: {
          select: { id: true, username: true, email: true }
        }
      },
      skip,
      take: Number(limit),
      orderBy: { createdAt: 'desc' }
    }),
    prisma.virtualMachine.count({ where })
  ]);
  
  res.json({
    vms,
    pagination: {
      page: Number(page),
      limit: Number(limit),
      total,
      pages: Math.ceil(total / Number(limit))
    }
  });
}));

// Get VM by ID
router.get('/:id', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  
  const vm = await prisma.virtualMachine.findUnique({
    where: { id },
    include: {
      user: {
        select: { id: true, username: true, email: true }
      },
      snapshots: {
        orderBy: { createdAt: 'desc' }
      },
      backups: {
        orderBy: { createdAt: 'desc' }
      }
    }
  });
  
  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }
  
  // Regular users can only view their own VMs
  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }
  
  // Get real-time status from PVE
  try {
    const pveStatus = await pveClient.getVMStatus(vm.node, vm.vmid);
    vm.status = pveStatus.status || vm.status;
    // 移除不存在的字段赋值
  } catch (error) {
    console.error(`Failed to get real-time status for VM ${vm.name}:`, error);
  }
  
  res.json({ vm });
}));

// Create VM
router.post('/', validateRequest(createVMSchema), asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { name, node, cpus, memory, disk, storage, network, os, cloudInit } = req.body;
  
  // Check VM quota for regular users
  if (req.user!.role === 'user') {
    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    if (user.vmCount >= user.vmQuota) {
      return res.status(400).json({ error: 'VM quota exceeded' });
    }
  }
  
  // Generate VMID
  const existingVMs = await prisma.virtualMachine.findMany({
    select: { vmid: true }
  });
  const usedVMIDs = new Set(existingVMs.map(vm => vm.vmid));
  let vmid = 100;
  while (usedVMIDs.has(vmid)) {
    vmid++;
  }
  
  // Create VM config for PVE
  const vmConfig = {
    vmid,
    name,
    cores: cpus,
    memory,
    ostype: os.type === 'linux' ? 'l26' : os.type === 'windows' ? 'win11' : 'other',
    ide2: `file=local:iso/${os.iso || 'none'},media=cdrom`,
    scsi0: `${storage}:${vmid}/vm-${vmid}-disk-0.qcow2,size=${disk}G`,
    net0: network ? `model=${network.model || 'virtio'},bridge=${network.bridge || 'vmbr0'}${network.firewall ? ',firewall=1' : ''}` : undefined,
    description: `Created by ${req.user!.email}`,
    ...cloudInit
  };
  
  try {
    // Create VM in PVE
    const pveResult = await pveClient.createVM(node, vmConfig);
    
    // Create VM record in database
    const vm = await prisma.virtualMachine.create({
      data: {
        name,
        node,
        vmid,
        cpus,
        memory,
        disk,
        storage,
        status: 'stopped',
        userId: req.user!.id,
        ip: network?.ip || null,
        osType: os.type,
        config: vmConfig
      },
      include: {
        user: {
          select: { id: true, username: true, email: true }
        }
      }
    });
    
    // Update user's VM count
    await prisma.user.update({
      where: { id: req.user!.id },
      data: { vmCount: { increment: 1 } }
    });
    
    // Log the action
    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'vm.create',
        resource: 'vm',
        resourceId: vm.id,
        status: 'success',
        message: `Created VM ${name} (VMID: ${vmid})`,
        ip: req.ip || 'unknown'
      }
    });
    
    res.status(201).json({ message: 'VM created successfully', vm });
  } catch (error) {
    // Log the failure
    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'vm.create',
        resource: 'vm',
        resourceId: 'failed',
        status: 'failed',
        message: `Failed to create VM ${name}: ${error}`,
        ip: req.ip || 'unknown'
      }
    });
    
    throw error;
  }
}));

// Update VM
router.put('/:id', validateRequest(updateVMSchema), asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  const { name, cpus, memory, description } = req.body;
  
  const vm = await prisma.virtualMachine.findUnique({ where: { id } });
  
  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }
  
  // Regular users can only update their own VMs
  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }
  
  // Update VM config in PVE if hardware changes
  if (cpus || memory) {
    try {
      const pveConfig: any = {};
      if (cpus) pveConfig.cores = cpus;
      if (memory) pveConfig.memory = memory;
      
      await pveClient.updateVMConfig(vm.node, vm.vmid, pveConfig);
    } catch (error) {
      return res.status(400).json({ error: 'Failed to update VM configuration' });
    }
  }
  
  // Update VM in database
  const updatedVM = await prisma.virtualMachine.update({
    where: { id },
    data: {
      name,
      cpus,
      memory,
      description
    },
    include: {
      user: {
        select: { id: true, username: true, email: true }
      }
    }
  });
  
  // Log the action
  await prisma.auditLog.create({
    data: {
      userId: req.user!.id,
      action: 'vm.update',
      resource: 'vm',
      resourceId: vm.id,
      status: 'success',
      message: `Updated VM ${vm.name}`,
      ip: req.ip || 'unknown'
    }
  });
  
  res.json({ message: 'VM updated successfully', vm: updatedVM });
}));

// Delete VM
router.delete('/:id', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  
  const vm = await prisma.virtualMachine.findUnique({ where: { id } });
  
  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }
  
  // Regular users can only delete their own VMs
  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }
  
  try {
    // Delete VM from PVE
    await pveClient.deleteVM(vm.node, vm.vmid);
    
    // Delete VM from database
    await prisma.virtualMachine.delete({ where: { id } });
    
    // Update user's VM count
    await prisma.user.update({
      where: { id: vm.userId },
      data: { vmCount: { decrement: 1 } }
    });
    
    // Log the action
    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'vm.delete',
        resource: 'vm',
        resourceId: vm.id,
        status: 'success',
        message: `Deleted VM ${vm.name} (VMID: ${vm.vmid})`,
        ip: req.ip || 'unknown'
      }
    });
    
    res.json({ message: 'VM deleted successfully' });
  } catch (error) {
    return res.status(400).json({ error: 'Failed to delete VM' });
  }
}));

// Start VM
router.post('/:id/start', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  
  const vm = await prisma.virtualMachine.findUnique({ where: { id } });
  
  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }
  
  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }
  
  try {
    await pveClient.startVM(vm.node, vm.vmid);
    
    await prisma.virtualMachine.update({
      where: { id },
      data: { status: 'running' }
    });
    
    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'vm.start',
        resource: 'vm',
        resourceId: vm.id,
        status: 'success',
        message: `Started VM ${vm.name}`,
        ip: req.ip || 'unknown'
      }
    });
    
    res.json({ message: 'VM started successfully' });
  } catch (error) {
    res.status(400).json({ error: 'Failed to start VM' });
  }
}));

// Stop VM
router.post('/:id/stop', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  
  const vm = await prisma.virtualMachine.findUnique({ where: { id } });
  
  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }
  
  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }
  
  try {
    await pveClient.stopVM(vm.node, vm.vmid);
    
    await prisma.virtualMachine.update({
      where: { id },
      data: { status: 'stopped' }
    });
    
    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'vm.stop',
        resource: 'vm',
        resourceId: vm.id,
        status: 'success',
        message: `Stopped VM ${vm.name}`,
        ip: req.ip || 'unknown'
      }
    });
    
    res.json({ message: 'VM stopped successfully' });
  } catch (error) {
    res.status(400).json({ error: 'Failed to stop VM' });
  }
}));

// Restart VM
router.post('/:id/restart', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  
  const vm = await prisma.virtualMachine.findUnique({ where: { id } });
  
  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }
  
  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }
  
  try {
    await pveClient.rebootVM(vm.node, vm.vmid);
    
    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'vm.restart',
        resource: 'vm',
        resourceId: vm.id,
        status: 'success',
        message: `Restarted VM ${vm.name}`,
        ip: req.ip || 'unknown'
      }
    });
    
    res.json({ message: 'VM restarted successfully' });
  } catch (error) {
    res.status(400).json({ error: 'Failed to restart VM' });
  }
}));

// Get VM snapshots
router.get('/:id/snapshots', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  
  const vm = await prisma.virtualMachine.findUnique({ where: { id } });
  
  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }
  
  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }
  
  try {
    const snapshots = await pveClient.getVMSnapshots(vm.node, vm.vmid);
    res.json({ snapshots });
  } catch (error) {
    res.status(400).json({ error: 'Failed to get snapshots' });
  }
}));

// Create VM snapshot
router.post('/:id/snapshots', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  const { name, description } = req.body;
  
  const vm = await prisma.virtualMachine.findUnique({ where: { id } });
  
  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }
  
  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }
  
  try {
    const snapshot = await pveClient.createVMSnapshot(vm.node, vm.vmid, name, description);
    
    // Save snapshot to database
    await prisma.snapshot.create({
      data: {
        name,
        description,
        snapname: name, // 使用与name相同的值作为snapname
        vmId: vm.id,
        userId: req.user!.id
      }
    });
    
    res.json({ message: 'Snapshot created successfully', snapshot });
  } catch (error) {
    res.status(400).json({ error: 'Failed to create snapshot' });
  }
}));

// Get VNC connection info
router.get('/:id/vnc', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const vm = await prisma.virtualMachine.findUnique({ where: { id } });

  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }

  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  try {
    const vncInfo = await pveClient.getVNCTicket(vm.node, vm.vmid);
    res.json({ vncInfo });
  } catch (error) {
    res.status(400).json({ error: 'Failed to get VNC connection info' });
  }
}));

// Suspend VM
router.post('/:id/suspend', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const vm = await prisma.virtualMachine.findUnique({ where: { id } });

  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }

  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  try {
    await pveClient.suspendVM(vm.node, vm.vmid);

    await prisma.virtualMachine.update({
      where: { id },
      data: { status: 'suspended' }
    });

    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'vm.suspend',
        resource: 'vm',
        resourceId: vm.id,
        status: 'success',
        message: `Suspended VM ${vm.name}`,
        ip: req.ip || 'unknown'
      }
    });

    res.json({ message: 'VM suspended successfully' });
  } catch (error) {
    res.status(400).json({ error: 'Failed to suspend VM' });
  }
}));

// Resume VM
router.post('/:id/resume', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const vm = await prisma.virtualMachine.findUnique({ where: { id } });

  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }

  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  try {
    await pveClient.resumeVM(vm.node, vm.vmid);

    await prisma.virtualMachine.update({
      where: { id },
      data: { status: 'running' }
    });

    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'vm.resume',
        resource: 'vm',
        resourceId: vm.id,
        status: 'success',
        message: `Resumed VM ${vm.name}`,
        ip: req.ip || 'unknown'
      }
    });

    res.json({ message: 'VM resumed successfully' });
  } catch (error) {
    res.status(400).json({ error: 'Failed to resume VM' });
  }
}));

// Clone VM
router.post('/:id/clone', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  const { name, targetNode } = req.body;

  const vm = await prisma.virtualMachine.findUnique({ where: { id } });

  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }

  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  // Check VM quota
  const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
  if (req.user!.role === 'user' && user!.vmCount >= user!.vmQuota) {
    return res.status(400).json({ error: 'VM quota exceeded' });
  }

  try {
    // Generate new VMID
    const existingVMs = await prisma.virtualMachine.findMany({
      select: { vmid: true }
    });
    const usedVMIDs = new Set(existingVMs.map(v => v.vmid));
    let newVmid = 100;
    while (usedVMIDs.has(newVmid)) {
      newVmid++;
    }

    // Clone VM in PVE
    await pveClient.cloneVM(vm.node, vm.vmid, {
      newid: newVmid,
      name: name || `${vm.name}-clone`,
      target: targetNode || vm.node,
      full: 1
    });

    // Create VM record in database
    const clonedVM = await prisma.virtualMachine.create({
      data: {
        name: name || `${vm.name}-clone`,
        node: targetNode || vm.node,
        vmid: newVmid,
        cpus: vm.cpus,
        memory: vm.memory,
        disk: vm.disk,
        storage: vm.storage,
        status: 'stopped',
        userId: req.user!.id,
        osType: vm.osType,
        description: `Cloned from ${vm.name}`
      },
      include: {
        user: {
          select: { id: true, username: true, email: true }
        }
      }
    });

    // Update user's VM count
    await prisma.user.update({
      where: { id: req.user!.id },
      data: { vmCount: { increment: 1 } }
    });

    // Log the action
    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'vm.clone',
        resource: 'vm',
        resourceId: clonedVM.id,
        status: 'success',
        message: `Cloned VM ${vm.name} to ${clonedVM.name}`,
        ip: req.ip || 'unknown'
      }
    });

    res.status(201).json({ message: 'VM cloned successfully', vm: clonedVM });
  } catch (error) {
    res.status(400).json({ error: 'Failed to clone VM' });
  }
}));

// Migrate VM
router.post('/:id/migrate', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  const { targetNode } = req.body;

  const vm = await prisma.virtualMachine.findUnique({ where: { id } });

  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }

  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  if (!targetNode) {
    return res.status(400).json({ error: 'Target node is required' });
  }

  try {
    // Migrate VM in PVE
    await pveClient.migrateVM(vm.node, vm.vmid, targetNode);

    // Update VM record in database
    const updatedVM = await prisma.virtualMachine.update({
      where: { id },
      data: { node: targetNode },
      include: {
        user: {
          select: { id: true, username: true, email: true }
        }
      }
    });

    // Log the action
    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'vm.migrate',
        resource: 'vm',
        resourceId: vm.id,
        status: 'success',
        message: `Migrated VM ${vm.name} to ${targetNode}`,
        ip: req.ip || 'unknown'
      }
    });

    res.json({ message: 'VM migrated successfully', vm: updatedVM });
  } catch (error) {
    res.status(400).json({ error: 'Failed to migrate VM' });
  }
}));

// Delete snapshot
router.delete('/:id/snapshots/:snapname', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id, snapname } = req.params;

  const vm = await prisma.virtualMachine.findUnique({ where: { id } });

  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }

  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  try {
    await pveClient.deleteVMSnapshot(vm.node, vm.vmid, snapname);

    // Remove snapshot from database
    await prisma.snapshot.deleteMany({
      where: {
        vmId: id,
        snapname
      }
    });

    res.json({ message: 'Snapshot deleted successfully' });
  } catch (error) {
    res.status(400).json({ error: 'Failed to delete snapshot' });
  }
}));

// Restore snapshot
router.post('/:id/snapshots/:snapname/restore', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id, snapname } = req.params;

  const vm = await prisma.virtualMachine.findUnique({ where: { id } });

  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }

  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  try {
    await pveClient.rollbackVMSnapshot(vm.node, vm.vmid, snapname);

    // Log the action
    await prisma.auditLog.create({
      data: {
        userId: req.user!.id,
        action: 'vm.snapshot.restore',
        resource: 'vm',
        resourceId: vm.id,
        status: 'success',
        message: `Restored snapshot ${snapname} for VM ${vm.name}`,
        ip: req.ip || 'unknown'
      }
    });

    res.json({ message: 'Snapshot restored successfully' });
  } catch (error) {
    res.status(400).json({ error: 'Failed to restore snapshot' });
  }
}));

// Get VM config
router.get('/:id/config', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const vm = await prisma.virtualMachine.findUnique({ where: { id } });

  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }

  if (req.user!.role === 'user' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  try {
    const config = await pveClient.getVMConfig(vm.node, vm.vmid);
    res.json({ config });
  } catch (error) {
    res.status(400).json({ error: 'Failed to get VM config' });
  }
}));

export { router as vmRoutes };
