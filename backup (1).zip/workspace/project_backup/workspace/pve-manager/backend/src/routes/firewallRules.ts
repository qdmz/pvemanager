import express from 'express';
import { prisma } from '../utils/database';
import { authenticateToken, AuthenticatedRequest, isAdmin } from '../middleware/auth';
import { asyncHandler } from '../middleware/errorHandler';
import { validateRequest, firewallRuleSchema } from '../middleware/validation';

const router = express.Router();

// Get all firewall rules for a VM
router.get('/vm/:vmId', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { vmId } = req.params;
  const { page = 1, limit = 50 } = req.query;
  const pageNumber = parseInt(page as string);
  const pageSize = parseInt(limit as string);
  const skip = (pageNumber - 1) * pageSize;

  // Check if user has access to the VM
  const vm = await prisma.virtualMachine.findUnique({ where: { id: vmId } });
  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }

  if (req.user!.role !== 'admin' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  const [rules, total] = await Promise.all([
    prisma.firewallRule.findMany({
      where: { vmId },
      select: {
        id: true,
        pos: true,
        type: true,
        action: true,
        protocol: true,
        source: true,
        sourcePort: true,
        dest: true,
        destPort: true,
        comment: true,
        enabled: true,
        createdAt: true,
        updatedAt: true
      },
      orderBy: { pos: 'asc' },
      skip,
      take: pageSize
    }),
    prisma.firewallRule.count({ where: { vmId } })
  ]);

  const totalPages = Math.ceil(total / pageSize);

  res.json({
    rules,
    pagination: {
      page: pageNumber,
      limit: pageSize,
      total,
      totalPages
    }
  });
}));

// Get all firewall rules (admin only)
router.get('/', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { page = 1, limit = 50, vmId } = req.query;
  const pageNumber = parseInt(page as string);
  const pageSize = parseInt(limit as string);
  const skip = (pageNumber - 1) * pageSize;

  const filters: any = {};
  if (vmId) filters.vmId = vmId;

  const [rules, total] = await Promise.all([
    prisma.firewallRule.findMany({
      where: filters,
      select: {
        id: true,
        pos: true,
        type: true,
        action: true,
        protocol: true,
        source: true,
        sourcePort: true,
        dest: true,
        destPort: true,
        comment: true,
        enabled: true,
        createdAt: true,
        updatedAt: true,
        vm: {
          select: {
            id: true,
            name: true,
            vmid: true,
            node: true
          }
        }
      },
      orderBy: { pos: 'asc' },
      skip,
      take: pageSize
    }),
    prisma.firewallRule.count({ where: filters })
  ]);

  const totalPages = Math.ceil(total / pageSize);

  res.json({
    rules,
    pagination: {
      page: pageNumber,
      limit: pageSize,
      total,
      totalPages
    }
  });
}));

// Get single firewall rule
router.get('/:id', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const rule = await prisma.firewallRule.findUnique({ where: { id } });
  if (!rule) {
    return res.status(404).json({ error: 'Firewall rule not found' });
  }

  // Check if user has access to the VM
  const vm = await prisma.virtualMachine.findUnique({ where: { id: rule.vmId } });
  if (req.user!.role !== 'admin' && vm!.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  res.json({ rule });
}));

// Create firewall rule
router.post('/', authenticateToken, validateRequest(firewallRuleSchema), asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { type, action, protocol, source, sourcePort, dest, destPort, comment, enabled = true, vmId } = req.body;

  // Check if user has access to the VM
  const vm = await prisma.virtualMachine.findUnique({ where: { id: vmId } });
  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }

  if (req.user!.role !== 'admin' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  // Get the next position for the rule
  const maxPos = await prisma.firewallRule.aggregate({
    _max: { pos: true },
    where: { vmId }
  });
  const nextPos = (maxPos._max.pos || 0) + 1;

  // Create the rule
  const rule = await prisma.firewallRule.create({
    data: {
      pos: nextPos,
      type,
      action,
      protocol,
      source,
      sourcePort,
      dest,
      destPort,
      comment,
      enabled,
      vmId,
      userId: req.user!.id
    },
    select: {
      id: true,
      pos: true,
      type: true,
      action: true,
      protocol: true,
      source: true,
      sourcePort: true,
      dest: true,
      destPort: true,
      comment: true,
      enabled: true,
      createdAt: true
    }
  });

  res.status(201).json({ message: 'Firewall rule created successfully', rule });
}));

// Update firewall rule
router.put('/:id', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  const { type, action, protocol, source, sourcePort, dest, destPort, comment, enabled, pos } = req.body;

  const rule = await prisma.firewallRule.findUnique({ where: { id } });
  if (!rule) {
    return res.status(404).json({ error: 'Firewall rule not found' });
  }

  // Check if user has access to the VM
  const vm = await prisma.virtualMachine.findUnique({ where: { id: rule.vmId } });
  if (req.user!.role !== 'admin' && vm!.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  const updateData: any = {
    type,
    action,
    protocol,
    source,
    sourcePort,
    dest,
    destPort,
    comment,
    enabled
  };

  // If position is changed, we need to reorder other rules
  if (pos && pos !== rule.pos) {
    // First, update the rule's position to a temporary value
    await prisma.firewallRule.update({
      where: { id },
      data: { pos: -1 }
    });

    // Update other rules based on the new position
    if (pos < rule.pos) {
      // Moving up: increase positions of rules between new pos and old pos
      await prisma.firewallRule.updateMany({
        where: {
          vmId: rule.vmId,
          pos: {
            gte: pos,
            lt: rule.pos
          }
        },
        data: { pos: { increment: 1 } }
      });
    } else {
      // Moving down: decrease positions of rules between old pos and new pos
      await prisma.firewallRule.updateMany({
        where: {
          vmId: rule.vmId,
          pos: {
            gt: rule.pos,
            lte: pos
          }
        },
        data: { pos: { decrement: 1 } }
      });
    }

    // Now set the final position
    updateData.pos = pos;
  }

  const updatedRule = await prisma.firewallRule.update({
    where: { id },
    data: updateData,
    select: {
      id: true,
      pos: true,
      type: true,
      action: true,
      protocol: true,
      source: true,
      sourcePort: true,
      dest: true,
      destPort: true,
      comment: true,
      enabled: true,
      updatedAt: true
    }
  });

  res.json({ message: 'Firewall rule updated successfully', rule: updatedRule });
}));

// Delete firewall rule
router.delete('/:id', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const rule = await prisma.firewallRule.findUnique({ where: { id } });
  if (!rule) {
    return res.status(404).json({ error: 'Firewall rule not found' });
  }

  // Check if user has access to the VM
  const vm = await prisma.virtualMachine.findUnique({ where: { id: rule.vmId } });
  if (req.user!.role !== 'admin' && vm!.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  // Delete the rule
  await prisma.firewallRule.delete({ where: { id } });

  // Update positions of remaining rules
  await prisma.firewallRule.updateMany({
    where: {
      vmId: rule.vmId,
      pos: { gt: rule.pos }
    },
    data: { pos: { decrement: 1 } }
  });

  res.json({ message: 'Firewall rule deleted successfully' });
}));

// Toggle firewall rule enabled status
router.post('/:id/toggle', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const rule = await prisma.firewallRule.findUnique({ where: { id } });
  if (!rule) {
    return res.status(404).json({ error: 'Firewall rule not found' });
  }

  // Check if user has access to the VM
  const vm = await prisma.virtualMachine.findUnique({ where: { id: rule.vmId } });
  if (req.user!.role !== 'admin' && vm!.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  const updatedRule = await prisma.firewallRule.update({
    where: { id },
    data: { enabled: !rule.enabled },
    select: {
      id: true,
      enabled: true
    }
  });

  res.json({ message: 'Firewall rule status toggled', rule: updatedRule });
}));

export { router as firewallRulesRoutes };
