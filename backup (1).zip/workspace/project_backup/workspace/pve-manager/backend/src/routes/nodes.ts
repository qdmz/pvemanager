import express from 'express';
import { prisma } from '../utils/database';
import { authenticateToken, AuthenticatedRequest, isAdmin } from '../middleware/auth';
import { asyncHandler } from '../middleware/errorHandler';
import PVEClient from '../utils/pveClient';

const router = express.Router();

// Get all PVE nodes (admin only)
router.get('/', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const nodes = await prisma.pveNode.findMany({
    select: {
      id: true,
      name: true,
      host: true,
      port: true,
      username: true,
      status: true,
      cpuUsage: true,
      memoryUsage: true,
      diskUsage: true,
      uptime: true,
      version: true,
      lastSeen: true,
      createdAt: true,
      updatedAt: true
    },
    orderBy: { name: 'asc' }
  });

  res.json({ nodes });
}));

// Get single PVE node (admin only)
router.get('/:id', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const node = await prisma.pveNode.findUnique({ where: { id } });

  if (!node) {
    return res.status(404).json({ error: 'Node not found' });
  }

  res.json({ node });
}));

// Create PVE node (admin only)
router.post('/', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { name, host, port, username, password, realm, description } = req.body;

  // Check if node already exists
  const existingNode = await prisma.pveNode.findUnique({ where: { name } });
  if (existingNode) {
    return res.status(400).json({ error: 'Node with this name already exists' });
  }

  // Create node in database without PVE connection check (for testing)
  const node = await prisma.pveNode.create({
    data: {
      name,
      host,
      port: port || 8006,
      username,
      password, // In production, this should be encrypted
      realm: realm || 'pam',
      description,
      status: 'UNKNOWN',
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSeen: new Date()
    },
    select: {
      id: true,
      name: true,
      host: true,
      port: true,
      username: true,
      status: true,
      cpuUsage: true,
      memoryUsage: true,
      diskUsage: true,
      uptime: true,
      version: true,
      lastSeen: true,
      createdAt: true
    }
  });

  res.status(201).json({ message: 'Node created successfully', node });
}));

// Update PVE node (admin only)
router.put('/:id', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  const { host, port, username, password, realm, description } = req.body;

  const node = await prisma.pveNode.findUnique({ where: { id } });
  if (!node) {
    return res.status(404).json({ error: 'Node not found' });
  }

  const updateData: any = {
    host,
    port,
    username,
    description,
    ...(password && { password }),
    realm
  };

  const updatedNode = await prisma.pveNode.update({
    where: { id },
    data: updateData,
    select: {
      id: true,
      name: true,
      host: true,
      port: true,
      username: true,
      status: true,
      cpuUsage: true,
      memoryUsage: true,
      diskUsage: true,
      uptime: true,
      version: true,
      lastSeen: true,
      updatedAt: true
    }
  });

  res.json({ message: 'Node updated successfully', node: updatedNode });
}));

// Delete PVE node (admin only)
router.delete('/:id', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const node = await prisma.pveNode.findUnique({ where: { id } });
  if (!node) {
    return res.status(404).json({ error: 'Node not found' });
  }

  await prisma.pveNode.delete({ where: { id } });

  res.json({ message: 'Node deleted successfully' });
}));

// Update node status (admin only)
router.post('/:id/update-status', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const node = await prisma.pveNode.findUnique({ where: { id } });
  if (!node) {
    return res.status(404).json({ error: 'Node not found' });
  }

  try {
    // Check if we're using token authentication (if password is in token format or we have tokenId/tokenSecret)
    const isTokenAuth = node.password?.startsWith('PVEAPIToken=') || !node.password;
    
    // Create PVE client with appropriate authentication method
    const pveClient = new PVEClient(
      node.host,
      node.username,
      node.password || '',
      node.realm || 'pam',
      isTokenAuth
    );
    
    await pveClient.authenticate();
    const status = await pveClient.getNodeStatus(node.name);

    await prisma.pveNode.update({
      where: { id },
      data: {
        status: 'ONLINE',
        cpuUsage: status.cpu || 0,
        memoryUsage: (status.mem / status.maxmem) * 100 || 0,
        diskUsage: (status.disk / status.maxdisk) * 100 || 0,
        uptime: status.uptime,
        version: status.version,
        lastSeen: new Date()
      }
    });

    res.json({ message: 'Node status updated successfully' });
  } catch (error) {
    // For testing purposes, we'll still update the database with basic information even if we can't connect to PVE
    try {
      await prisma.pveNode.update({
        where: { id },
        data: {
          status: 'UNKNOWN',
          lastSeen: new Date()
        }
      });
      
      // Return a more user-friendly error message
      res.status(200).json({ 
        message: 'Node status updated locally, but failed to connect to PVE server: ' + (error as Error).message,
        warning: '无法连接到PVE服务器，节点状态已更新为UNKNOWN',
        status: 'warning'
      });
    } catch (dbError) {
      res.status(500).json({ error: 'Failed to update node status: ' + (dbError as Error).message });
    }
  }
}));

export { router as nodeRoutes };
