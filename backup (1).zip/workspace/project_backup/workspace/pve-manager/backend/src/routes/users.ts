import express from 'express';
import bcrypt from 'bcryptjs';
import { prisma } from '../utils/database';
import { authenticateToken, requireAdmin, AuthenticatedRequest } from '../middleware/auth';
import { asyncHandler } from '../middleware/errorHandler';

const router = express.Router();

// Apply authentication to all routes
router.use(authenticateToken);

// Get all users (Admin can get all, regular users can only get their own)
router.get('/', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { page = 1, limit = 10, search, role, status } = req.query;
  
  // Regular users can only get their own information
  if (req.user!.role !== 'admin') {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.id },
      select: {
        id: true,
        email: true,
        username: true,
        role: true,
        status: true,
        vmQuota: true,
        vmCount: true,
        createdAt: true,
        lastLoginAt: true
      }
    });
    
    return res.json({
      users: [user],
      pagination: {
        page: 1,
        limit: 1,
        total: 1,
        pages: 1
      }
    });
  }
  
  // Admin can get all users with filtering and pagination
  const skip = (Number(page) - 1) * Number(limit);
  
  const where: any = {};
  
  if (search) {
    where.OR = [
      { email: { contains: search as string, mode: 'insensitive' } },
      { username: { contains: search as string, mode: 'insensitive' } }
    ];
  }
  
  if (role) where.role = role;
  if (status) where.status = status;
  
  const [users, total] = await Promise.all([
    prisma.user.findMany({
      where,
      skip,
      take: Number(limit),
      select: {
        id: true,
        email: true,
        username: true,
        role: true,
        status: true,
        vmQuota: true,
        vmCount: true,
        createdAt: true,
        lastLoginAt: true
      },
      orderBy: { createdAt: 'desc' }
    }),
    prisma.user.count({ where })
  ]);
  
  res.json({
    users,
    pagination: {
      page: Number(page),
      limit: Number(limit),
      total,
      pages: Math.ceil(total / Number(limit))
    }
  });
}));

// Get user by ID (Admin or self)
router.get('/:id', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  
  // Users can only view their own profile unless admin
  if (req.user!.role !== 'admin' && req.user!.id !== id) {
    return res.status(403).json({ error: 'Access denied' });
  }
  
  const user = await prisma.user.findUnique({
    where: { id },
    select: {
      id: true,
      email: true,
      username: true,
      role: true,
      status: true,
      vmQuota: true,
      vmCount: true,
      createdAt: true,
      updatedAt: true,
      lastLoginAt: true
    }
  });
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  res.json({ user });
}));

// Create user (Admin only)
router.post('/', requireAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { email, username, password, role, vmQuota } = req.body;
  
  // Check if user exists
  const existingUser = await prisma.user.findFirst({
    where: {
      OR: [{ email }, { username }]
    }
  });
  
  if (existingUser) {
    return res.status(400).json({ 
      error: existingUser.email === email ? 'Email already exists' : 'Username already exists'
    });
  }
  
  // Hash password
  const hashedPassword = await bcrypt.hash(password, 12);
  
  const user = await prisma.user.create({
    data: {
      email,
      username,
      password: hashedPassword,
      role: role || 'user',
      status: 'ACTIVE',
      vmQuota: vmQuota || parseInt(process.env.DEFAULT_VM_QUOTA || '5')
    },
    select: {
      id: true,
      email: true,
      username: true,
      role: true,
      status: true,
      vmQuota: true,
      vmCount: true,
      createdAt: true
    }
  });
  
  // Log the action
  await prisma.auditLog.create({
    data: {
      userId: req.user!.id,
      action: 'user.create',
      resource: 'user',
      resourceId: user.id,
      status: 'success',
      message: `Created user ${user.username}`,
      ip: req.ip || 'unknown'
    }
  });
  
  res.status(201).json({ message: 'User created successfully', user });
}));

// Update user (Admin or self)
router.put('/:id', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  const { username, role, vmQuota, status } = req.body;
  
  // Users can only update their own username
  if (req.user!.role !== 'admin') {
    if (id !== req.user!.id) {
      return res.status(403).json({ error: 'Access denied' });
    }
    // Users cannot change role, vmQuota, or status
    delete req.body.role;
    delete req.body.vmQuota;
    delete req.body.status;
  }
  
  const user = await prisma.user.update({
    where: { id },
    data: {
      username,
      role,
      vmQuota,
      status
    },
    select: {
      id: true,
      email: true,
      username: true,
      role: true,
      status: true,
      vmQuota: true,
      vmCount: true,
      updatedAt: true
    }
  });
  
  // Log the action
  await prisma.auditLog.create({
    data: {
      userId: req.user!.id,
      action: 'user.update',
      resource: 'user',
      resourceId: user.id,
      status: 'success',
      message: `Updated user ${user.username}`,
      ip: req.ip || 'unknown'
    }
  });
  
  res.json({ message: 'User updated successfully', user });
}));

// Delete user (Admin only)
router.delete('/:id', requireAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  
  // Check if user exists
  const user = await prisma.user.findUnique({ where: { id } });
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  // Check if user has VMs
  const vmCount = await prisma.virtualMachine.count({
    where: { userId: id }
  });
  
  if (vmCount > 0) {
    return res.status(400).json({ error: 'Cannot delete user with existing VMs' });
  }
  
  await prisma.user.delete({ where: { id } });
  
  // Log the action
  await prisma.auditLog.create({
    data: {
      userId: req.user!.id,
      action: 'user.delete',
      resource: 'user',
      resourceId: id,
      status: 'success',
      message: `Deleted user ${user.username}`,
      ip: req.ip || 'unknown'
    }
  });
  
  res.json({ message: 'User deleted successfully' });
}));

// Reset password (Admin only)
router.put('/:id/password', requireAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  const { password } = req.body;
  
  if (!password) {
    return res.status(400).json({ error: 'Password is required' });
  }
  
  const hashedPassword = await bcrypt.hash(password, 12);
  
  await prisma.user.update({
    where: { id },
    data: { password: hashedPassword }
  });
  
  res.json({ message: 'Password reset successfully' });
}));

// Get user's VMs
router.get('/:id/vms', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  
  // Users can only view their own VMs unless admin
  if (req.user!.role !== 'admin' && req.user!.id !== id) {
    return res.status(403).json({ error: 'Access denied' });
  }
  
  const vms = await prisma.virtualMachine.findMany({
    where: { userId: id },
    orderBy: { createdAt: 'desc' }
  });
  
  res.json({ vms });
}));

// Get user's API keys
router.get('/:id/api-keys', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  
  // Users can only view their own API keys unless admin
  if (req.user!.role !== 'admin' && req.user!.id !== id) {
    return res.status(403).json({ error: 'Access denied' });
  }
  
  const apiKeys = await prisma.apiKey.findMany({
    where: { userId: id },
    select: {
      id: true,
      name: true,
      permissions: true,
      status: true,
      createdAt: true,
      lastUsedAt: true,
      expiresAt: true
    },
    orderBy: { createdAt: 'desc' }
  });
  
  res.json({ apiKeys });
}));

// Get user's audit logs
router.get('/:id/logs', asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  const { page = 1, limit = 10 } = req.query;
  
  // Users can only view their own logs unless admin
  if (req.user!.role !== 'admin' && req.user!.id !== id) {
    return res.status(403).json({ error: 'Access denied' });
  }
  
  const skip = (Number(page) - 1) * Number(limit);
  
  const [logs, total] = await Promise.all([
    prisma.auditLog.findMany({
      where: { userId: id },
      skip,
      take: Number(limit),
      orderBy: { createdAt: 'desc' }
    }),
    prisma.auditLog.count({ where: { userId: id } })
  ]);
  
  res.json({
    logs,
    pagination: {
      page: Number(page),
      limit: Number(limit),
      total,
      pages: Math.ceil(total / Number(limit))
    }
  });
}));

export { router as userRoutes };
