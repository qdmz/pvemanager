import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '../utils/database';
import { authenticateToken, AuthenticatedRequest } from '../middleware/auth';
import { validateRequest, registerSchema, loginSchema, changePasswordSchema } from '../middleware/validation';
import { asyncHandler } from '../middleware/errorHandler';

const router = express.Router();

// Register
router.post('/register', validateRequest(registerSchema), asyncHandler(async (req: any, res: any) => {
  const { email, username, password, confirmPassword } = req.body;

  // Check if user already exists
  const existingUser = await prisma.user.findFirst({
    where: {
      OR: [{ email }, { username }]
    }
  });

  if (existingUser) {
    return res.status(400).json({ 
      error: existingUser.email === email ? 'Email already registered' : 'Username already taken'
    });
  }

  // Hash password
  const hashedPassword = await bcrypt.hash(password, 12);

  // Create user
  const user = await prisma.user.create({
    data: {
      email,
      username,
      password: hashedPassword,
      role: 'user',
      status: 'ACTIVE',
      vmQuota: parseInt(process.env.DEFAULT_VM_QUOTA || '5')
    },
    select: {
      id: true,
      email: true,
      username: true,
      role: true,
      status: true,
      vmQuota: true,
      createdAt: true
    }
  });

  // Generate tokens
  const accessToken = jwt.sign(
    { userId: user.id, email: user.email, role: user.role },
    process.env.JWT_SECRET!,
    { expiresIn: '15m' }
  );

  const refreshToken = jwt.sign(
    { userId: user.id },
    process.env.JWT_REFRESH_SECRET!,
    { expiresIn: '7d' }
  );

  res.status(201).json({
    message: 'User registered successfully',
    user,
    accessToken,
    refreshToken
  });
}));

// Login
router.post('/login', validateRequest(loginSchema), asyncHandler(async (req: any, res: any) => {
  const { email, password } = req.body;

  // Find user
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  // Check password
  const isValidPassword = await bcrypt.compare(password, user.password);
  if (!isValidPassword) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  // Check if user is active
  if (user.status !== 'ACTIVE') {
    return res.status(401).json({ error: 'Account not activated or suspended' });
  }

  // Update last login
  await prisma.user.update({
    where: { id: user.id },
    data: { lastLoginAt: new Date() }
  });

  // Generate tokens
  const accessToken = jwt.sign(
    { userId: user.id, email: user.email, role: user.role },
    process.env.JWT_SECRET!,
    { expiresIn: '15m' }
  );

  const refreshToken = jwt.sign(
    { userId: user.id },
    process.env.JWT_REFRESH_SECRET!,
    { expiresIn: '7d' }
  );

  res.json({
    message: 'Login successful',
    user: {
      id: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
      vmQuota: user.vmQuota
    },
    accessToken,
    refreshToken
  });
}));

// Logout
router.post('/logout', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  // In a production app, you might want to blacklist the token
  res.json({ message: 'Logged out successfully' });
}));

// Refresh token
router.post('/refresh', asyncHandler(async (req: any, res: any) => {
  const { refreshToken } = req.body;

  if (!refreshToken) {
    return res.status(401).json({ error: 'Refresh token required' });
  }

  try {
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET!) as any;
    
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: { id: true, email: true, role: true, status: true }
    });

    if (!user || user.status !== 'ACTIVE') {
      return res.status(401).json({ error: 'Invalid user' });
    }

    const newAccessToken = jwt.sign(
      { userId: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET!,
      { expiresIn: '15m' }
    );

    res.json({ accessToken: newAccessToken });
  } catch (error) {
    return res.status(403).json({ error: 'Invalid refresh token' });
  }
}));

// Get profile
router.get('/profile', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user!.id },
    select: {
      id: true,
      email: true,
      username: true,
      role: true,
      status: true,
      vmQuota: true,
      vmCount: true,
      createdAt: true,
      lastLoginAt: true
    }
  });

  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  res.json({ user });
}));

// Update profile
router.put('/profile', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { username, email } = req.body;

  const updateData: any = {};
  
  if (username) updateData.username = username;
  if (email) updateData.email = email;

  const user = await prisma.user.update({
    where: { id: req.user!.id },
    data: updateData,
    select: {
      id: true,
      email: true,
      username: true,
      role: true,
      status: true,
      vmQuota: true,
      vmCount: true
    }
  });

  res.json({ message: 'Profile updated', user });
}));

// Change password
router.put('/password', authenticateToken, validateRequest(changePasswordSchema), asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { currentPassword, newPassword } = req.body;

  const user = await prisma.user.findUnique({
    where: { id: req.user!.id }
  });

  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  // Verify current password
  const isValidPassword = await bcrypt.compare(currentPassword, user.password);
  if (!isValidPassword) {
    return res.status(400).json({ error: 'Current password is incorrect' });
  }

  // Hash new password
  const hashedPassword = await bcrypt.hash(newPassword, 12);

  await prisma.user.update({
    where: { id: req.user!.id },
    data: { password: hashedPassword }
  });

  res.json({ message: 'Password changed successfully' });
}));

export { router as authRoutes };
