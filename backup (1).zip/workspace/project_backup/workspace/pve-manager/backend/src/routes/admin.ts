import express from 'express';
import bcrypt from 'bcryptjs';
import { prisma } from '../utils/database';
import { authenticateToken, AuthenticatedRequest, isAdmin } from '../middleware/auth';
import { validateRequest, registerSchema, changePasswordSchema } from '../middleware/validation';
import { asyncHandler } from '../middleware/errorHandler';

const router = express.Router();

// User management

// Get all users (admin only)
router.get('/users', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { page = 1, limit = 20, status, role } = req.query;
  const pageNumber = parseInt(page as string);
  const pageSize = parseInt(limit as string);
  
  const skip = (pageNumber - 1) * pageSize;
  
  // Build filters
  const filters: any = {};
  if (status) filters.status = status;
  if (role) filters.role = role;
  
  const [users, total] = await Promise.all([
    prisma.user.findMany({
      where: filters,
      select: {
        id: true,
        email: true,
        username: true,
        role: true,
        status: true,
        vmQuota: true,
        vmCount: true,
        createdAt: true,
        updatedAt: true,
        lastLoginAt: true,
        emailVerified: true
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: pageSize
    }),
    prisma.user.count({ where: filters })
  ]);
  
  const totalPages = Math.ceil(total / pageSize);
  
  res.json({
    users,
    pagination: {
      page: pageNumber,
      limit: pageSize,
      total,
      totalPages
    }
  });
}));

// Get single user (admin only)
router.get('/users/:id', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  
  const user = await prisma.user.findUnique({
    where: { id },
    select: {
      id: true,
      email: true,
      username: true,
      role: true,
      status: true,
      vmQuota: true,
      vmCount: true,
      createdAt: true,
      updatedAt: true,
      lastLoginAt: true,
      emailVerified: true
    }
  });
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  res.json({ user });
}));

// Create user (admin only)
router.post('/users', authenticateToken, isAdmin, validateRequest(registerSchema), asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { email, username, password, role, vmQuota } = req.body;
  
  // Check if user already exists
  const existingUser = await prisma.user.findFirst({
    where: {
      OR: [{ email }, { username }]
    }
  });
  
  if (existingUser) {
    return res.status(400).json({ 
      error: existingUser.email === email ? 'Email already registered' : 'Username already taken'
    });
  }
  
  // Hash password
  const hashedPassword = await bcrypt.hash(password, 12);
  
  // Create user
  const user = await prisma.user.create({
    data: {
      email,
      username,
      password: hashedPassword,
      role: role || 'USER',
      status: 'ACTIVE',
      vmQuota: vmQuota || parseInt(process.env.DEFAULT_VM_QUOTA || '5'),
      emailVerified: true
    },
    select: {
      id: true,
      email: true,
      username: true,
      role: true,
      status: true,
      vmQuota: true,
      vmCount: true,
      createdAt: true
    }
  });
  
  res.status(201).json({ message: 'User created successfully', user });
}));

// Update user (admin only)
router.put('/users/:id', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  const { username, role, status, vmQuota } = req.body;
  
  const user = await prisma.user.findUnique({
    where: { id }
  });
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  const updatedUser = await prisma.user.update({
    where: { id },
    data: {
      username,
      role,
      status,
      vmQuota
    },
    select: {
      id: true,
      email: true,
      username: true,
      role: true,
      status: true,
      vmQuota: true,
      vmCount: true
    }
  });
  
  res.json({ message: 'User updated successfully', user: updatedUser });
}));

// Delete user (admin only)
router.delete('/users/:id', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  
  // Prevent deleting self
  if (id === req.user!.id) {
    return res.status(400).json({ error: 'Cannot delete your own account' });
  }
  
  const user = await prisma.user.findUnique({
    where: { id }
  });
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  await prisma.user.delete({ where: { id } });
  
  res.json({ message: 'User deleted successfully' });
}));

// Reset user password (admin only)
router.put('/users/:id/password', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  const { newPassword } = req.body;
  
  const user = await prisma.user.findUnique({
    where: { id }
  });
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  // Hash new password
  const hashedPassword = await bcrypt.hash(newPassword, 12);
  
  await prisma.user.update({
    where: { id },
    data: { password: hashedPassword }
  });
  
  res.json({ message: 'Password reset successfully' });
}));

// Verify user email (admin only)
router.put('/users/:id/verify', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  
  const user = await prisma.user.findUnique({
    where: { id }
  });
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  await prisma.user.update({
    where: { id },
    data: { emailVerified: true, status: 'ACTIVE' }
  });
  
  res.json({ message: 'Email verified successfully' });
}));

// VM management

// Get all VMs (admin only)
router.get('/vms', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { page = 1, limit = 20, status, userId } = req.query;
  const pageNumber = parseInt(page as string);
  const pageSize = parseInt(limit as string);
  
  const skip = (pageNumber - 1) * pageSize;
  
  // Build filters
  const filters: any = {};
  if (status) filters.status = status;
  if (userId) filters.userId = userId;
  
  const [vms, total] = await Promise.all([
    prisma.virtualMachine.findMany({
      where: filters,
      select: {
        id: true,
        name: true,
        node: true,
        vmid: true,
        status: true,
        cpus: true,
        memory: true,
        disk: true,
        storage: true,
        ip: true,
        mac: true,
        osType: true,
        description: true,
        createdAt: true,
        updatedAt: true,
        user: {
          select: {
            id: true,
            username: true,
            email: true
          }
        }
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: pageSize
    }),
    prisma.virtualMachine.count({ where: filters })
  ]);
  
  const totalPages = Math.ceil(total / pageSize);
  
  res.json({
    vms,
    pagination: {
      page: pageNumber,
      limit: pageSize,
      total,
      totalPages
    }
  });
}));

// System settings

// Get all system settings (admin only)
router.get('/settings', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const settings = await prisma.systemSetting.findMany({
    select: {
      id: true,
      key: true,
      value: true,
      description: true,
      createdAt: true,
      updatedAt: true
    },
    orderBy: { key: 'asc' }
  });
  
  res.json({ settings });
}));

// Get single system setting (admin only)
router.get('/settings/:key', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { key } = req.params;
  
  const setting = await prisma.systemSetting.findUnique({
    where: { key },
    select: {
      id: true,
      key: true,
      value: true,
      description: true,
      createdAt: true,
      updatedAt: true
    }
  });
  
  if (!setting) {
    return res.status(404).json({ error: 'Setting not found' });
  }
  
  res.json({ setting });
}));

// Create or update system setting (admin only)
router.put('/settings/:key', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { key } = req.params;
  const { value, description } = req.body;
  
  const setting = await prisma.systemSetting.upsert({
    where: { key },
    update: { value, description },
    create: { key, value, description }
  });
  
  res.json({ message: 'Setting updated successfully', setting });
}));

// Delete system setting (admin only)
router.delete('/settings/:key', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { key } = req.params;
  
  const setting = await prisma.systemSetting.findUnique({
    where: { key }
  });
  
  if (!setting) {
    return res.status(404).json({ error: 'Setting not found' });
  }
  
  await prisma.systemSetting.delete({ where: { key } });
  
  res.json({ message: 'Setting deleted successfully' });
}));

export { router as adminRoutes };