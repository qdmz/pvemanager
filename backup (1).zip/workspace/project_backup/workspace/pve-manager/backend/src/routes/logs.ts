import express from 'express';
import { prisma } from '../utils/database';
import { authenticateToken, AuthenticatedRequest, isAdmin } from '../middleware/auth';
import { asyncHandler } from '../middleware/errorHandler';

const router = express.Router();

// Get audit logs with pagination and filters
router.get('/', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { page = 1, limit = 20, action, resource, status, startDate, endDate } = req.query;
  const pageNumber = parseInt(page as string);
  const pageSize = parseInt(limit as string);
  
  const skip = (pageNumber - 1) * pageSize;
  
  // Build filters
  const filters: any = {};
  
  // For non-admin users, only show their own logs
  if (req.user!.role !== 'ADMIN') {
    filters.userId = req.user!.id;
  }
  
  if (action) filters.action = action;
  if (resource) filters.resource = resource;
  if (status) filters.status = status;
  
  if (startDate && endDate) {
    filters.createdAt = {
      gte: new Date(startDate as string),
      lte: new Date(endDate as string)
    };
  } else if (startDate) {
    filters.createdAt = {
      gte: new Date(startDate as string)
    };
  } else if (endDate) {
    filters.createdAt = {
      lte: new Date(endDate as string)
    };
  }
  
  // Get logs with pagination
  const [logs, total] = await Promise.all([
    prisma.auditLog.findMany({
      where: filters,
      select: {
        id: true,
        userId: true,
        user: {
          select: {
            username: true,
            email: true
          }
        },
        action: true,
        resource: true,
        resourceId: true,
        status: true,
        message: true,
        ip: true,
        userAgent: true,
        duration: true,
        createdAt: true
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: pageSize
    }),
    prisma.auditLog.count({ where: filters })
  ]);
  
  const totalPages = Math.ceil(total / pageSize);
  
  res.json({
    logs,
    pagination: {
      page: pageNumber,
      limit: pageSize,
      total,
      totalPages
    }
  });
}));

// Get single audit log
router.get('/:id', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  
  const log = await prisma.auditLog.findUnique({
    where: { id },
    select: {
      id: true,
      userId: true,
      user: {
        select: {
          username: true,
          email: true
        }
      },
      action: true,
      resource: true,
      resourceId: true,
      status: true,
      message: true,
      ip: true,
      userAgent: true,
      duration: true,
      createdAt: true
    }
  });
  
  if (!log) {
    return res.status(404).json({ error: 'Log not found' });
  }
  
  // Check if user has permission to view this log
  if (req.user!.role !== 'ADMIN' && log.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  
  res.json({ log });
}));

// Get logs for a specific user (admin only)
router.get('/user/:userId', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { userId } = req.params;
  const { page = 1, limit = 20 } = req.query;
  const pageNumber = parseInt(page as string);
  const pageSize = parseInt(limit as string);
  
  const skip = (pageNumber - 1) * pageSize;
  
  const [logs, total] = await Promise.all([
    prisma.auditLog.findMany({
      where: { userId },
      select: {
        id: true,
        action: true,
        resource: true,
        resourceId: true,
        status: true,
        message: true,
        ip: true,
        userAgent: true,
        duration: true,
        createdAt: true
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: pageSize
    }),
    prisma.auditLog.count({ where: { userId } })
  ]);
  
  const totalPages = Math.ceil(total / pageSize);
  
  res.json({
    logs,
    pagination: {
      page: pageNumber,
      limit: pageSize,
      total,
      totalPages
    }
  });
}));

export { router as logRoutes };