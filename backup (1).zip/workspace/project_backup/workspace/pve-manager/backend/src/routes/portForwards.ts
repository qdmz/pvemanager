import express from 'express';
import { prisma } from '../utils/database';
import { authenticateToken, AuthenticatedRequest, isAdmin } from '../middleware/auth';
import { asyncHandler } from '../middleware/errorHandler';
import { validateRequest, portForwardSchema } from '../middleware/validation';

const router = express.Router();

// Get all port forwards for a VM
router.get('/vm/:vmId', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { vmId } = req.params;
  const { page = 1, limit = 20 } = req.query;
  const pageNumber = parseInt(page as string);
  const pageSize = parseInt(limit as string);
  const skip = (pageNumber - 1) * pageSize;

  // Check if user has access to the VM
  const vm = await prisma.virtualMachine.findUnique({ where: { id: vmId } });
  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }

  if (req.user!.role !== 'admin' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  const [portForwards, total] = await Promise.all([
    prisma.portForward.findMany({
      where: { vmId },
      select: {
        id: true,
        name: true,
        protocol: true,
        sourcePort: true,
        destIP: true,
        destPort: true,
        comment: true,
        enabled: true,
        createdAt: true,
        updatedAt: true
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: pageSize
    }),
    prisma.portForward.count({ where: { vmId } })
  ]);

  const totalPages = Math.ceil(total / pageSize);

  res.json({
    portForwards,
    pagination: {
      page: pageNumber,
      limit: pageSize,
      total,
      totalPages
    }
  });
}));

// Get all port forwards (admin only)
router.get('/', authenticateToken, isAdmin, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { page = 1, limit = 20, vmId, enabled } = req.query;
  const pageNumber = parseInt(page as string);
  const pageSize = parseInt(limit as string);
  const skip = (pageNumber - 1) * pageSize;

  const filters: any = {};
  if (vmId) filters.vmId = vmId;
  if (enabled !== undefined) filters.enabled = enabled === 'true';

  const [portForwards, total] = await Promise.all([
    prisma.portForward.findMany({
      where: filters,
      select: {
        id: true,
        name: true,
        protocol: true,
        sourcePort: true,
        destIP: true,
        destPort: true,
        comment: true,
        enabled: true,
        createdAt: true,
        updatedAt: true,
        vm: {
          select: {
            id: true,
            name: true,
            vmid: true,
            node: true
          }
        }
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: pageSize
    }),
    prisma.portForward.count({ where: filters })
  ]);

  const totalPages = Math.ceil(total / pageSize);

  res.json({
    portForwards,
    pagination: {
      page: pageNumber,
      limit: pageSize,
      total,
      totalPages
    }
  });
}));

// Get single port forward
router.get('/:id', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const portForward = await prisma.portForward.findUnique({ where: { id } });
  if (!portForward) {
    return res.status(404).json({ error: 'Port forward not found' });
  }

  // Check if user has access to the VM
  const vm = await prisma.virtualMachine.findUnique({ where: { id: portForward.vmId } });
  if (req.user!.role !== 'admin' && vm!.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  res.json({ portForward });
}));

// Create port forward
router.post('/', authenticateToken, validateRequest(portForwardSchema), asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { name, protocol, sourcePort, destIP, destPort, comment, enabled = true, vmId } = req.body;

  // Check if user has access to the VM
  const vm = await prisma.virtualMachine.findUnique({ where: { id: vmId } });
  if (!vm) {
    return res.status(404).json({ error: 'VM not found' });
  }

  if (req.user!.role !== 'admin' && vm.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  // Check if source port is already in use
  const existingPortForward = await prisma.portForward.findFirst({
    where: { sourcePort, protocol }
  });

  if (existingPortForward) {
    return res.status(400).json({ error: 'Source port already in use for this protocol' });
  }

  // Create the port forward
  const portForward = await prisma.portForward.create({
    data: {
      name,
      protocol,
      sourcePort,
      destIP,
      destPort,
      comment,
      enabled,
      vmId,
      userId: req.user!.id
    },
    select: {
      id: true,
      name: true,
      protocol: true,
      sourcePort: true,
      destIP: true,
      destPort: true,
      comment: true,
      enabled: true,
      createdAt: true
    }
  });

  res.status(201).json({ message: 'Port forward created successfully', portForward });
}));

// Update port forward
router.put('/:id', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  const { name, protocol, sourcePort, destIP, destPort, comment, enabled } = req.body;

  const portForward = await prisma.portForward.findUnique({ where: { id } });
  if (!portForward) {
    return res.status(404).json({ error: 'Port forward not found' });
  }

  // Check if user has access to the VM
  const vm = await prisma.virtualMachine.findUnique({ where: { id: portForward.vmId } });
  if (req.user!.role !== 'admin' && vm!.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  // Check if source port is already in use by another port forward
  if (sourcePort && (sourcePort !== portForward.sourcePort || protocol !== portForward.protocol)) {
    const existingPortForward = await prisma.portForward.findFirst({
      where: {
        id: { not: id },
        sourcePort,
        protocol
      }
    });

    if (existingPortForward) {
      return res.status(400).json({ error: 'Source port already in use for this protocol' });
    }
  }

  const updatedPortForward = await prisma.portForward.update({
    where: { id },
    data: {
      name,
      protocol,
      sourcePort,
      destIP,
      destPort,
      comment,
      enabled
    },
    select: {
      id: true,
      name: true,
      protocol: true,
      sourcePort: true,
      destIP: true,
      destPort: true,
      comment: true,
      enabled: true,
      updatedAt: true
    }
  });

  res.json({ message: 'Port forward updated successfully', portForward: updatedPortForward });
}));

// Delete port forward
router.delete('/:id', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const portForward = await prisma.portForward.findUnique({ where: { id } });
  if (!portForward) {
    return res.status(404).json({ error: 'Port forward not found' });
  }

  // Check if user has access to the VM
  const vm = await prisma.virtualMachine.findUnique({ where: { id: portForward.vmId } });
  if (req.user!.role !== 'admin' && vm!.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  await prisma.portForward.delete({ where: { id } });

  res.json({ message: 'Port forward deleted successfully' });
}));

// Toggle port forward enabled status
router.post('/:id/toggle', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const portForward = await prisma.portForward.findUnique({ where: { id } });
  if (!portForward) {
    return res.status(404).json({ error: 'Port forward not found' });
  }

  // Check if user has access to the VM
  const vm = await prisma.virtualMachine.findUnique({ where: { id: portForward.vmId } });
  if (req.user!.role !== 'admin' && vm!.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access denied' });
  }

  const updatedPortForward = await prisma.portForward.update({
    where: { id },
    data: { enabled: !portForward.enabled },
    select: {
      id: true,
      enabled: true
    }
  });

  res.json({ message: 'Port forward status toggled', portForward: updatedPortForward });
}));

export { router as portForwardRoutes };
