import express from 'express';
import crypto from 'crypto';
import { prisma } from '../utils/database';
import { authenticateToken, AuthenticatedRequest } from '../middleware/auth';
import { asyncHandler } from '../middleware/errorHandler';

const router = express.Router();

// Get all API keys for current user
router.get('/', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const apiKeys = await prisma.apiKey.findMany({
    where: { userId: req.user!.id },
    select: {
      id: true,
      name: true,
      key: true,
      permissions: true,
      status: true,
      createdAt: true,
      updatedAt: true,
      lastUsedAt: true,
      expiresAt: true
    },
    orderBy: { createdAt: 'desc' }
  });

  res.json({ apiKeys });
}));

// Create new API key
router.post('/', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { name, permissions, expiresAt } = req.body;

  // Generate random API key and secret
  const key = `pk_${crypto.randomBytes(16).toString('hex')}`;
  const secret = `sk_${crypto.randomBytes(32).toString('hex')}`;

  const apiKey = await prisma.apiKey.create({
    data: {
      name,
      key,
      secret,
      permissions,
      userId: req.user!.id,
      expiresAt: expiresAt ? new Date(expiresAt) : null
    },
    select: {
      id: true,
      name: true,
      key: true,
      permissions: true,
      status: true,
      createdAt: true,
      updatedAt: true,
      lastUsedAt: true,
      expiresAt: true
    }
  });

  res.status(201).json({ message: 'API key created successfully', apiKey });
}));

// Get single API key
router.get('/:id', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const apiKey = await prisma.apiKey.findFirst({
    where: { id, userId: req.user!.id },
    select: {
      id: true,
      name: true,
      key: true,
      permissions: true,
      status: true,
      createdAt: true,
      updatedAt: true,
      lastUsedAt: true,
      expiresAt: true
    }
  });

  if (!apiKey) {
    return res.status(404).json({ error: 'API key not found' });
  }

  res.json({ apiKey });
}));

// Update API key
router.put('/:id', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;
  const { name, permissions, status, expiresAt } = req.body;

  const apiKey = await prisma.apiKey.findFirst({
    where: { id, userId: req.user!.id }
  });

  if (!apiKey) {
    return res.status(404).json({ error: 'API key not found' });
  }

  const updatedApiKey = await prisma.apiKey.update({
    where: { id },
    data: {
      name,
      permissions,
      status,
      expiresAt: expiresAt ? new Date(expiresAt) : null
    },
    select: {
      id: true,
      name: true,
      key: true,
      permissions: true,
      status: true,
      createdAt: true,
      updatedAt: true,
      lastUsedAt: true,
      expiresAt: true
    }
  });

  res.json({ message: 'API key updated successfully', apiKey: updatedApiKey });
}));

// Delete API key
router.delete('/:id', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const { id } = req.params;

  const apiKey = await prisma.apiKey.findFirst({
    where: { id, userId: req.user!.id }
  });

  if (!apiKey) {
    return res.status(404).json({ error: 'API key not found' });
  }

  await prisma.apiKey.delete({ where: { id } });

  res.json({ message: 'API key deleted successfully' });
}));

// Get API key stats
router.get('/stats', authenticateToken, asyncHandler(async (req: AuthenticatedRequest, res: any) => {
  const stats = await prisma.apiKey.groupBy({
    by: ['status'],
    _count: {
      id: true
    }
  });

  const total = await prisma.apiKey.count();
  const active = stats.find(s => s.status === 'ACTIVE')?._count.id || 0;
  const revoked = stats.find(s => s.status === 'REVOKED')?._count.id || 0;
  const expired = stats.find(s => s.status === 'EXPIRED')?._count.id || 0;

  res.json({
    total,
    active,
    revoked,
    expired
  });
}));

export { router as apiKeyRoutes };