# PVE管理系统 - 部署指南

## 目录

- [系统要求](#系统要求)
- [快速部署](#快速部署)
- [手动部署](#手动部署)
- [生产环境配置](#生产环境配置)
- [监控和日志](#监控和日志)
- [备份和恢复](#备份和恢复)
- [故障排除](#故障排除)

## 系统要求

### 硬件要求
- **CPU**: 2核及以上
- **内存**: 4GB及以上
- **磁盘**: 20GB及以上可用空间
- **网络**: 稳定的网络连接

### 软件要求
- **操作系统**: Ubuntu 20.04+ / Debian 11+ / CentOS 8+
- **Docker**: 20.10+
- **Docker Compose**: 2.0+

### PVE要求
- Proxmox VE 7.0+
- PVE API访问权限
- 至少一个PVE节点

## 快速部署

### 使用安装脚本（推荐）

```bash
# 1. 克隆项目
git clone <repository-url>
cd new-pve-system

# 2. 运行安装脚本
chmod +x install.sh
sudo ./install.sh

# 3. 按照提示输入配置信息
# - PVE主机地址
# - PVE用户名和密码
# - 其他配置选项
```

安装脚本会自动完成：
1. ✅ 安装Docker和Docker Compose
2. ✅ 配置环境变量
3. ✅ 构建所有服务镜像
4. ✅ 启动服务
5. ✅ 初始化数据库
6. ✅ 创建管理员账户

### 使用快速启动脚本（开发环境）

```bash
# 1. 配置环境变量
cp .env.example .env
nano .env  # 编辑配置

# 2. 启动服务
chmod +x quick-start.sh
./quick-start.sh
```

## 手动部署

### 1. 准备环境

```bash
# 克隆项目
git clone <repository-url>
cd new-pve-system

# 创建必要目录
mkdir -p backend/logs backend/uploads
mkdir -p nginx/logs nginx/ssl
mkdir -p monitoring/grafana/provisioning
```

### 2. 配置环境变量

```bash
# 复制环境变量模板
cp .env.example .env

# 编辑配置文件
nano .env
```

**必填配置项**:
```env
# PVE配置
PVE_HOST=your-pve-host-or-ip
PVE_USERNAME=root
PVE_PASSWORD=your-pve-password
PVE_REALM=pam

# JWT密钥（请修改为随机字符串）
JWT_SECRET=your-random-secret-key-1
JWT_REFRESH_SECRET=your-random-secret-key-2

# 数据库配置
DATABASE_URL=postgresql://postgres:postgres@postgres:5432/pvemanager

# Redis配置
REDIS_URL=redis://redis:6379
```

### 3. 构建和启动服务

```bash
# 构建镜像
docker-compose build

# 启动所有服务
docker-compose up -d

# 查看服务状态
docker-compose ps
```

### 4. 初始化数据库

```bash
# 等待PostgreSQL就绪（约30秒）
sleep 30

# 生成Prisma客户端
docker-compose exec backend npx prisma generate

# 运行数据库迁移
docker-compose exec backend npx prisma migrate deploy

# 创建管理员用户
docker-compose exec backend node dist/scripts/createAdmin.js
```

### 5. 验证部署

```bash
# 检查所有服务状态
docker-compose ps

# 测试后端API
curl http://localhost:5000/health

# 访问前端
# 浏览器打开 http://localhost
```

## 生产环境配置

### 使用HTTPS

1. **获取SSL证书**

```bash
# 使用Let's Encrypt
sudo apt-get install certbot
sudo certbot certonly --standalone -d yourdomain.com
```

2. **配置Nginx**

```bash
# 复制证书到ssl目录
cp /etc/letsencrypt/live/yourdomain.com/fullchain.pem nginx/ssl/
cp /etc/letsencrypt/live/yourdomain.com/privkey.pem nginx/ssl/
```

3. **更新nginx.conf**

```nginx
server {
    listen 443 ssl http2;
    server_name yourdomain.com;

    ssl_certificate /etc/nginx/ssl/fullchain.pem;
    ssl_certificate_key /etc/nginx/ssl/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # ... 其他配置
}

server {
    listen 80;
    server_name yourdomain.com;
    return 301 https://$server_name$request_uri;
}
```

### 配置防火墙

```bash
# 允许必要端口
ufw allow 80/tcp    # HTTP
ufw allow 443/tcp   # HTTPS
ufw allow 5000/tcp  # Backend API (可选，如果通过nginx代理则不需要)
ufw allow 22/tcp    # SSH

# 启用防火墙
ufw enable
```

### 配置日志轮转

创建 `/etc/logrotate.d/pve-manager`:

```
/path/to/backend/logs/*.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    create 0644 www-data www-data
}

/path/to/nginx/logs/*.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    create 0644 www-data www-data
}
```

### 设置自动备份

创建备份脚本 `backup.sh`:

```bash
#!/bin/bash

BACKUP_DIR=/backups/pve-manager
DATE=$(date +%Y%m%d_%H%M%S)

# 创建备份目录
mkdir -p $BACKUP_DIR

# 备份数据库
docker-compose exec -T postgres pg_dump -U postgres pvemanager > $BACKUP_DIR/db_$DATE.sql

# 备份配置文件
tar -czf $BACKUP_DIR/config_$DATE.tar.gz .env nginx/ssl/

# 删除7天前的备份
find $BACKUP_DIR -type f -mtime +7 -delete

echo "Backup completed: $BACKUP_DIR/db_$DATE.sql"
```

添加到crontab:

```bash
crontab -e

# 每天凌晨2点备份
0 2 * * * /path/to/backup.sh
```

## 监控和日志

### 查看日志

```bash
# 所有服务日志
docker-compose logs

# 特定服务日志
docker-compose logs backend
docker-compose logs frontend
docker-compose logs postgres

# 实时跟踪日志
docker-compose logs -f backend

# 最近100行
docker-compose logs --tail=100 backend
```

### 使用Grafana监控

1. 访问 Grafana: http://localhost:3001
2. 默认登录: admin/admin
3. 首次登录后修改密码
4. 导入仪表板配置

### 使用Prometheus查询

访问 Prometheus: http://localhost:9090

常用查询示例:
- `rate(http_requests_total[1m])` - API请求速率
- `vms_total` - 虚拟机总数
- `vms_running` - 运行中的虚拟机数量

## 备份和恢复

### 备份数据

```bash
# 备份数据库
docker-compose exec postgres pg_dump -U postgres pvemanager > backup.sql

# 备份数据卷
docker run --rm \
  -v pvemanager_postgres_data:/data \
  -v $(pwd):/backup \
  alpine tar czf /backup/postgres_data.tar.gz /data

# 备份配置
tar -czf config_backup.tar.gz .env nginx/ssl/
```

### 恢复数据

```bash
# 恢复数据库
docker-compose exec -T postgres psql -U postgres pvemanager < backup.sql

# 恢复数据卷
docker run --rm \
  -v pvemanager_postgres_data:/data \
  -v $(pwd):/backup \
  alpine sh -c "cd /data && tar xzf /backup/postgres_data.tar.gz --strip 1"

# 恢复配置
tar -xzf config_backup.tar.gz
```

### 迁移到新服务器

```bash
# 1. 在旧服务器导出所有数据
docker-compose exec postgres pg_dump -U postgres pvemanager > db_dump.sql

# 2. 复制所有卷
docker run --rm --volumes-from pvemanager-postgres \
  -v $(pwd):/backup ubuntu tar czf /backup/postgres_data.tar.gz /var/lib/postgresql/data

# 3. 在新服务器导入数据
docker-compose exec -T postgres psql -U postgres pvemanager < db_dump.sql

# 4. 复制配置文件
scp .env user@new-server:/path/to/pve-manager/
```

## 故障排除

### 服务无法启动

```bash
# 查看服务日志
docker-compose logs

# 检查端口占用
netstat -tlnp | grep :5000

# 重启服务
docker-compose restart

# 清理并重建
docker-compose down -v
docker-compose up -d
```

### 数据库连接失败

```bash
# 检查PostgreSQL状态
docker-compose ps postgres

# 进入PostgreSQL容器
docker-compose exec postgres psql -U postgres pvemanager

# 检查数据库连接
docker-compose exec backend npx prisma db push
```

### PVE连接失败

```bash
# 测试PVE连接
curl -k https://your-pve-host:8006/api2/json/access/ticket \
  -d "username=root&password=your-password"

# 检查网络连通性
ping your-pve-host
telnet your-pve-host 8006

# 查看后端日志
docker-compose logs backend | grep PVE
```

### 内存不足

```bash
# 增加Docker内存限制
# 编辑docker-compose.yml
services:
  backend:
    mem_limit: 2g
    memswap_limit: 2g
```

### 性能优化

```bash
# 1. 启用Docker构建缓存
export DOCKER_BUILDKIT=1

# 2. 使用多阶段构建
# (已在Dockerfile中实现)

# 3. 优化数据库查询
# 在Prisma schema中添加索引

# 4. 启用Redis缓存
# 确保.env中配置了REDIS_URL

# 5. 配置Nginx缓存
# 在nginx.conf中添加缓存配置
```

## 更新系统

```bash
# 拉取最新代码
git pull origin main

# 重新构建镜像
docker-compose build

# 重启服务
docker-compose up -d

# 运行数据库迁移
docker-compose exec backend npx prisma migrate deploy
```

## 安全建议

1. **修改默认密码**: 首次登录后立即修改管理员密码
2. **使用HTTPS**: 生产环境必须启用SSL/TLS
3. **配置防火墙**: 只开放必要的端口
4. **定期备份**: 设置自动备份策略
5. **监控日志**: 定期检查异常访问
6. **更新系统**: 及时应用安全补丁
7. **限制权限**: 使用最小权限原则

## 技术支持

- 📖 文档: 查看 README.md 和 快速启动指南.md
- 🐛 问题反馈: 提交 GitHub Issue
- 📧 联系支持: support@yourdomain.com

## 许可证

MIT License
