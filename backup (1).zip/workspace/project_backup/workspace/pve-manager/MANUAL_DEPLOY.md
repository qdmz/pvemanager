# PVE管理系统远程部署指南

## 服务器信息
- 服务器IP: 154.9.237.203
- 用户名: root
- 密码: thanks123A#

## 部署步骤

### 方法一：使用SSH手动部署（推荐）

#### 步骤1：打包项目代码
在本地执行：
```bash
cd /home/admin/workspace
tar -czf pve-manager.tar.gz pve-manager/ --exclude='node_modules' --exclude='frontend/dist' --exclude='backend/node_modules' --exclude='.git'
```

#### 步骤2：上传代码到远程服务器
```bash
scp pve-manager.tar.gz root@154.9.237.203:/tmp/
```
（输入密码：thanks123A#）

#### 步骤3：SSH登录到远程服务器
```bash
ssh root@154.9.237.203
```
（输入密码：thanks123A#）

#### 步骤4：在远程服务器上解压项目
```bash
cd /root
rm -rf pve-manager
tar -xzf /tmp/pve-manager.tar.gz
mv pve-manager /root/
cd /root/pve-manager
```

#### 步骤5：执行一键部署脚本
```bash
chmod +x QUICK_DEPLOY.sh
./QUICK_DEPLOY.sh
```

### 方法二：使用部署脚本（需要手动输入密码）

在本地执行：
```bash
cd /home/admin/workspace/pve-manager
chmod +x deploy_to_remote.sh
./deploy_to_remote.sh
```

脚本会提示输入密码，输入：thanks123A#

## 部署后配置

### 1. 修改PVE连接配置
```bash
vi /root/pve-manager/backend/.env
```

修改以下配置：
```
PVE_HOST="你的PVE服务器地址"
PVE_USERNAME="root"
PVE_PASSWORD="你的PVE密码"
```

### 2. 重启后端服务
```bash
pm2 restart pve-backend
```

### 3. 查看后端日志
```bash
pm2 logs pve-backend
```

## 访问系统

部署完成后，访问：http://154.9.237.203

默认登录账号：
- 邮箱: admin@example.com
- 密码: admin123

## 常用命令

```bash
# 查看后端状态
pm2 status

# 查看后端日志
pm2 logs pve-backend

# 重启后端
pm2 restart pve-backend

# 停止后端
pm2 stop pve-backend

# 查看Nginx状态
systemctl status nginx

# 重启Nginx
systemctl restart nginx

# 查看Nginx日志
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

## 故障排查

### 后端无法启动
```bash
cd /root/pve-manager/backend
npm run dev
```

### 前端无法访问
```bash
# 检查Nginx配置
nginx -t

# 检查Nginx状态
systemctl status nginx

# 重新加载Nginx
systemctl reload nginx
```

### 数据库问题
```bash
cd /root/pve-manager/backend
npx prisma migrate deploy
```

## 防火墙配置

如果无法访问，检查防火墙：
```bash
# 查看防火墙状态
ufw status

# 开放端口
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 5000/tcp

# 启用防火墙
ufw enable
```
