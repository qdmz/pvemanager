#!/bin/bash

# 远程部署脚本 - 在本地执行，自动部署到远程服务器

REMOTE_HOST="154.9.237.203"
REMOTE_USER="root"
REMOTE_PASSWORD="thanks123A#"
PROJECT_DIR="/root/pve-manager"

echo "=========================================="
echo "  PVE管理系统远程部署"
echo "=========================================="
echo "目标服务器: $REMOTE_HOST"
echo ""

# 创建临时部署脚本
cat > /tmp/remote_deploy.sh << 'REMOTE_SCRIPT'
#!/bin/bash
set -e

echo "正在更新系统..."
apt-get update -qq

echo "正在安装必要工具..."
apt-get install -y curl git nodejs npm nginx ufw > /dev/null 2>&1

echo "正在安装PM2..."
npm install -g pm2 > /dev/null 2>&1

echo "正在创建项目目录..."
mkdir -p /root/pve-manager

echo "正在安装后端依赖..."
cd /root/pve-manager/backend
npm install > /dev/null 2>&1

echo "正在生成Prisma客户端..."
npx prisma generate > /dev/null 2>&1

echo "正在运行数据库迁移..."
npx prisma migrate deploy > /dev/null 2>&1

echo "正在构建前端..."
cd /root/pve-manager/frontend
npm install > /dev/null 2>&1
npm run build > /dev/null 2>&1

echo "正在配置环境变量..."
cd /root/pve-manager/backend
if [ ! -f .env ]; then
    cat > .env << EOF
DATABASE_URL="file:./database.sqlite"
JWT_SECRET="pve-manager-secret-key-$(date +%s)"
PVE_HOST="your-pve-host"
PVE_USERNAME="root"
PVE_PASSWORD="your-pve-password"
PORT=5000
NODE_ENV=production
EOF
fi

echo "正在启动后端服务..."
cd /root/pve-manager/backend
pm2 delete pve-backend 2>/dev/null || true
pm2 start npm --name "pve-backend" -- run start > /dev/null 2>&1
pm2 save > /dev/null 2>&1

echo "正在配置Nginx..."
cat > /etc/nginx/sites-available/pve-manager << 'EOF'
server {
    listen 80;
    server_name _;
    location / {
        root /root/pve-manager/frontend/dist;
        try_files $uri $uri/ /index.html;
    }
    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF

ln -sf /etc/nginx/sites-available/pve-manager /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t > /dev/null 2>&1 && systemctl reload nginx

echo "正在配置防火墙..."
ufw allow 22/tcp > /dev/null 2>&1
ufw allow 80/tcp > /dev/null 2>&1
ufw allow 443/tcp > /dev/null 2>&1
ufw --force enable > /dev/null 2>&1

echo "正在设置开机自启..."
pm2 startup systemd -u root --hp /root > /dev/null 2>&1

echo "部署完成！"
REMOTE_SCRIPT

chmod +x /tmp/remote_deploy.sh

echo "步骤1: 打包项目代码..."
cd /home/admin/workspace
tar -czf pve-manager.tar.gz pve-manager/ --exclude='node_modules' --exclude='frontend/dist' --exclude='backend/node_modules' --exclude='.git'

echo "步骤2: 上传项目代码到远程服务器..."
# 使用SSH上传（需要手动输入密码）
echo "请输入SSH密码: $REMOTE_PASSWORD"
scp pve-manager.tar.gz $REMOTE_USER@$REMOTE_HOST:/tmp/

echo "步骤3: 在远程服务器上解压项目..."
ssh $REMOTE_USER@$REMOTE_HOST "cd /root && rm -rf pve-manager && tar -xzf /tmp/pve-manager.tar.gz && mv pve-manager /root/"

echo "步骤4: 上传并执行部署脚本..."
scp /tmp/remote_deploy.sh $REMOTE_USER@$REMOTE_HOST:/tmp/
ssh $REMOTE_USER@$REMOTE_HOST "chmod +x /tmp/remote_deploy.sh && /tmp/remote_deploy.sh"

echo ""
echo "=========================================="
echo "  部署完成！"
echo "=========================================="
echo "访问地址: http://$REMOTE_HOST"
echo "默认账号: admin@example.com"
echo "默认密码: admin123"
echo ""
