@echo off
REM PVE管理系统 - Windows快速启动脚本

echo ==========================================
echo PVE Management System - Quick Start
echo ==========================================
echo.

REM 检查Docker是否安装
docker --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Docker is not installed!
    echo Please install Docker Desktop from: https://www.docker.com/products/docker-desktop
    pause
    exit /b 1
)

echo [OK] Docker is installed
echo.

REM 检查docker-compose是否安装
docker-compose --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Docker Compose is not installed!
    echo Please install Docker Compose
    pause
    exit /b 1
)

echo [OK] Docker Compose is installed
echo.

REM 检查.env文件
if not exist .env (
    echo [WARNING] .env file not found!
    echo Creating .env from .env.example...
    copy .env.example .env
    echo.
    echo [IMPORTANT] Please edit .env file and configure your PVE settings!
    echo Open .env file and update at least:
    echo   - PVE_HOST
    echo   - PVE_USERNAME
    echo   - PVE_PASSWORD
    echo   - JWT_SECRET
    echo   - JWT_REFRESH_SECRET
    echo.
    pause
)

echo [OK] .env file exists
echo.

REM 启动服务
echo Starting services...
docker-compose up -d

echo.
echo ==========================================
echo Services are starting...
echo.
echo Access URLs:
echo   - Main Portal:  http://localhost
echo   - Frontend:     http://localhost:3000
echo   - Backend API:  http://localhost:5000
echo   - Grafana:      http://localhost:3001
echo   - Prometheus:   http://localhost:9090
echo.
echo Default Credentials:
echo   - Email:    admin@example.com
echo   - Password: admin123
echo.
echo [IMPORTANT] Please change the default password after first login!
echo ==========================================
echo.
echo To view logs: docker-compose logs -f
echo To stop: docker-compose down
echo.
pause
