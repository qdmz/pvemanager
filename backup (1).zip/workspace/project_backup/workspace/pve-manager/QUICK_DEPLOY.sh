#!/bin/bash

# PVE管理系统一键部署脚本
# 在远程服务器上执行此脚本

set -e

echo "=========================================="
echo "  PVE管理系统一键部署脚本"
echo "=========================================="

# 检查是否为root用户
if [ "$EUID" -ne 0 ]; then 
    echo "请使用root用户执行此脚本"
    exit 1
fi

# 更新系统
echo "正在更新系统..."
apt-get update -qq

# 安装必要工具
echo "正在安装必要工具..."
apt-get install -y curl git nodejs npm nginx ufw > /dev/null 2>&1

# 安装PM2
echo "正在安装PM2..."
npm install -g pm2 > /dev/null 2>&1

# 创建项目目录
PROJECT_DIR="/root/pve-manager"
echo "正在创建项目目录: $PROJECT_DIR"
mkdir -p $PROJECT_DIR
cd $PROJECT_DIR

# 如果项目代码已存在，询问是否更新
if [ -d "backend" ] && [ -d "frontend" ]; then
    echo "检测到项目代码已存在"
    read -p "是否要更新代码? (y/n): " update_code
    if [ "$update_code" = "y" ]; then
        echo "请手动上传新的代码包到 $PROJECT_DIR"
        exit 0
    fi
else
    echo "请先上传项目代码到 $PROJECT_DIR"
    echo "上传完成后，重新执行此脚本"
    exit 1
fi

# 安装后端依赖
echo "正在安装后端依赖..."
cd $PROJECT_DIR/backend
npm install > /dev/null 2>&1

# 生成Prisma客户端
echo "正在生成Prisma客户端..."
npx prisma generate > /dev/null 2>&1

# 运行数据库迁移
echo "正在运行数据库迁移..."
npx prisma migrate deploy > /dev/null 2>&1

# 构建前端
echo "正在构建前端..."
cd $PROJECT_DIR/frontend
npm install > /dev/null 2>&1
npm run build > /dev/null 2>&1

# 配置环境变量
echo "正在配置环境变量..."
cd $PROJECT_DIR/backend
if [ ! -f .env ]; then
    cat > .env << EOF
# 数据库
DATABASE_URL="file:./database.sqlite"

# JWT密钥
JWT_SECRET="pve-manager-secret-key-$(date +%s)"

# PVE连接配置（请修改为实际值）
PVE_HOST="your-pve-host"
PVE_USERNAME="root"
PVE_PASSWORD="your-pve-password"

# 服务器配置
PORT=5000
NODE_ENV=production
EOF
    echo "已创建.env文件，请修改PVE连接配置"
fi

# 启动后端服务
echo "正在启动后端服务..."
cd $PROJECT_DIR/backend
pm2 delete pve-backend 2>/dev/null || true
pm2 start npm --name "pve-backend" -- run start > /dev/null 2>&1
pm2 save > /dev/null 2>&1

# 配置Nginx
echo "正在配置Nginx..."
cat > /etc/nginx/sites-available/pve-manager << 'EOF'
server {
    listen 80;
    server_name _;

    # 前端静态文件
    location / {
        root /root/pve-manager/frontend/dist;
        try_files $uri $uri/ /index.html;
    }

    # 后端API代理
    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF

ln -sf /etc/nginx/sites-available/pve-manager /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t > /dev/null 2>&1 && systemctl reload nginx

# 配置防火墙
echo "正在配置防火墙..."
ufw allow 22/tcp > /dev/null 2>&1
ufw allow 80/tcp > /dev/null 2>&1
ufw allow 443/tcp > /dev/null 2>&1
ufw --force enable > /dev/null 2>&1

# 设置PM2开机自启
echo "正在设置开机自启..."
pm2 startup systemd -u root --hp /root > /dev/null 2>&1

echo ""
echo "=========================================="
echo "  部署完成！"
echo "=========================================="
echo ""
echo "访问地址: http://$(curl -s ifconfig.me)"
echo "默认账号: admin@example.com"
echo "默认密码: admin123"
echo ""
echo "重要提示:"
echo "1. 请修改 /root/pve-manager/backend/.env 中的PVE连接配置"
echo "2. 重启后端服务: pm2 restart pve-backend"
echo "3. 查看后端日志: pm2 logs pve-backend"
echo ""
