# PVE管理系统 - 快速使用指南

## 🚀 5分钟快速部署

### 第一步：配置环境变量

```bash
# 复制环境变量模板
cp .env.example .env

# 编辑配置（至少修改以下几项）
nano .env
```

**必须修改的配置**：
```env
# PVE连接信息
PVE_HOST=你的PVE服务器地址
PVE_USERNAME=root
PVE_PASSWORD=你的PVE密码

# JWT密钥（请使用随机字符串）
JWT_SECRET=随意生成一个长随机字符串
JWT_REFRESH_SECRET=再生成一个长随机字符串
```

### 第二步：一键部署

```bash
# 给脚本添加执行权限
chmod +x install.sh verify-setup.sh

# 运行安装脚本
sudo ./install.sh
```

安装脚本会自动完成所有配置和启动。

### 第三步：验证部署

```bash
# 运行验证脚本
./verify-setup.sh
```

### 第四步：开始使用

打开浏览器访问：http://localhost

默认登录账号：
- 邮箱：admin@example.com
- 密码：admin123

⚠️ **重要：首次登录后立即修改密码！**

---

## 📖 常用操作

### 查看服务状态

```bash
# 查看所有服务
docker-compose ps

# 查看特定服务
docker-compose ps backend
```

### 查看日志

```bash
# 查看所有服务日志
docker-compose logs

# 查看后端日志
docker-compose logs backend

# 实时跟踪日志
docker-compose logs -f backend

# 查看最近100行
docker-compose logs --tail=100 backend
```

### 重启服务

```bash
# 重启所有服务
docker-compose restart

# 重启特定服务
docker-compose restart backend
```

### 停止服务

```bash
# 停止所有服务（保留数据）
docker-compose down

# 停止并删除数据卷（⚠️ 会丢失数据）
docker-compose down -v
```

### 更新系统

```bash
# 拉取最新代码
git pull

# 重新构建并启动
docker-compose up -d --build

# 运行数据库迁移
docker-compose exec backend npx prisma migrate deploy
```

---

## 🖥️ 创建第一个虚拟机

1. 登录系统后，点击左侧菜单"虚拟机管理"
2. 点击"创建虚拟机"按钮
3. 填写配置信息：
   - 名称：test-vm
   - 节点：选择你的PVE节点
   - CPU核心：2
   - 内存：4096 MB
   - 磁盘：50 GB
   - 操作系统：Linux
   - 存储：local-lvm
4. 点击"创建"
5. 等待创建完成后，点击"启动"按钮

---

## 👥 创建第一个用户

1. 点击左侧菜单"用户管理"
2. 点击"创建用户"按钮
3. 填写用户信息：
   - 用户名：demo
   - 邮箱：demo@example.com
   - 密码：demo123
   - 角色：用户
   - VM配额：3
4. 点击"创建"

---

## 🔑 创建API密钥

1. 点击右上角用户头像，选择"个人设置"
2. 进入"API密钥"标签页
3. 点击"创建API密钥"
4. 填写信息：
   - 名称：my-key
   - 权限：选择需要的权限
   - 有效期：30天
5. 点击"生成"
6. **重要**：复制并保存API密钥，只显示一次！

---

## 🔒 配置防火墙规则

1. 进入"虚拟机管理"，选择一个虚拟机
2. 进入"防火墙规则"标签
3. 点击"创建规则"
4. 填写规则：
   - 类型：in（入站）或out（出站）
   - 动作：ACCEPT（接受）或DROP（拒绝）
   - 协议：tcp、udp或any
   - 源地址：IP地址或CIDR
   - 目标端口：端口号
5. 点击"创建"

---

## 🔀 配置端口转发

1. 进入"虚拟机管理"，选择一个虚拟机
2. 进入"端口转发"标签
3. 点击"创建端口转发"
4. 填写信息：
   - 协议：TCP或UDP
   - 源端口：外部端口号
   - 目标IP：虚拟机IP地址
   - 目标端口：虚拟机端口号
5. 点击"创建"

---

## 📸 创建快照

1. 进入"虚拟机管理"，选择一个虚拟机
2. 进入"快照"标签
3. 点击"创建快照"
4. 输入快照名称和描述
5. 点击"创建"

---

## 🔄 恢复快照

1. 进入"虚拟机管理"，选择一个虚拟机
2. 进入"快照"标签
3. 找到要恢复的快照
4. 点击"恢复"按钮
5. 确认操作

---

## 📊 查看监控数据

### Grafana监控

访问：http://localhost:3001
- 默认账号：admin
- 默认密码：admin
- 首次登录后修改密码

### Prometheus查询

访问：http://localhost:9090
- 输入查询语句
- 查看指标图表

---

## 🐛 常见问题

### 无法访问系统

```bash
# 检查服务状态
docker-compose ps

# 查看错误日志
docker-compose logs

# 重启服务
docker-compose restart
```

### 无法连接到PVE

1. 检查 `.env` 文件中的PVE配置
2. 测试PVE连接：
   ```bash
   curl -k https://your-pve-host:8006/api2/json/access/ticket \
     -d "username=root&password=your-password"
   ```
3. 检查网络连通性：
   ```bash
   ping your-pve-host
   ```

### 数据库连接失败

```bash
# 检查PostgreSQL状态
docker-compose ps postgres

# 查看PostgreSQL日志
docker-compose logs postgres

# 重启PostgreSQL
docker-compose restart postgres
```

### 虚拟机创建失败

1. 检查PVE节点状态
2. 检查存储空间
3. 查看后端日志：
   ```bash
   docker-compose logs backend
   ```

---

## 💡 最佳实践

1. **安全**
   - 修改所有默认密码
   - 定期更新系统
   - 配置防火墙规则
   - 启用HTTPS（生产环境）

2. **备份**
   - 定期备份数据库
   - 备份配置文件
   - 测试恢复流程

3. **监控**
   - 监控资源使用
   - 设置告警规则
   - 定期查看日志

4. **优化**
   - 定期清理日志
   - 优化数据库查询
   - 配置缓存

---

## 📚 更多文档

- **完整设计文档**：PVE管理系统完整设计方案.md
- **部署指南**：DEPLOYMENT.md
- **检查清单**：CHECKLIST.md
- **项目完成总结**：PROJECT_COMPLETION.md

---

## 🆘 获取帮助

```bash
# 查看所有可用命令
docker-compose --help

# 查看特定服务帮助
docker-compose logs --help

# 验证系统状态
./verify-setup.sh
```

---

**祝你使用愉快！** 🎉
