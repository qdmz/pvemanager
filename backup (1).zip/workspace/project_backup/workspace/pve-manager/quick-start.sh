#!/bin/bash

# Quick Start Script for Development

echo "🚀 Quick Start - PVE Management System"
echo ""

# Start services
echo "Starting services..."
docker-compose up -d

echo ""
echo "⏳ Waiting for services to start..."
sleep 10

echo ""
echo "✅ Services are starting..."
echo ""
echo "Access URLs:"
echo "  • Frontend:  http://localhost:3000"
echo "  • Backend:   http://localhost:5000"
echo "  • Grafana:   http://localhost:3001"
echo ""
echo "To view logs: docker-compose logs -f"
