#!/bin/bash

# PVE Management System - Setup Verification Script

echo "=========================================="
echo "PVE Management System Setup Verification"
echo "=========================================="
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

success_count=0
fail_count=0

check_service() {
    service_name=$1
    service_url=$2

    echo -n "Checking $service_name... "

    if curl -s -o /dev/null -w "%{http_code}" "$service_url" | grep -q "200\|404"; then
        echo -e "${GREEN}✓ OK${NC}"
        ((success_count++))
        return 0
    else
        echo -e "${RED}✗ FAILED${NC}"
        ((fail_count++))
        return 1
    fi
}

check_docker_container() {
    container_name=$1

    echo -n "Checking Docker container $container_name... "

    if docker ps --format '{{.Names}}' | grep -q "^${container_name}$"; then
        echo -e "${GREEN}✓ Running${NC}"
        ((success_count++))
        return 0
    else
        echo -e "${RED}✗ Not Running${NC}"
        ((fail_count++))
        return 1
    fi
}

check_file() {
    file_path=$1
    file_description=$2

    echo -n "Checking $file_description... "

    if [ -f "$file_path" ]; then
        echo -e "${GREEN}✓ Exists${NC}"
        ((success_count++))
        return 0
    else
        echo -e "${RED}✗ Missing${NC}"
        ((fail_count++))
        return 1
    fi
}

check_directory() {
    dir_path=$1
    dir_description=$2

    echo -n "Checking $dir_description... "

    if [ -d "$dir_path" ]; then
        echo -e "${GREEN}✓ Exists${NC}"
        ((success_count++))
        return 0
    else
        echo -e "${RED}✗ Missing${NC}"
        ((fail_count++))
        return 1
    fi
}

echo "1. Checking Docker Services..."
echo "----------------------------"

check_docker_container "pve-manager-frontend"
check_docker_container "pve-manager-backend"
check_docker_container "pve-manager-postgres"
check_docker_container "pve-manager-redis"
check_docker_container "pve-manager-nginx"

echo ""
echo "2. Checking Service Endpoints..."
echo "----------------------------"

check_service "Frontend" "http://localhost:3000"
check_service "Backend" "http://localhost:5000/health"
check_service "Nginx" "http://localhost"

echo ""
echo "3. Checking Required Files..."
echo "----------------------------"

check_file ".env" "Environment configuration file"
check_file "docker-compose.yml" "Docker Compose configuration"
check_file "frontend/Dockerfile" "Frontend Dockerfile"
check_file "backend/Dockerfile" "Backend Dockerfile"

echo ""
echo "4. Checking Required Directories..."
echo "----------------------------"

check_directory "backend/logs" "Backend logs directory"
check_directory "backend/uploads" "Backend uploads directory"
check_directory "monitoring/grafana/provisioning" "Grafana provisioning directory"
check_directory "monitoring/prometheus" "Prometheus configuration directory"

echo ""
echo "5. Checking Optional Services..."
echo "----------------------------"

if curl -s -o /dev/null -w "%{http_code}" "http://localhost:3001" | grep -q "200\|302"; then
    echo -e "${GREEN}✓ Grafana is accessible${NC}"
    ((success_count++))
else
    echo -e "${YELLOW}⚠ Grafana is not accessible (optional)${NC}"
fi

if curl -s -o /dev/null -w "%{http_code}" "http://localhost:9090" | grep -q "200\|404"; then
    echo -e "${GREEN}✓ Prometheus is accessible${NC}"
    ((success_count++))
else
    echo -e "${YELLOW}⚠ Prometheus is not accessible (optional)${NC}"
fi

echo ""
echo "6. Checking Docker Volumes..."
echo "----------------------------"

if docker volume ls | grep -q "pvemanager_postgres_data"; then
    echo -e "${GREEN}✓ PostgreSQL data volume exists${NC}"
    ((success_count++))
else
    echo -e "${RED}✗ PostgreSQL data volume missing${NC}"
    ((fail_count++))
fi

if docker volume ls | grep -q "pvemanager_redis_data"; then
    echo -e "${GREEN}✓ Redis data volume exists${NC}"
    ((success_count++))
else
    echo -e "${RED}✗ Redis data volume missing${NC}"
    ((fail_count++))
fi

echo ""
echo "=========================================="
echo "Verification Summary"
echo "=========================================="
echo -e "${GREEN}Passed: $success_count${NC}"
echo -e "${RED}Failed: $fail_count${NC}"
echo ""

if [ $fail_count -eq 0 ]; then
    echo -e "${GREEN}✓ All checks passed! System is ready to use.${NC}"
    echo ""
    echo "Access URLs:"
    echo "  • Main Portal: http://localhost"
    echo "  • Frontend:    http://localhost:3000"
    echo "  • Backend API: http://localhost:5000"
    echo "  • Grafana:     http://localhost:3001"
    echo "  • Prometheus:  http://localhost:9090"
    echo ""
    echo "Default Credentials:"
    echo "  • Email:    admin@example.com"
    echo "  • Password: admin123"
    exit 0
else
    echo -e "${RED}✗ Some checks failed. Please review the errors above.${NC}"
    echo ""
    echo "Troubleshooting:"
    echo "  • Check logs: docker-compose logs [service]"
    echo "  • Restart services: docker-compose restart"
    echo "  • View detailed setup guide: DEPLOYMENT.md"
    exit 1
fi
