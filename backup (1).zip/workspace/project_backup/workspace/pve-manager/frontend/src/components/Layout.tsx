import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';

const Layout = ({ children }: { children: React.ReactNode }) => {
  const { user, logout } = useAuthStore();
  const location = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
  };

  const navItems = [
    { id: 'dashboard', label: '仪表盘', path: '/', icon: '🏠' },
    { id: 'vms', label: '虚拟机管理', path: '/vms', icon: '🖥️' },
    { id: 'nodes', label: '节点管理', path: '/nodes', icon: '🏢' },
    { id: 'firewall-rules', label: '防火墙规则', path: '/firewall-rules', icon: '🔒' },
    { id: 'port-forwards', label: '端口转发', path: '/port-forwards', icon: '🔄' },
    { id: 'api-keys', label: 'API凭证', path: '/api-keys', icon: '🔑' },
    { id: 'logs', label: '操作日志', path: '/logs', icon: '📋' },
    ...(user?.role === 'ADMIN' ? [{ id: 'admin', label: '用户管理', path: '/admin', icon: '👥' }] : [])
  ];

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <div className="layout">
      {/* Mobile menu button */}
      <button
        className="mobile-menu-button"
        onClick={() => setIsMobileOpen(!isMobileOpen)}
      >
        <span className="menu-icon">☰</span>
      </button>

      {/* Mobile overlay */}
      {isMobileOpen && (
        <div 
          className="mobile-overlay"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside 
        className={`sidebar ${isMobileOpen ? 'mobile-open' : ''} ${isCollapsed ? 'collapsed' : ''}`}
      >
        <div className="sidebar-content">
          {/* Header */}
          <div className="sidebar-header">
            {!isCollapsed && (
              <div className="sidebar-title-container">
                <div className="sidebar-logo">
                  <span className="logo-icon">🖥️</span>
                </div>
                <span className="sidebar-title">PVE管理系统</span>
              </div>
            )}
            <button
              className={`sidebar-toggle ${isCollapsed ? 'toggle-collapsed' : ''}`}
              onClick={() => setIsCollapsed(!isCollapsed)}
            >
              <span className="toggle-icon">{isCollapsed ? '➡️' : '⬅️'}</span>
            </button>
          </div>

          {/* Navigation */}
          <nav className="sidebar-nav">
            <ul className="nav-list">
              {navItems.map(item => (
                <li key={item.id} className="nav-item">
                  <Link 
                    to={item.path} 
                    className={`nav-link ${isActive(item.path) ? 'active' : ''} ${isCollapsed ? 'collapsed' : ''}`}
                    onClick={() => setIsMobileOpen(false)}
                  >
                    <span className="nav-icon">{item.icon}</span>
                    {!isCollapsed && <span className="nav-label">{item.label}</span>}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* Footer */}
          <div className="sidebar-footer">
            {!isCollapsed && (
              <div className="sidebar-user-info">
                <div className="user-details">
                  <div className="user-name">{user?.username}</div>
                  <div className="user-role">{user?.role === 'ADMIN' ? '管理员' : '用户'}</div>
                </div>
                <button 
                  className="logout-button"
                  onClick={handleLogout}
                >
                  退出登录
                </button>
              </div>
            )}
            {isCollapsed && (
              <div className="sidebar-user-info collapsed">
                <div className="user-avatar">
                  {user?.username?.charAt(0)?.toUpperCase() || 'U'}
                </div>
                <button 
                  className="logout-button collapsed"
                  onClick={handleLogout}
                  title="退出登录"
                >
                  <span className="logout-icon">❌</span>
                </button>
              </div>
            )}
            {!isCollapsed && (
              <div className="sidebar-version">
                PVE用户API管理系统 v1.0.0
              </div>
            )}
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`main-content ${isCollapsed ? 'collapsed' : ''}`}>
        {/* Header */}
        <header className="main-header">
          <div className="header-content">
            <h1 className="header-title">
              {navItems.find(item => isActive(item.path))?.label || 'PVE管理系统'}
            </h1>
          </div>
          <div className="header-actions">
            <button className="header-action-button">
              <span className="action-icon">🔍</span>
            </button>
            <button className="header-action-button">
              <span className="action-icon">🔔</span>
            </button>
          </div>
        </header>

        {/* Content */}
        <div className="content">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;