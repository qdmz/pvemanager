export interface User {
  id: string;
  email: string;
  username: string;
  role: 'ADMIN' | 'USER';
  status: 'ACTIVE' | 'INACTIVE' | 'PENDING';
  vmQuota: number;
  vmCount: number;
  createdAt: string;
  updatedAt: string;
  lastLoginAt?: string;
  emailVerified: boolean;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  email: string;
  username: string;
  password: string;
  confirmPassword: string;
}

export interface AuthResponse {
  user: User;
  accessToken: string;
  refreshToken: string;
}

export interface ErrorResponse {
  error: string;
  details?: unknown;
}

export interface ApiKey {
  id: string;
  name: string;
  key: string;
  permissions: string[];
  status: 'ACTIVE' | 'REVOKED' | 'EXPIRED';
  createdAt: string;
  updatedAt: string;
  lastUsedAt?: string;
  expiresAt?: string;
}

export interface VirtualMachine {
  id: string;
  name: string;
  node: string;
  vmid: number;
  status: 'RUNNING' | 'STOPPED' | 'PAUSED' | 'SUSPENDED' | 'UNKNOWN';
  cpus: number;
  memory: number;
  disk: number;
  storage: string;
  ip?: string;
  mac?: string;
  osType: string;
  description?: string;
  config?: Record<string, unknown>;
  userId: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  user: {
    username: string;
    email: string;
  };
  action: string;
  resource: string;
  resourceId: string;
  status: 'SUCCESS' | 'FAILED' | 'PENDING';
  message?: string;
  ip: string;
  userAgent?: string;
  duration?: number;
  createdAt: string;
}

export interface Node {
  id: string;
  name: string;
  host: string;
  port: number;
  username: string;
  password?: string;
  tokenId?: string;
  tokenSecret?: string;
  status: 'ACTIVE' | 'INACTIVE' | 'ERROR';
  description?: string;
  apiVersion?: string;
  uptime?: number;
  memoryTotal?: number;
  memoryUsed?: number;
  cpuUsage?: number;
  createdAt: string;
  updatedAt: string;
}

export interface FirewallRule {
  id: string;
  vmId: string;
  position: number;
  action: 'ACCEPT' | 'DROP' | 'REJECT';
  protocol: 'TCP' | 'UDP' | 'ICMP' | 'ANY';
  source?: string;
  destination?: string;
  dport?: number;
  sport?: number;
  comment?: string;
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface PortForward {
  id: string;
  vmId: string;
  protocol: 'TCP' | 'UDP' | 'BOTH';
  sourcePort: number;
  destinationPort: number;
  destinationIp: string;
  comment?: string;
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
}
