import axios from 'axios';
import type { User } from '../types';

const api = axios.create({
  baseURL: '/api/users',
  headers: {
    'Content-Type': 'application/json',
  },
});

// 添加请求拦截器，自动添加token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const userService = {
  // 获取所有用户
  async getUsers(params?: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    role?: string;
  }): Promise<{
    users: User[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      pages: number;
    };
  }> {
    const response = await api.get('/', { params });
    return response.data;
  },

  // 获取单个用户
  async getUser(id: string): Promise<{ user: User }> {
    const response = await api.get(`/${id}`);
    return response.data;
  },

  // 更新用户
  async updateUser(id: string, data: {
    username?: string;
    email?: string;
    role?: 'ADMIN' | 'USER';
    status?: 'ACTIVE' | 'INACTIVE' | 'PENDING';
    vmQuota?: number;
  }): Promise<{ message: string; user: User }> {
    const response = await api.put(`/${id}`, data);
    return response.data;
  },

  // 删除用户
  async deleteUser(id: string): Promise<{ message: string }> {
    const response = await api.delete(`/${id}`);
    return response.data;
  },

  // 批量更新用户状态
  async bulkUpdateUsers(ids: string[], data: {
    status?: 'ACTIVE' | 'INACTIVE' | 'PENDING';
    role?: 'ADMIN' | 'USER';
  }): Promise<{ message: string; updatedCount: number }> {
    const response = await api.put('/bulk', { ids, data });
    return response.data;
  },

  // 获取用户统计
  async getUserStats(): Promise<{
    total: number;
    active: number;
    inactive: number;
    pending: number;
    admins: number;
    users: number;
  }> {
    try {
      const response = await api.get('/stats');
      return response.data;
    } catch (error) {
      // 如果后端没有实现/stats端点，返回默认值
      return {
        total: 0,
        active: 0,
        inactive: 0,
        pending: 0,
        admins: 0,
        users: 0
      };
    }
  },
};