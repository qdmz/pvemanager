import axios from 'axios';

const api = axios.create({
  baseURL: '/api/firewall-rules',
  headers: {
    'Content-Type': 'application/json',
  },
});

// 添加请求拦截器，自动添加token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const firewallRulesService = {
  // 获取指定VM的所有防火墙规则
  async getVMRules(vmId: string, params?: {
    page?: number;
    limit?: number;
  }): Promise<{
    rules: any[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      pages: number;
    };
  }> {
    const response = await api.get(`/vm/${vmId}`, { params });
    return response.data;
  },

  // 获取所有防火墙规则（管理员）
  async getAllRules(params?: {
    page?: number;
    limit?: number;
    vmId?: string;
  }): Promise<{
    rules: any[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      pages: number;
    };
  }> {
    const response = await api.get('/', { params });
    return response.data;
  },

  // 获取单个防火墙规则
  async getRule(id: string): Promise<{ rule: any }> {
    const response = await api.get(`/${id}`);
    return response.data;
  },

  // 创建防火墙规则
  async createRule(data: {
    vmId: string;
    type: 'in' | 'out';
    action: 'ACCEPT' | 'DROP' | 'REJECT';
    protocol: 'tcp' | 'udp' | 'icmp' | 'any';
    source?: string;
    sourcePort?: string;
    dest?: string;
    destPort?: string;
    comment?: string;
    enabled?: boolean;
  }): Promise<{ message: string; rule: any }> {
    const response = await api.post('/', data);
    return response.data;
  },

  // 更新防火墙规则
  async updateRule(id: string, data: {
    type?: 'in' | 'out';
    action?: 'ACCEPT' | 'DROP' | 'REJECT';
    protocol?: 'tcp' | 'udp' | 'icmp' | 'any';
    source?: string;
    sourcePort?: string;
    dest?: string;
    destPort?: string;
    comment?: string;
    enabled?: boolean;
    pos?: number;
  }): Promise<{ message: string; rule: any }> {
    const response = await api.put(`/${id}`, data);
    return response.data;
  },

  // 删除防火墙规则
  async deleteRule(id: string): Promise<{ message: string }> {
    const response = await api.delete(`/${id}`);
    return response.data;
  },

  // 切换防火墙规则启用状态
  async toggleRuleStatus(id: string): Promise<{ message: string; rule: any }> {
    const response = await api.post(`/${id}/toggle`);
    return response.data;
  },
};
