import axios from 'axios';
import type { ApiKey } from '../types';

const api = axios.create({
  baseURL: '/api/api-keys',
  headers: {
    'Content-Type': 'application/json',
  },
});

// 添加请求拦截器，自动添加token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const apiKeysService = {
  // 获取所有API密钥
  async getApiKeys(params?: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
  }): Promise<{
    apiKeys: ApiKey[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      pages: number;
    };
  }> {
    const response = await api.get('/', { params });
    return response.data;
  },

  // 创建API密钥
  async createApiKey(data: {
    name: string;
    permissions: string[];
    expiresAt?: Date;
  }): Promise<{ message: string; apiKey: ApiKey }> {
    const response = await api.post('/', data);
    return response.data;
  },

  // 撤销API密钥
  async revokeApiKey(id: string): Promise<{ message: string }> {
    const response = await api.delete(`/${id}`);
    return response.data;
  },

  // 获取API密钥使用统计
  async getApiKeyStats(): Promise<{
    total: number;
    active: number;
    revoked: number;
    expired: number;
  }> {
    try {
      const response = await api.get('/stats');
      return response.data;
    } catch (error) {
      // 如果后端没有实现/stats端点，返回默认值
      return {
        total: 0,
        active: 0,
        revoked: 0,
        expired: 0
      };
    }
  },
};