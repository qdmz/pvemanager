import axios from 'axios';

const api = axios.create({
  baseURL: '/api/admin/nodes',
  headers: {
    'Content-Type': 'application/json',
  },
});

// 添加请求拦截器，自动添加token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const nodeService = {
  // 获取所有PVE节点
  async getNodes(): Promise<{ nodes: any[] }> {
    const response = await api.get('/');
    return response.data;
  },

  // 获取单个PVE节点
  async getNode(id: string): Promise<{ node: any }> {
    const response = await api.get(`/${id}`);
    return response.data;
  },

  // 创建PVE节点
  async createNode(data: {
    name: string;
    host: string;
    port?: number;
    username: string;
    password: string;
    realm?: string;
    description?: string;
  }): Promise<{ message: string; node: any }> {
    const response = await api.post('/', data);
    return response.data;
  },

  // 更新PVE节点
  async updateNode(id: string, data: {
    host?: string;
    port?: number;
    username?: string;
    password?: string;
    realm?: string;
  }): Promise<{ message: string; node: any }> {
    const response = await api.put(`/${id}`, data);
    return response.data;
  },

  // 删除PVE节点
  async deleteNode(id: string): Promise<{ message: string }> {
    const response = await api.delete(`/${id}`);
    return response.data;
  },

  // 更新节点状态
  async updateNodeStatus(id: string): Promise<{ message: string }> {
    const response = await api.post(`/${id}/update-status`);
    return response.data;
  },
};
