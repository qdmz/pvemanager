import axios from 'axios';
import type { AuthResponse, User } from '../types';

const API_BASE_URL = import.meta.env.VITE_API_URL || '/api';

const api = axios.create({
  baseURL: `${API_BASE_URL}/auth`,
  headers: {
    'Content-Type': 'application/json',
  },
});

// 添加请求拦截器，自动添加token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const authService = {
  async login(email: string, password: string): Promise<AuthResponse> {
    const response = await api.post<AuthResponse>('/login', { email, password });
    return response.data;
  },

  async register(
    email: string,
    username: string,
    password: string,
    confirmPassword: string
  ): Promise<AuthResponse> {
    const response = await api.post<AuthResponse>('/register', {
      email,
      username,
      password,
      confirmPassword,
    });
    return response.data;
  },

  async logout(): Promise<void> {
    await api.post('/logout');
  },

  async refresh(refreshToken: string): Promise<{ accessToken: string }> {
    const response = await api.post<{ accessToken: string }>('/refresh', {
      refreshToken,
    });
    return response.data;
  },

  async getProfile(): Promise<{ user: User }> {
    const response = await api.get('/profile');
    return response.data;
  },

  async updateProfile(data: { username?: string }): Promise<{ user: User }> {
    const response = await api.put('/profile', data);
    return response.data;
  },

  async changePassword(
    currentPassword: string,
    newPassword: string,
    confirmPassword: string
  ): Promise<{ message: string }> {
    const response = await api.put('/password', {
      currentPassword,
      newPassword,
      confirmPassword,
    });
    return response.data;
  },
};
