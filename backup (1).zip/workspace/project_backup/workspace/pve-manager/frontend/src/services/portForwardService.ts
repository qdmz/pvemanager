import axios from 'axios';

const api = axios.create({
  baseURL: '/api/port-forwards',
  headers: {
    'Content-Type': 'application/json',
  },
});

// 添加请求拦截器，自动添加token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const portForwardService = {
  // 获取指定VM的所有端口转发
  async getVMPortForwards(vmId: string, params?: {
    page?: number;
    limit?: number;
  }): Promise<{
    portForwards: any[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      pages: number;
    };
  }> {
    const response = await api.get(`/vm/${vmId}`, { params });
    return response.data;
  },

  // 获取所有端口转发（管理员）
  async getAllPortForwards(params?: {
    page?: number;
    limit?: number;
    vmId?: string;
    enabled?: boolean;
  }): Promise<{
    portForwards: any[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      pages: number;
    };
  }> {
    const response = await api.get('/', { params });
    return response.data;
  },

  // 获取单个端口转发
  async getPortForward(id: string): Promise<{ portForward: any }> {
    const response = await api.get(`/${id}`);
    return response.data;
  },

  // 创建端口转发
  async createPortForward(data: {
    vmId: string;
    name: string;
    protocol: 'tcp' | 'udp';
    sourcePort: number;
    destIP: string;
    destPort: number;
    comment?: string;
    enabled?: boolean;
  }): Promise<{ message: string; portForward: any }> {
    const response = await api.post('/', data);
    return response.data;
  },

  // 更新端口转发
  async updatePortForward(id: string, data: {
    name?: string;
    protocol?: 'tcp' | 'udp';
    sourcePort?: number;
    destIP?: string;
    destPort?: number;
    comment?: string;
    enabled?: boolean;
  }): Promise<{ message: string; portForward: any }> {
    const response = await api.put(`/${id}`, data);
    return response.data;
  },

  // 删除端口转发
  async deletePortForward(id: string): Promise<{ message: string }> {
    const response = await api.delete(`/${id}`);
    return response.data;
  },

  // 切换端口转发启用状态
  async togglePortForwardStatus(id: string): Promise<{ message: string; portForward: any }> {
    const response = await api.post(`/${id}/toggle`);
    return response.data;
  },
};
