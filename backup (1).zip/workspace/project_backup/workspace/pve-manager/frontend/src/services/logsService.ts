import axios from 'axios';
import type { AuditLog } from '../types';

const api = axios.create({
  baseURL: '/api/logs',
  headers: {
    'Content-Type': 'application/json',
  },
});

// 添加请求拦截器，自动添加token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export const logsService = {
  // 获取所有操作日志
  async getLogs(params?: {
    page?: number;
    limit?: number;
    search?: string;
    action?: string;
    resource?: string;
    status?: string;
    startDate?: string;
    endDate?: string;
  }): Promise<{
    logs: AuditLog[];
    pagination: {
      page: number;
      limit: number;
      total: number;
      pages: number;
    };
  }> {
    const response = await api.get('/', { params });
    return response.data;
  },

  // 获取单个操作日志
  async getLog(id: string): Promise<{ log: AuditLog }> {
    const response = await api.get(`/${id}`);
    return response.data;
  },

  // 导出操作日志
  async exportLogs(params?: {
    action?: string;
    resource?: string;
    status?: string;
    startDate?: string;
    endDate?: string;
  }): Promise<Blob> {
    const response = await api.get('/export', {
      params,
      responseType: 'blob',
    });
    return response.data;
  },

  // 获取日志统计
  async getLogStats(params?: {
    startDate?: string;
    endDate?: string;
  }): Promise<{
    total: number;
    success: number;
    failed: number;
    byAction: Record<string, number>;
  }> {
    try {
      const response = await api.get('/stats', { params });
      return response.data;
    } catch (error) {
      // 如果后端没有实现/stats端点，返回默认值
      return {
        total: 0,
        success: 0,
        failed: 0,
        byAction: {}
      };
    }
  },
};