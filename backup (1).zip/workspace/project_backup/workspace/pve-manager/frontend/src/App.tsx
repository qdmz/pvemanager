import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import VMPage from './pages/VMPage';
import ApiKeysPage from './pages/ApiKeysPage';
import LogsPage from './pages/LogsPage';
import AdminPage from './pages/AdminPage';
import NodesPage from './pages/NodesPage';
import FirewallRulesPage from './pages/FirewallRulesPage';
import PortForwardsPage from './pages/PortForwardsPage';
import SettingsPage from './pages/SettingsPage';
import { useAuthStore } from './store/authStore';
import Layout from './components/Layout';
import './App.css';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <AppContent />
      </Router>
    </QueryClientProvider>
  );
}

function AppContent() {
  const { isLoading } = useAuthStore();

  if (isLoading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      
      {/* Protected Routes */}
      <Route 
        path="/" 
        element={
          <RequireAuth>
            <Layout>
              <DashboardPage />
            </Layout>
          </RequireAuth>
        } 
      />
      <Route 
        path="/vms" 
        element={
          <RequireAuth>
            <Layout>
              <VMPage />
            </Layout>
          </RequireAuth>
        } 
      />
      <Route 
        path="/api-keys" 
        element={
          <RequireAuth>
            <Layout>
              <ApiKeysPage />
            </Layout>
          </RequireAuth>
        } 
      />
      <Route 
        path="/logs" 
        element={
          <RequireAuth>
            <Layout>
              <LogsPage />
            </Layout>
          </RequireAuth>
        } 
      />
      <Route 
        path="/admin" 
        element={
          <RequireAuth>
            <Layout>
              <AdminPage />
            </Layout>
          </RequireAuth>
        } 
      />
      
      <Route 
        path="/nodes" 
        element={
          <RequireAuth>
            <Layout>
              <NodesPage />
            </Layout>
          </RequireAuth>
        } 
      />
      
      <Route 
        path="/firewall-rules" 
        element={
          <RequireAuth>
            <Layout>
              <FirewallRulesPage />
            </Layout>
          </RequireAuth>
        } 
      />
      
      <Route 
        path="/port-forwards" 
        element={
          <RequireAuth>
            <Layout>
              <PortForwardsPage />
            </Layout>
          </RequireAuth>
        } 
      />
      
      <Route 
        path="/settings" 
        element={
          <RequireAuth>
            <Layout>
              <SettingsPage />
            </Layout>
          </RequireAuth>
        } 
      />
      
      {/* Redirect to login if no route matches */}
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}

// Protected Route Component
function RequireAuth({ children }: { children: React.ReactNode }) {
  const { user } = useAuthStore();
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  return children;
}

export default App;