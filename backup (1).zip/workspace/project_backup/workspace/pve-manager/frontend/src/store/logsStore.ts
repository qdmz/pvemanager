import { create } from 'zustand';
import { logsService } from '../services/logsService';
import type { AuditLog } from '../types';

interface LogState {
  logs: AuditLog[];
  loading: boolean;
  error: string | null;
  pagination: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
  stats: {
    total: number;
    success: number;
    failed: number;
    byAction: Record<string, number>;
  };
  fetchLogs: (params?: {
    page?: number;
    limit?: number;
    search?: string;
    action?: string;
    resource?: string;
    status?: string;
    startDate?: string;
    endDate?: string;
  }) => Promise<void>;
  fetchLogStats: (params?: {
    startDate?: string;
    endDate?: string;
  }) => Promise<void>;
  exportLogs: (params?: {
    action?: string;
    resource?: string;
    status?: string;
    startDate?: string;
    endDate?: string;
  }) => Promise<void>;
  clearError: () => void;
}

export const useLogsStore = create<LogState>((set) => ({
  logs: [],
  loading: false,
  error: null,
  pagination: {
    page: 1,
    limit: 20,
    total: 0,
    pages: 0
  },
  stats: {
    total: 0,
    success: 0,
    failed: 0,
    byAction: {}
  },

  fetchLogs: async (params) => {
    set({ loading: true, error: null });
    try {
      const response = await logsService.getLogs(params);
      set({
        logs: response.logs,
        pagination: response.pagination,
        loading: false
      });
    } catch (error) {
      set({ 
        error: 'Failed to fetch logs', 
        loading: false 
      });
    }
  },

  fetchLogStats: async (params) => {
    try {
      const stats = await logsService.getLogStats(params);
      set({ stats });
    } catch (error) {
      console.error('Failed to fetch log stats:', error);
    }
  },

  exportLogs: async (params) => {
    set({ loading: true, error: null });
    try {
      const blob = await logsService.exportLogs(params);
      // 创建下载链接
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `logs-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      set({ loading: false });
    } catch (error) {
      set({ 
        error: 'Failed to export logs', 
        loading: false 
      });
    }
  },

  clearError: () => {
    set({ error: null });
  }
}));