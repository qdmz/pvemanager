import { create } from 'zustand';
import { firewallRulesService } from '../services/firewallRulesService';
import type { FirewallRule } from '../types';

interface FirewallRulesState {
  rules: FirewallRule[];
  isLoading: boolean;
  error: string | null;
  getVMRules: (vmId: string) => Promise<void>;
  getAllRules: () => Promise<void>;
  createRule: (rule: Omit<FirewallRule, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  updateRule: (id: string, rule: Partial<FirewallRule>) => Promise<void>;
  deleteRule: (id: string) => Promise<void>;
  toggleRuleStatus: (id: string) => Promise<void>;
  clearError: () => void;
}

export const useFirewallRulesStore = create<FirewallRulesState>((set, get) => ({
  rules: [],
  isLoading: false,
  error: null,

  getVMRules: async (vmId) => {
    set({ isLoading: true, error: null });
    try {
      const rules = await firewallRulesService.getVMRules(vmId);
      set({ rules, isLoading: false });
    } catch {
      set({ error: '获取虚拟机防火墙规则失败', isLoading: false });
    }
  },

  getAllRules: async () => {
    set({ isLoading: true, error: null });
    try {
      const rules = await firewallRulesService.getAllRules();
      set({ rules, isLoading: false });
    } catch {
      set({ error: '获取所有防火墙规则失败', isLoading: false });
    }
  },

  createRule: async (rule) => {
    set({ isLoading: true, error: null });
    try {
      const newRule = await firewallRulesService.createRule(rule);
      set({ rules: [...get().rules, newRule], isLoading: false });
    } catch {
      set({ error: '创建防火墙规则失败', isLoading: false });
    }
  },

  updateRule: async (id, rule) => {
    set({ isLoading: true, error: null });
    try {
      const updatedRule = await firewallRulesService.updateRule(id, rule);
      set({ 
        rules: get().rules.map(r => r.id === id ? updatedRule : r), 
        isLoading: false 
      });
    } catch {
      set({ error: '更新防火墙规则失败', isLoading: false });
    }
  },

  deleteRule: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await firewallRulesService.deleteRule(id);
      set({ 
        rules: get().rules.filter(r => r.id !== id), 
        isLoading: false 
      });
    } catch {
      set({ error: '删除防火墙规则失败', isLoading: false });
    }
  },

  toggleRuleStatus: async (id) => {
    set({ isLoading: true, error: null });
    try {
      const updatedRule = await firewallRulesService.toggleRuleStatus(id);
      set({ 
        rules: get().rules.map(r => r.id === id ? updatedRule : r), 
        isLoading: false 
      });
    } catch {
      set({ error: '切换防火墙规则状态失败', isLoading: false });
    }
  },

  clearError: () => {
    set({ error: null });
  }
}));
