import { create } from 'zustand';
import { nodeService } from '../services/nodeService';
import type { Node } from '../types';

interface NodeState {
  nodes: Node[];
  isLoading: boolean;
  error: string | null;
  getNodes: () => Promise<void>;
  createNode: (node: Omit<Node, 'id' | 'status'>) => Promise<void>;
  updateNode: (id: string, node: Partial<Node>) => Promise<void>;
  deleteNode: (id: string) => Promise<void>;
  updateNodeStatus: (id: string, status: Node['status']) => Promise<void>;
  clearError: () => void;
}

export const useNodeStore = create<NodeState>((set, get) => ({
  nodes: [],
  isLoading: false,
  error: null,

  getNodes: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await nodeService.getNodes();
      set({ nodes: response.nodes, isLoading: false });
    } catch (error) {
      console.error('获取节点列表失败:', error);
      set({ error: '获取节点列表失败', isLoading: false });
    }
  },

  createNode: async (node) => {
    set({ isLoading: true, error: null });
    try {
      const response = await nodeService.createNode(node);
      set({ nodes: [...get().nodes, response.node], isLoading: false });
    } catch (error) {
      console.error('创建节点失败:', error);
      set({ error: '创建节点失败', isLoading: false });
    }
  },

  updateNode: async (id, node) => {
    set({ isLoading: true, error: null });
    try {
      const response = await nodeService.updateNode(id, node);
      set({ 
        nodes: get().nodes.map(n => n.id === id ? response.node : n), 
        isLoading: false 
      });
    } catch (error) {
      console.error('更新节点失败:', error);
      set({ error: '更新节点失败', isLoading: false });
    }
  },

  deleteNode: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await nodeService.deleteNode(id);
      set({ 
        nodes: get().nodes.filter(n => n.id !== id), 
        isLoading: false 
      });
    } catch {
      set({ error: '删除节点失败', isLoading: false });
    }
  },

  updateNodeStatus: async (id: string, status: Node['status']) => {
    set({ isLoading: true, error: null });
    try {
      await nodeService.updateNodeStatus(id);
      set({ 
        nodes: get().nodes.map(n => n.id === id ? { ...n, status } : n), 
        isLoading: false 
      });
    } catch (error) {
      console.error('更新节点状态失败:', error);
      set({ error: '更新节点状态失败', isLoading: false });
    }
  },

  clearError: () => {
    set({ error: null });
  }
}));
