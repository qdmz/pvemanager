import { create } from 'zustand';
import { apiKeysService } from '../services/apiKeysService';
import type { ApiKey } from '../types';

interface ApiKeyState {
  apiKeys: ApiKey[];
  loading: boolean;
  error: string | null;
  stats: {
    total: number;
    active: number;
    revoked: number;
    expired: number;
  };
  fetchApiKeys: (params?: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
  }) => Promise<void>;
  createApiKey: (data: any) => Promise<void>;
  revokeApiKey: (id: string) => Promise<void>;
  fetchApiKeyStats: () => Promise<void>;
  clearError: () => void;
}

export const useApiKeysStore = create<ApiKeyState>((set, get) => ({
  apiKeys: [],
  loading: false,
  error: null,
  stats: {
    total: 0,
    active: 0,
    revoked: 0,
    expired: 0
  },

  fetchApiKeys: async (params) => {
    set({ loading: true, error: null });
    try {
      const response = await apiKeysService.getApiKeys(params);
      set({
        apiKeys: response.apiKeys,
        loading: false
      });
    } catch (error) {
      set({ 
        error: 'Failed to fetch API keys', 
        loading: false 
      });
    }
  },

  createApiKey: async (data) => {
    set({ loading: true, error: null });
    try {
      const response = await apiKeysService.createApiKey(data);
      const { apiKeys } = get();
      set({
        apiKeys: [...apiKeys, response.apiKey],
        loading: false
      });
      // 刷新统计数据
      await get().fetchApiKeyStats();
    } catch (error) {
      set({ 
        error: 'Failed to create API key', 
        loading: false 
      });
    }
  },

  revokeApiKey: async (id) => {
    set({ loading: true, error: null });
    try {
      await apiKeysService.revokeApiKey(id);
      const { apiKeys } = get();
      set({
        apiKeys: apiKeys.map(key => 
          key.id === id ? { ...key, status: 'REVOKED' } : key
        ),
        loading: false
      });
      // 刷新统计数据
      await get().fetchApiKeyStats();
    } catch (error) {
      set({ 
        error: 'Failed to revoke API key', 
        loading: false 
      });
    }
  },

  fetchApiKeyStats: async () => {
    try {
      const stats = await apiKeysService.getApiKeyStats();
      set({ stats });
    } catch (error) {
      console.error('Failed to fetch API key stats:', error);
    }
  },

  clearError: () => {
    set({ error: null });
  }
}));