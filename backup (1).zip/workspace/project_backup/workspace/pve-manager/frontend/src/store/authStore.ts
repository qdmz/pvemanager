import { create } from 'zustand';
import { authService } from '../services/authService';
import type { User } from '../types';

interface AuthState {
  user: User | null;
  token: string | null;
  refreshToken: string | null;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, username: string, password: string, confirmPassword: string) => Promise<void>;
  logout: () => void;
  refresh: () => Promise<void>;
  updateUser: (user: User) => void;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  token: localStorage.getItem('token'),
  refreshToken: localStorage.getItem('refreshToken'),
  isLoading: false,
  error: null,

  login: async (email, password) => {
    set({ isLoading: true, error: null });
    try {
      const response = await authService.login(email, password);
      const { user, accessToken, refreshToken } = response;
      
      // 处理后端返回的user对象，确保它符合User类型
      const formattedUser = {
        ...user,
        // 确保role是大写的，处理可能的大小写问题
        role: (user.role || 'USER').toUpperCase() as 'ADMIN' | 'USER',
        // 添加缺失的字段，使用默认值
        status: (user.status || 'ACTIVE') as 'ACTIVE' | 'INACTIVE' | 'PENDING',
        vmCount: user.vmCount || 0,
        createdAt: user.createdAt || new Date().toISOString(),
        updatedAt: user.updatedAt || new Date().toISOString(),
        emailVerified: user.emailVerified || false
      };
      
      localStorage.setItem('token', accessToken);
      if (refreshToken) {
        localStorage.setItem('refreshToken', refreshToken);
      }
      
      set({ 
        user: formattedUser,
        token: accessToken, 
        refreshToken: refreshToken || null,
        isLoading: false 
      });
    } catch (error) {
      console.error('Login error:', error);
      set({ 
        error: '登录失败，请检查邮箱和密码是否正确', 
        isLoading: false 
      });
    }
  },

  register: async (email, username, password, confirmPassword) => {
    set({ isLoading: true, error: null });
    try {
      const response = await authService.register(email, username, password, confirmPassword);
      const { user, accessToken, refreshToken } = response;
      
      // 处理后端返回的user对象，确保它符合User类型
      const formattedUser = {
        ...user,
        // 确保role是大写的，处理可能的大小写问题
        role: (user.role || 'USER').toUpperCase() as 'ADMIN' | 'USER',
        // 添加缺失的字段，使用默认值
        status: 'ACTIVE',
        vmCount: user.vmCount || 0,
        createdAt: user.createdAt || new Date().toISOString(),
        updatedAt: user.updatedAt || new Date().toISOString(),
        emailVerified: user.emailVerified || false
      };
      
      localStorage.setItem('token', accessToken);
      if (refreshToken) {
        localStorage.setItem('refreshToken', refreshToken);
      }
      
      set({ 
        user: formattedUser,
        token: accessToken, 
        refreshToken: refreshToken || null,
        isLoading: false 
      });
    } catch (error) {
      console.error('Registration error:', error);
      set({ 
        error: '注册失败，请检查输入信息是否正确', 
        isLoading: false 
      });
    }
  },

  logout: () => {
    localStorage.removeItem('token');
    localStorage.removeItem('refreshToken');
    set({ 
      user: null, 
      token: null, 
      refreshToken: null, 
      error: null 
    });
  },

  refresh: async () => {
    const { refreshToken } = get();
    if (!refreshToken) {
      get().logout();
      return;
    }

    try {
      const response = await authService.refresh(refreshToken);
      const { accessToken } = response;
      
      localStorage.setItem('token', accessToken);
      
      set({ 
        token: accessToken, 
        error: null 
      });
    } catch {
      get().logout();
    }
  },

  clearError: () => {
    set({ error: null });
  },

  updateUser: (user: User) => {
    set({ user });
  }
}));
