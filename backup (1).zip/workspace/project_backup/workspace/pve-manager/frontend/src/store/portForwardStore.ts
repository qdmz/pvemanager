import { create } from 'zustand';
import { portForwardService } from '../services/portForwardService';
import type { PortForward } from '../types';

interface PortForwardState {
  portForwards: PortForward[];
  isLoading: boolean;
  error: string | null;
  getVMPortForwards: (vmId: string) => Promise<void>;
  getAllPortForwards: () => Promise<void>;
  createPortForward: (portForward: Omit<PortForward, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>;
  updatePortForward: (id: string, portForward: Partial<PortForward>) => Promise<void>;
  deletePortForward: (id: string) => Promise<void>;
  togglePortForwardStatus: (id: string) => Promise<void>;
  clearError: () => void;
}

export const usePortForwardStore = create<PortForwardState>((set, get) => ({
  portForwards: [],
  isLoading: false,
  error: null,

  getVMPortForwards: async (vmId) => {
    set({ isLoading: true, error: null });
    try {
      const portForwards = await portForwardService.getVMPortForwards(vmId);
      set({ portForwards, isLoading: false });
    } catch {
      set({ error: '获取虚拟机端口转发规则失败', isLoading: false });
    }
  },

  getAllPortForwards: async () => {
    set({ isLoading: true, error: null });
    try {
      const portForwards = await portForwardService.getAllPortForwards();
      set({ portForwards, isLoading: false });
    } catch {
      set({ error: '获取所有端口转发规则失败', isLoading: false });
    }
  },

  createPortForward: async (portForward) => {
    set({ isLoading: true, error: null });
    try {
      const newPortForward = await portForwardService.createPortForward(portForward);
      set({ portForwards: [...get().portForwards, newPortForward], isLoading: false });
    } catch {
      set({ error: '创建端口转发规则失败', isLoading: false });
    }
  },

  updatePortForward: async (id, portForward) => {
    set({ isLoading: true, error: null });
    try {
      const updatedPortForward = await portForwardService.updatePortForward(id, portForward);
      set({ 
        portForwards: get().portForwards.map(pf => pf.id === id ? updatedPortForward : pf), 
        isLoading: false 
      });
    } catch {
      set({ error: '更新端口转发规则失败', isLoading: false });
    }
  },

  deletePortForward: async (id) => {
    set({ isLoading: true, error: null });
    try {
      await portForwardService.deletePortForward(id);
      set({ 
        portForwards: get().portForwards.filter(pf => pf.id !== id), 
        isLoading: false 
      });
    } catch {
      set({ error: '删除端口转发规则失败', isLoading: false });
    }
  },

  togglePortForwardStatus: async (id) => {
    set({ isLoading: true, error: null });
    try {
      const updatedPortForward = await portForwardService.togglePortForwardStatus(id);
      set({ 
        portForwards: get().portForwards.map(pf => pf.id === id ? updatedPortForward : pf), 
        isLoading: false 
      });
    } catch {
      set({ error: '切换端口转发规则状态失败', isLoading: false });
    }
  },

  clearError: () => {
    set({ error: null });
  }
}));
