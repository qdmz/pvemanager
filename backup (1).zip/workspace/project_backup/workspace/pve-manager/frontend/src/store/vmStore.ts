import { create } from 'zustand';
import { vmService } from '../services/vmService';
import type { VirtualMachine } from '../types';

interface VMState {
  vms: VirtualMachine[];
  loading: boolean;
  error: string | null;
  pagination: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
  fetchVMs: (params?: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    node?: string;
  }) => Promise<void>;
  createVM: (data: any) => Promise<void>;
  updateVM: (id: string, data: any) => Promise<void>;
  deleteVM: (id: string) => Promise<void>;
  performVMAction: (id: string, action: string) => Promise<void>;
  clearError: () => void;
}

export const useVMStore = create<VMState>((set, get) => ({
  vms: [],
  loading: false,
  error: null,
  pagination: {
    page: 1,
    limit: 10,
    total: 0,
    pages: 0
  },

  fetchVMs: async (params) => {
    set({ loading: true, error: null });
    try {
      const response = await vmService.getVMs(params);
      set({
        vms: response.vms,
        pagination: response.pagination,
        loading: false
      });
    } catch (error) {
      set({ 
        error: 'Failed to fetch virtual machines', 
        loading: false 
      });
    }
  },

  createVM: async (data) => {
    set({ loading: true, error: null });
    try {
      const response = await vmService.createVM(data);
      const { vms } = get();
      set({
        vms: [...vms, response.vm],
        loading: false
      });
    } catch (error) {
      set({ 
        error: 'Failed to create virtual machine', 
        loading: false 
      });
    }
  },

  updateVM: async (id, data) => {
    set({ loading: true, error: null });
    try {
      const response = await vmService.updateVM(id, data);
      const { vms } = get();
      set({
        vms: vms.map(vm => 
          vm.id === id ? response.vm : vm
        ),
        loading: false
      });
    } catch (error) {
      set({ 
        error: 'Failed to update virtual machine', 
        loading: false 
      });
    }
  },

  deleteVM: async (id) => {
    set({ loading: true, error: null });
    try {
      await vmService.deleteVM(id);
      const { vms } = get();
      set({
        vms: vms.filter(vm => vm.id !== id),
        loading: false
      });
    } catch (error) {
      set({ 
        error: 'Failed to delete virtual machine', 
        loading: false 
      });
    }
  },

  performVMAction: async (id, action) => {
    set({ loading: true, error: null });
    try {
      switch (action) {
        case 'start':
          await vmService.startVM(id);
          break;
        case 'stop':
          await vmService.stopVM(id);
          break;
        case 'restart':
          await vmService.restartVM(id);
          break;
        case 'pause':
          await vmService.pauseVM(id);
          break;
        case 'resume':
          await vmService.resumeVM(id);
          break;
        default:
          throw new Error(`Unknown action: ${action}`);
      }
      // 刷新虚拟机列表
      await get().fetchVMs();
    } catch (error) {
      set({ 
        error: `Failed to ${action} virtual machine`, 
        loading: false 
      });
    }
  },

  clearError: () => {
    set({ error: null });
  }
}));