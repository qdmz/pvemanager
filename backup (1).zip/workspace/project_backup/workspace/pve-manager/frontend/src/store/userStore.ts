import { create } from 'zustand';
import { userService } from '../services/userService';
import type { User } from '../types';

interface UserState {
  users: User[];
  loading: boolean;
  error: string | null;
  pagination: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
  stats: {
    total: number;
    active: number;
    inactive: number;
    pending: number;
    admins: number;
    users: number;
  };
  fetchUsers: (params?: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
    role?: string;
  }) => Promise<void>;
  createUser: (data: any) => Promise<void>;
  updateUser: (id: string, data: any) => Promise<void>;
  deleteUser: (id: string) => Promise<void>;
  bulkUpdateUsers: (ids: string[], data: any) => Promise<void>;
  fetchUserStats: () => Promise<void>;
  clearError: () => void;
}

export const useUserStore = create<UserState>((set, get) => ({
  users: [],
  loading: false,
  error: null,
  pagination: {
    page: 1,
    limit: 20,
    total: 0,
    pages: 0
  },
  stats: {
    total: 0,
    active: 0,
    inactive: 0,
    pending: 0,
    admins: 0,
    users: 0
  },

  fetchUsers: async (params) => {
    set({ loading: true, error: null });
    try {
      const response = await userService.getUsers(params);
      set({
        users: response.users,
        pagination: response.pagination,
        loading: false
      });
    } catch (error) {
      set({ 
        error: 'Failed to fetch users', 
        loading: false 
      });
    }
  },

  createUser: async (data) => {
    set({ loading: true, error: null });
    try {
      // 这里应该调用注册API，而不是用户管理API
      // 因为注册会处理密码哈希等
      // 暂时使用mock数据
      const newUser: User = {
        id: `user-${Date.now()}`,
        username: data.username,
        email: data.email,
        role: data.role,
        status: data.status,
        vmQuota: data.vmQuota,
        vmCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        lastLoginAt: undefined,
        emailVerified: false
      };
      
      // 模拟API调用延迟
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const { users } = get();
      set({
        users: [...users, newUser],
        loading: false
      });
      // 刷新统计数据
      await get().fetchUserStats();
    } catch (error) {
      set({ 
        error: 'Failed to create user', 
        loading: false 
      });
    }
  },

  updateUser: async (id, data) => {
    set({ loading: true, error: null });
    try {
      const response = await userService.updateUser(id, data);
      const { users } = get();
      set({
        users: users.map(user => 
          user.id === id ? response.user : user
        ),
        loading: false
      });
      // 刷新统计数据
      await get().fetchUserStats();
    } catch (error) {
      set({ 
        error: 'Failed to update user', 
        loading: false 
      });
    }
  },

  deleteUser: async (id) => {
    set({ loading: true, error: null });
    try {
      await userService.deleteUser(id);
      const { users } = get();
      set({
        users: users.filter(user => user.id !== id),
        loading: false
      });
      // 刷新统计数据
      await get().fetchUserStats();
    } catch (error) {
      set({ 
        error: 'Failed to delete user', 
        loading: false 
      });
    }
  },

  bulkUpdateUsers: async (ids, data) => {
    set({ loading: true, error: null });
    try {
      for (const id of ids) {
        await userService.updateUser(id, data);
      }
      // 刷新用户列表
      await get().fetchUsers();
    } catch (error) {
      set({ 
        error: 'Failed to update users', 
        loading: false 
      });
    }
  },

  fetchUserStats: async () => {
    try {
      const stats = await userService.getUserStats();
      set({ stats });
    } catch (error) {
      console.error('Failed to fetch user stats:', error);
    }
  },

  clearError: () => {
    set({ error: null });
  }
}));