import { useEffect, useState } from 'react';
import { useAuthStore } from '../store/authStore';
import { useNavigate } from 'react-router-dom';

interface DashboardStats {
  totalUsers: number;
  totalVMs: number;
  runningVMs: number;
  activeAPICredentials: number;
  totalAPICredentials: number;
  onlineNodes: number;
  totalNodes: number;
}

interface AuditLog {
  id: string;
  userName: string;
  message: string;
  status: 'success' | 'failed' | 'pending';
  createdAt: string;
}

interface StatCardProps {
  title: string;
  value: string | number;
  icon: string;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
}

// 统计卡片组件
const StatCard = ({ title, value, icon, change, changeType }: StatCardProps) => (
  <div className="stat-card">
    <div className="stat-card-header">
      <h3 className="stat-card-title">{title}</h3>
      <span className="stat-card-icon">{icon}</span>
    </div>
    <div className="stat-card-value">{value}</div>
    {change && (
      <div className={`stat-card-change ${changeType || 'neutral'}`}>
        {changeType === 'positive' && '↑ '}
        {changeType === 'negative' && '↓ '}
        {change}
      </div>
    )}
  </div>
);

const DashboardPage = () => {
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [stats] = useState<DashboardStats>({
    totalUsers: 10,
    totalVMs: 25,
    runningVMs: 18,
    activeAPICredentials: 15,
    totalAPICredentials: 20,
    onlineNodes: 3,
    totalNodes: 3
  });

  // 模拟最近活动日志
  const [recentLogs] = useState<AuditLog[]>([
    {
      id: '1',
      userName: 'admin',
      message: '启动虚拟机 web-server-01',
      status: 'success',
      createdAt: '2026-01-25T10:30:00Z'
    },
    {
      id: '2',
      userName: user?.username || 'user',
      message: '创建虚拟机 dev-workspace-01',
      status: 'success',
      createdAt: '2026-01-24T15:20:00Z'
    },
    {
      id: '3',
      userName: 'admin',
      message: '创建新用户 guest1',
      status: 'success',
      createdAt: '2026-01-23T14:10:00Z'
    },
    {
      id: '4',
      userName: user?.username || 'user',
      message: '停止虚拟机 test-vm-01',
      status: 'failed',
      createdAt: '2026-01-22T09:15:00Z'
    },
    {
      id: '5',
      userName: 'admin',
      message: '生成新的API凭证',
      status: 'success',
      createdAt: '2026-01-20T11:00:00Z'
    }
  ]);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // 格式化日期时间
  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  // 快速操作处理函数
  const handleQuickAction = (action: string) => {
    switch(action) {
      case 'create-vm':
        // 跳转到虚拟机管理页面，可能需要添加创建VM的逻辑
        navigate('/vms');
        break;
      case 'manage-api-keys':
        navigate('/api-keys');
        break;
      case 'view-logs':
        navigate('/logs');
        break;
      case 'update-settings':
        // 跳转到个人设置页面
        navigate('/settings');
        break;
      default:
        break;
    }
  };

  return (
    <div className="dashboard">
      {/* 页面标题和当前时间 */}
      <div className="dashboard-header">
        <div className="dashboard-title">
          <h1 className="page-title">仪表盘</h1>
          <p className="page-subtitle">PVE虚拟机管理系统概览</p>
        </div>
        <div className="dashboard-time">
          {currentTime.toLocaleString()}
        </div>
      </div>

      {/* 统计卡片 */}
      <div className="stats-grid">
        <StatCard 
          title="总用户数" 
          value={stats.totalUsers} 
          icon="👥"
          change="+2 本月"
          changeType="positive"
        />
        <StatCard 
          title="虚拟机总数" 
          value={stats.totalVMs} 
          icon="🖥️"
          change={`${stats.runningVMs} 运行中`}
          changeType="positive"
        />
        <StatCard 
          title="API凭证" 
          value={stats.activeAPICredentials} 
          icon="🔑"
          change={`共 ${stats.totalAPICredentials} 个`}
          changeType="neutral"
        />
        <StatCard 
          title="节点状态" 
          value={`${stats.onlineNodes}/${stats.totalNodes}`} 
          icon="🌐"
          change={`${stats.onlineNodes} 在线`}
          changeType={stats.onlineNodes === stats.totalNodes ? 'positive' : 'negative'}
        />
      </div>

      {/* 用户相关统计 */}
      {user && (
        <div className="user-stats-grid">
          <StatCard 
            title="您的VMs" 
            value={`${user.vmCount} / ${user.vmQuota}`} 
            icon="📊"
            change={`已使用 ${Math.round((user.vmCount / user.vmQuota) * 100)}%`}
            changeType="neutral"
          />
          <StatCard 
            title="您的角色" 
            value={user.role === 'ADMIN' ? '管理员' : '用户'} 
            icon="🎭"
            change={user.status === 'ACTIVE' ? '已激活' : user.status}
            changeType="positive"
          />
        </div>
      )}

      {/* 主要内容区域 */}
      <div className="main-content-grid">
        {/* 系统状态 */}
        <div className="content-card">
          <h2 className="content-card-title">系统状态</h2>
          <div className="system-stats">
            <div className="system-stat-item">
              <div className="system-stat-header">
                <span className="system-stat-label">CPU 使用率</span>
                <span className="system-stat-value">45.2%</span>
              </div>
              <div className="progress-bar-container">
                <div className="progress-bar" style={{ width: '45.2%', backgroundColor: '#3b82f6' }}></div>
              </div>
            </div>
            <div className="system-stat-item">
              <div className="system-stat-header">
                <span className="system-stat-label">内存使用率</span>
                <span className="system-stat-value">62.8%</span>
              </div>
              <div className="progress-bar-container">
                <div className="progress-bar" style={{ width: '62.8%', backgroundColor: '#8b5cf6' }}></div>
              </div>
            </div>
            <div className="system-stat-item">
              <div className="system-stat-header">
                <span className="system-stat-label">存储使用率</span>
                <span className="system-stat-value">38.5%</span>
              </div>
              <div className="progress-bar-container">
                <div className="progress-bar" style={{ width: '38.5%', backgroundColor: '#f59e0b' }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* 最近活动 */}
        <div className="content-card">
          <h2 className="content-card-title">最近活动</h2>
          <div className="activity-list">
            {recentLogs.map((log) => (
              <div key={log.id} className="activity-item">
                <div className="activity-content">
                  <div className={`activity-status-dot ${log.status}`}></div>
                  <div className="activity-info">
                    <div className="activity-message">{log.message}</div>
                    <div className="activity-meta">{log.userName} • {formatDateTime(log.createdAt)}</div>
                  </div>
                </div>
                <span className={`activity-status-badge ${log.status}`}>
                  {log.status === 'success' ? '成功' : log.status === 'failed' ? '失败' : '进行中'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 快速操作 */}
      <div className="content-card">
        <h2 className="content-card-title">快速操作</h2>
        <div className="quick-actions-grid">
          <button 
            className="quick-action-button"
            onClick={() => handleQuickAction('create-vm')}
          >
            <span className="quick-action-icon">➕</span>
            <span className="quick-action-label">创建虚拟机</span>
          </button>
          <button 
            className="quick-action-button"
            onClick={() => handleQuickAction('manage-api-keys')}
          >
            <span className="quick-action-icon">🔑</span>
            <span className="quick-action-label">管理API密钥</span>
          </button>
          <button 
            className="quick-action-button"
            onClick={() => handleQuickAction('view-logs')}
          >
            <span className="quick-action-icon">📋</span>
            <span className="quick-action-label">查看操作日志</span>
          </button>
          <button 
            className="quick-action-button"
            onClick={() => handleQuickAction('update-settings')}
          >
            <span className="quick-action-icon">⚙️</span>
            <span className="quick-action-label">更新个人设置</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;