import { useState, useEffect } from 'react';
import { apiKeysService } from '../services/apiKeysService';
import type { ApiKey } from '../types';

const ApiKeysPage = () => {
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // 搜索和筛选
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  
  // 创建API密钥对话框
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [apiKeyFormData, setApiKeyFormData] = useState({
    name: '',
    permissions: ['vm:read', 'vm:write'],
    expiresAt: ''
  });
  
  // API密钥统计
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    revoked: 0,
    expired: 0
  });
  
  // 可用权限列表
  const availablePermissions = [
    { value: 'vm:read', label: '虚拟机读取' },
    { value: 'vm:write', label: '虚拟机写入' },
    { value: 'api-keys:read', label: 'API密钥读取' },
    { value: 'api-keys:write', label: 'API密钥写入' },
    { value: 'logs:read', label: '日志读取' },
    { value: 'user:read', label: '用户读取' },
    { value: 'user:write', label: '用户写入' }
  ];
  
  // 加载API密钥列表
  useEffect(() => {
    const fetchApiKeys = async () => {
      try {
        setLoading(true);
        const response = await apiKeysService.getApiKeys();
        setApiKeys(response.apiKeys);
        
        // 获取统计数据
        const statsResponse = await apiKeysService.getApiKeyStats();
        setStats(statsResponse);
        
        setError(null);
      } catch (err) {
        setError('Failed to fetch API keys');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchApiKeys();
  }, []);
  
  // 筛选API密钥
  const filteredApiKeys = apiKeys.filter(apiKey => {
    const matchesSearch = apiKey.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || apiKey.status === statusFilter;
    return matchesSearch && matchesStatus;
  });
  
  // 格式化日期
  const formatDate = (dateString?: string) => {
    if (!dateString) return '永久';
    return new Date(dateString).toLocaleString();
  };
  
  // 创建API密钥
  const handleCreateApiKey = async () => {
    try {
      setLoading(true);
      
      const createData = {
        ...apiKeyFormData,
        expiresAt: apiKeyFormData.expiresAt ? new Date(apiKeyFormData.expiresAt) : undefined
      };
      
      await apiKeysService.createApiKey(createData);
      
      // 刷新API密钥列表
      const response = await apiKeysService.getApiKeys();
      setApiKeys(response.apiKeys);
      
      // 刷新统计数据
      const statsResponse = await apiKeysService.getApiKeyStats();
      setStats(statsResponse);
      
      // 重置表单
      setApiKeyFormData({
        name: '',
        permissions: ['vm:read', 'vm:write'],
        expiresAt: ''
      });
      
      setIsCreateDialogOpen(false);
      setError(null);
    } catch (err) {
      setError('Failed to create API key');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  // 撤销API密钥
  const handleRevokeApiKey = async (id: string) => {
    try {
      if (window.confirm('确定要撤销此API密钥吗？')) {
        await apiKeysService.revokeApiKey(id);
        
        // 刷新API密钥列表
        const response = await apiKeysService.getApiKeys();
        setApiKeys(response.apiKeys);
        
        // 刷新统计数据
        const statsResponse = await apiKeysService.getApiKeyStats();
        setStats(statsResponse);
        
        setError(null);
      }
    } catch (err) {
      setError('Failed to revoke API key');
      console.error(err);
    }
  };
  
  // 切换权限选择
  const togglePermission = (permission: string) => {
    setApiKeyFormData(prev => {
      if (prev.permissions.includes(permission)) {
        return {
          ...prev,
          permissions: prev.permissions.filter(p => p !== permission)
        };
      } else {
        return {
          ...prev,
          permissions: [...prev.permissions, permission]
        };
      }
    });
  };

  return (
    <div className="api-keys-page">
      {/* 页面标题 */}
      <div className="page-header">
        <div>
          <h1 className="page-title">API密钥管理</h1>
          <p className="page-subtitle">创建和管理API访问凭证</p>
        </div>
        <button 
          className="create-api-key-button"
          onClick={() => setIsCreateDialogOpen(true)}
        >
          创建API密钥
        </button>
      </div>
      
      {/* 错误提示 */}
      {error && (
        <div className="error-message">
          {error}
        </div>
      )}
      
      {/* API密钥统计 */}
      <div className="api-keys-stats">
        <div className="stat-card">
          <div className="stat-header">
            <h3 className="stat-title">总密钥数</h3>
            <div className="stat-icon">🔑</div>
          </div>
          <div className="stat-value">{stats.total}</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-header">
            <h3 className="stat-title">活跃密钥</h3>
            <div className="stat-icon">✅</div>
          </div>
          <div className="stat-value">{stats.active}</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-header">
            <h3 className="stat-title">已撤销</h3>
            <div className="stat-icon">❌</div>
          </div>
          <div className="stat-value">{stats.revoked}</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-header">
            <h3 className="stat-title">已过期</h3>
            <div className="stat-icon">⏰</div>
          </div>
          <div className="stat-value">{stats.expired}</div>
        </div>
      </div>
      
      {/* 搜索和筛选 */}
      <div className="search-filter-section">
        <div className="search-box">
          <input
            type="text"
            placeholder="搜索API密钥名称..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
        
        <div className="filter-section">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">所有状态</option>
            <option value="ACTIVE">活跃</option>
            <option value="REVOKED">已撤销</option>
            <option value="EXPIRED">已过期</option>
          </select>
        </div>
      </div>
      
      {/* API密钥列表 */}
      <div className="api-keys-list-section">
        {loading ? (
          <div className="loading">加载中...</div>
        ) : filteredApiKeys.length === 0 ? (
          <div className="empty-state">
            没有找到匹配的API密钥
          </div>
        ) : (
          <div className="api-keys-table-container">
            <table className="api-keys-table">
              <thead>
                <tr>
                  <th>名称</th>
                  <th>密钥</th>
                  <th>权限</th>
                  <th>状态</th>
                  <th>创建时间</th>
                  <th>过期时间</th>
                  <th>最后使用</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredApiKeys.map((apiKey) => (
                  <tr key={apiKey.id} className="api-key-row">
                    <td className="api-key-name">
                      <div className="api-key-name-info">
                        <span className="api-key-icon">🔑</span>
                        <span>{apiKey.name}</span>
                      </div>
                    </td>
                    
                    <td className="api-key-value">
                      <div className="key-display">
                        {apiKey.key.substring(0, 10)}...{apiKey.key.substring(apiKey.key.length - 10)}
                      </div>
                    </td>
                    
                    <td className="api-key-permissions">
                      <div className="permissions-list">
                        {apiKey.permissions.slice(0, 3).map((permission, index) => (
                          <span key={index} className="permission-tag">
                            {permission}
                          </span>
                        ))}
                        {apiKey.permissions.length > 3 && (
                          <span className="permission-more">+{apiKey.permissions.length - 3}</span>
                        )}
                      </div>
                    </td>
                    
                    <td className="api-key-status">
                      <span className={`status-badge ${apiKey.status}`}>
                        {apiKey.status === 'ACTIVE' ? '活跃' : apiKey.status === 'REVOKED' ? '已撤销' : '已过期'}
                      </span>
                    </td>
                    
                    <td className="api-key-created">
                      {formatDate(apiKey.createdAt)}
                    </td>
                    
                    <td className="api-key-expires">
                      {formatDate(apiKey.expiresAt)}
                    </td>
                    
                    <td className="api-key-last-used">
                      {apiKey.lastUsedAt ? formatDate(apiKey.lastUsedAt) : '从未使用'}
                    </td>
                    
                    <td className="api-key-actions">
                      <div className="action-buttons">
                        {apiKey.status === 'ACTIVE' && (
                          <button 
                            className="action-button revoke"
                            onClick={() => handleRevokeApiKey(apiKey.id)}
                            title="撤销"
                          >
                            ❌
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      
      {/* 创建API密钥对话框 */}
      {isCreateDialogOpen && (
        <div className="dialog-overlay">
          <div className="dialog-content">
            <div className="dialog-header">
              <h2>创建新API密钥</h2>
              <button 
                className="close-button"
                onClick={() => setIsCreateDialogOpen(false)}
              >
                ×
              </button>
            </div>
            
            <div className="dialog-body">
              <div className="form-section">
                <label className="form-label">密钥名称</label>
                <input
                  type="text"
                  value={apiKeyFormData.name}
                  onChange={(e) => setApiKeyFormData({ ...apiKeyFormData, name: e.target.value })}
                  className="form-input"
                  placeholder="输入API密钥名称"
                />
              </div>
              
              <div className="form-section">
                <label className="form-label">权限</label>
                <div className="permissions-grid">
                  {availablePermissions.map((permission) => (
                    <div key={permission.value} className="permission-item">
                      <input
                        type="checkbox"
                        id={`permission-${permission.value}`}
                        checked={apiKeyFormData.permissions.includes(permission.value)}
                        onChange={() => togglePermission(permission.value)}
                      />
                      <label htmlFor={`permission-${permission.value}`}>
                        {permission.label}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="form-section">
                <label className="form-label">过期时间（可选）</label>
                <input
                  type="datetime-local"
                  value={apiKeyFormData.expiresAt}
                  onChange={(e) => setApiKeyFormData({ ...apiKeyFormData, expiresAt: e.target.value })}
                  className="form-input"
                />
                <p className="form-hint">留空表示永久有效</p>
              </div>
            </div>
            
            <div className="dialog-footer">
              <button 
                className="cancel-button"
                onClick={() => setIsCreateDialogOpen(false)}
              >
                取消
              </button>
              <button 
                className="create-button"
                onClick={handleCreateApiKey}
                disabled={loading || !apiKeyFormData.name || apiKeyFormData.permissions.length === 0}
              >
                {loading ? '创建中...' : '创建API密钥'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ApiKeysPage;