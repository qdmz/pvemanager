import { useState, useEffect } from 'react';
import { logsService } from '../services/logsService';
import type { AuditLog } from '../types';

const LogsPage = () => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // 搜索和筛选
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState('all');
  const [resourceFilter, setResourceFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateRange, setDateRange] = useState({
    start: '',
    end: ''
  });
  
  // 分页
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 20,
    total: 0,
    pages: 0
  });
  
  // 日志统计
  const [stats, setStats] = useState({
    total: 0,
    success: 0,
    failed: 0,
    byAction: {}
  });
  
  // 可用的操作类型
  const actions = [
    { value: 'all', label: '所有操作' },
    { value: 'vm.create', label: '创建虚拟机' },
    { value: 'vm.start', label: '启动虚拟机' },
    { value: 'vm.stop', label: '停止虚拟机' },
    { value: 'vm.restart', label: '重启虚拟机' },
    { value: 'vm.delete', label: '删除虚拟机' },
    { value: 'api-key.create', label: '创建API密钥' },
    { value: 'api-key.revoke', label: '撤销API密钥' },
    { value: 'user.create', label: '创建用户' },
    { value: 'user.update', label: '更新用户' },
    { value: 'user.delete', label: '删除用户' }
  ];
  
  // 可用的资源类型
  const resources = [
    { value: 'all', label: '所有资源' },
    { value: 'vm', label: '虚拟机' },
    { value: 'api-key', label: 'API密钥' },
    { value: 'user', label: '用户' },
    { value: 'log', label: '日志' }
  ];
  
  // 可用的状态类型
  const statuses = [
    { value: 'all', label: '所有状态' },
    { value: 'success', label: '成功' },
    { value: 'failed', label: '失败' },
    { value: 'pending', label: '进行中' }
  ];
  
  // 加载日志列表
  useEffect(() => {
    const fetchLogs = async () => {
      try {
        setLoading(true);
        
        const params = {
          page: pagination.page,
          limit: pagination.limit,
          search: searchTerm,
          action: actionFilter === 'all' ? undefined : actionFilter,
          resource: resourceFilter === 'all' ? undefined : resourceFilter,
          status: statusFilter === 'all' ? undefined : statusFilter,
          startDate: dateRange.start || undefined,
          endDate: dateRange.end || undefined
        };
        
        const response = await logsService.getLogs(params);
        setLogs(response.logs);
        setPagination({
          ...pagination,
          total: response.pagination.total,
          pages: response.pagination.pages
        });
        
        // 获取日志统计
        const statsResponse = await logsService.getLogStats(params);
        setStats(statsResponse);
        
        setError(null);
      } catch (err) {
        setError('Failed to fetch logs');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchLogs();
  }, [searchTerm, actionFilter, resourceFilter, statusFilter, dateRange, pagination.page, pagination.limit]);
  
  // 格式化日期时间
  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };
  
  // 导出日志
  const handleExportLogs = async () => {
    try {
      setLoading(true);
      
      const params = {
        action: actionFilter === 'all' ? undefined : actionFilter,
        resource: resourceFilter === 'all' ? undefined : resourceFilter,
        status: statusFilter === 'all' ? undefined : statusFilter,
        startDate: dateRange.start || undefined,
        endDate: dateRange.end || undefined
      };
      
      const blob = await logsService.exportLogs(params);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `logs-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      setError(null);
    } catch (err) {
      setError('Failed to export logs');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  // 处理分页
  const handlePageChange = (page: number) => {
    setPagination(prev => ({ ...prev, page }));
  };
  
  // 处理日期范围变化
  const handleDateChange = (field: 'start' | 'end', value: string) => {
    setDateRange(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="logs-page">
      {/* 页面标题 */}
      <div className="page-header">
        <div>
          <h1 className="page-title">操作日志</h1>
          <p className="page-subtitle">查看和管理系统操作日志</p>
        </div>
        <button 
          className="export-logs-button"
          onClick={handleExportLogs}
          disabled={loading}
        >
          {loading ? '导出中...' : '导出日志'}
        </button>
      </div>
      
      {/* 错误提示 */}
      {error && (
        <div className="error-message">
          {error}
        </div>
      )}
      
      {/* 日志统计 */}
      <div className="logs-stats">
        <div className="stat-card">
          <div className="stat-header">
            <h3 className="stat-title">总日志数</h3>
            <div className="stat-icon">📋</div>
          </div>
          <div className="stat-value">{stats.total}</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-header">
            <h3 className="stat-title">成功操作</h3>
            <div className="stat-icon">✅</div>
          </div>
          <div className="stat-value">{stats.success}</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-header">
            <h3 className="stat-title">失败操作</h3>
            <div className="stat-icon">❌</div>
          </div>
          <div className="stat-value">{stats.failed}</div>
        </div>
      </div>
      
      {/* 搜索和筛选 */}
      <div className="search-filter-section">
        <div className="search-box">
          <input
            type="text"
            placeholder="搜索日志内容..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
        
        <div className="filters-grid">
          <div className="filter-item">
            <label className="filter-label">操作类型</label>
            <select
              value={actionFilter}
              onChange={(e) => setActionFilter(e.target.value)}
              className="filter-select"
            >
              {actions.map(action => (
                <option key={action.value} value={action.value}>
                  {action.label}
                </option>
              ))}
            </select>
          </div>
          
          <div className="filter-item">
            <label className="filter-label">资源类型</label>
            <select
              value={resourceFilter}
              onChange={(e) => setResourceFilter(e.target.value)}
              className="filter-select"
            >
              {resources.map(resource => (
                <option key={resource.value} value={resource.value}>
                  {resource.label}
                </option>
              ))}
            </select>
          </div>
          
          <div className="filter-item">
            <label className="filter-label">状态</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="filter-select"
            >
              {statuses.map(status => (
                <option key={status.value} value={status.value}>
                  {status.label}
                </option>
              ))}
            </select>
          </div>
          
          <div className="filter-item">
            <label className="filter-label">开始日期</label>
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => handleDateChange('start', e.target.value)}
              className="filter-input"
            />
          </div>
          
          <div className="filter-item">
            <label className="filter-label">结束日期</label>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => handleDateChange('end', e.target.value)}
              className="filter-input"
            />
          </div>
        </div>
      </div>
      
      {/* 日志列表 */}
      <div className="logs-list-section">
        {loading ? (
          <div className="loading">加载中...</div>
        ) : logs.length === 0 ? (
          <div className="empty-state">
            没有找到匹配的日志
          </div>
        ) : (
          <div className="logs-table-container">
            <table className="logs-table">
              <thead>
                <tr>
                  <th>操作时间</th>
                  <th>用户名</th>
                  <th>操作类型</th>
                  <th>资源类型</th>
                  <th>资源ID</th>
                  <th>操作内容</th>
                  <th>状态</th>
                  <th>IP地址</th>
                </tr>
              </thead>
              <tbody>
                {logs.map((log) => (
                  <tr key={log.id} className="log-row">
                    <td className="log-time">
                      {formatDateTime(log.createdAt)}
                    </td>
                    
                    <td className="log-user">
                      <span className="user-badge">
                        {log.user?.username || '系统'}
                      </span>
                    </td>
                    
                    <td className="log-action">
                      <span className="action-tag">
                        {log.action}
                      </span>
                    </td>
                    
                    <td className="log-resource">
                      <span className="resource-tag">
                        {log.resource}
                      </span>
                    </td>
                    
                    <td className="log-resource-id">
                      {log.resourceId}
                    </td>
                    
                    <td className="log-message">
                      {log.message}
                    </td>
                    
                    <td className="log-status">
                      <span className={`status-badge ${log.status}`}>
                        {log.status === 'SUCCESS' ? '成功' : log.status === 'FAILED' ? '失败' : '进行中'}
                      </span>
                    </td>
                    
                    <td className="log-ip">
                      {log.ip}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            
            {/* 分页 */}
            {pagination.pages > 1 && (
              <div className="pagination">
                <button 
                  className="pagination-button"
                  onClick={() => handlePageChange(1)}
                  disabled={pagination.page === 1}
                >
                  首页
                </button>
                <button 
                  className="pagination-button"
                  onClick={() => handlePageChange(pagination.page - 1)}
                  disabled={pagination.page === 1}
                >
                  上一页
                </button>
                
                <div className="pagination-info">
                  第 {pagination.page} 页，共 {pagination.pages} 页
                </div>
                
                <button 
                  className="pagination-button"
                  onClick={() => handlePageChange(pagination.page + 1)}
                  disabled={pagination.page === pagination.pages}
                >
                  下一页
                </button>
                <button 
                  className="pagination-button"
                  onClick={() => handlePageChange(pagination.pages)}
                  disabled={pagination.page === pagination.pages}
                >
                  末页
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default LogsPage;