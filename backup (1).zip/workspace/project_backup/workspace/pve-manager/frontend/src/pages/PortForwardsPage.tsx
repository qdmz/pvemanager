import { useState, useEffect } from 'react';
import { usePortForwardStore } from '../store/portForwardStore';
import type { PortForward } from '../types';

const PortForwardsPage = () => {
  const { 
    portForwards, 
    isLoading, 
    error, 
    getVMPortForwards, 
    getAllPortForwards, 
    createPortForward, 
    updatePortForward, 
    deletePortForward, 
    togglePortForwardStatus 
  } = usePortForwardStore();
  
  // 筛选和搜索
  const [vmFilter, setVmFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [protocolFilter, setProtocolFilter] = useState('all');
  
  // 创建/编辑规则对话框
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentPortForwardId, setCurrentPortForwardId] = useState<string | null>(null);
  const [portForwardFormData, setPortForwardFormData] = useState({
    vmId: '',
    protocol: 'TCP' as const,
    sourcePort: 0,
    destinationPort: 0,
    destinationIp: '',
    comment: '',
    enabled: true
  });
  
  // 模拟虚拟机数据
  const vms = [
    { id: '1', name: 'web-01', vmid: 100, ip: '192.168.1.100' },
    { id: '2', name: 'db-01', vmid: 101, ip: '192.168.1.101' },
    { id: '3', name: 'app-01', vmid: 102, ip: '192.168.1.102' }
  ];
  
  // 加载规则列表
  useEffect(() => {
    // 暂时不自动加载，等待用户选择虚拟机或使用默认值
    // getAllPortForwards();
  }, [getAllPortForwards]);
  
  // 根据选择的虚拟机筛选规则
  useEffect(() => {
    if (vmFilter !== 'all') {
      getVMPortForwards(vmFilter);
    } else {
      // 暂时不加载所有端口转发，避免403错误
      // getAllPortForwards();
    }
  }, [vmFilter, getVMPortForwards, getAllPortForwards]);
  
  // 筛选规则
  const filteredPortForwards = portForwards.filter(pf => {
    const matchesSearch = 
      (pf.sourcePort.toString().includes(searchTerm)) ||
      (pf.destinationPort.toString().includes(searchTerm)) ||
      (!pf.destinationIp || pf.destinationIp.includes(searchTerm)) ||
      (!pf.comment || pf.comment.includes(searchTerm));
    
    const matchesStatus = statusFilter === 'all' || 
      (statusFilter === 'enabled' && pf.enabled) ||
      (statusFilter === 'disabled' && !pf.enabled);
    
    const matchesProtocol = protocolFilter === 'all' || pf.protocol === protocolFilter;
    
    return matchesSearch && matchesStatus && matchesProtocol;
  });
  
  // 打开创建规则对话框
  const handleOpenCreateDialog = () => {
    setIsEditMode(false);
    setCurrentPortForwardId(null);
    
    // 获取默认虚拟机IP
    const defaultVm = vms[0];
    
    setPortForwardFormData({
      vmId: vmFilter !== 'all' ? vmFilter : (defaultVm ? defaultVm.id : ''),
      protocol: 'TCP',
      sourcePort: 0,
      destinationPort: 0,
      destinationIp: defaultVm ? defaultVm.ip : '',
      comment: '',
      enabled: true
    });
    setIsDialogOpen(true);
  };
  
  // 打开编辑规则对话框
  const handleOpenEditDialog = (portForward: PortForward) => {
    setIsEditMode(true);
    setCurrentPortForwardId(portForward.id);
    setPortForwardFormData({
      vmId: portForward.vmId,
      protocol: portForward.protocol,
      sourcePort: portForward.sourcePort,
      destinationPort: portForward.destinationPort,
      destinationIp: portForward.destinationIp,
      comment: portForward.comment || '',
      enabled: portForward.enabled
    });
    setIsDialogOpen(true);
  };
  
  // 提交规则表单
  const handleSubmitPortForward = async () => {
    if (isEditMode && currentPortForwardId) {
      await updatePortForward(currentPortForwardId, portForwardFormData);
    } else {
      await createPortForward(portForwardFormData);
    }
    setIsDialogOpen(false);
  };
  
  // 处理规则删除
  const handleDeletePortForward = async (id: string) => {
    if (window.confirm('确定要删除此端口转发规则吗？')) {
      await deletePortForward(id);
    }
  };
  
  // 处理规则状态切换
  const handleTogglePortForwardStatus = async (id: string) => {
    await togglePortForwardStatus(id);
  };
  
  // 获取虚拟机信息
  const getVMInfo = (vmId: string) => {
    return vms.find(vm => vm.id === vmId) || { name: vmId, vmid: -1, ip: '未知' };
  };

  return (
    <div className="port-forwards-page">
      {/* 页面标题 */}
      <div className="page-header">
        <div>
          <h1 className="page-title">端口转发管理</h1>
          <p className="page-subtitle">管理所有虚拟机的端口转发规则</p>
        </div>
        <button 
          className="create-port-forward-button"
          onClick={handleOpenCreateDialog}
        >
          创建规则
        </button>
      </div>
      
      {/* 错误提示 */}
      {error && (
        <div className="error-message">
          {error}
        </div>
      )}
      
      {/* 搜索和筛选 */}
      <div className="search-filter-section">
        <div className="search-box">
          <input
            type="text"
            placeholder="搜索端口号或目标IP..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
        
        <div className="filter-section">
          <select
            value={vmFilter}
            onChange={(e) => setVmFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">所有虚拟机</option>
            {vms.map(vm => (
              <option key={vm.id} value={vm.id}>
                {vm.name} (VMID: {vm.vmid})
              </option>
            ))}
          </select>
          
          <select
            value={protocolFilter}
            onChange={(e) => setProtocolFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">所有协议</option>
            <option value="TCP">TCP</option>
            <option value="UDP">UDP</option>
            <option value="BOTH">BOTH</option>
          </select>
          
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">所有状态</option>
            <option value="enabled">已启用</option>
            <option value="disabled">已禁用</option>
          </select>
        </div>
      </div>
      
      {/* 端口转发规则列表 */}
      <div className="port-forwards-list-section">
        {isLoading ? (
          <div className="loading">加载中...</div>
        ) : filteredPortForwards.length === 0 ? (
          <div className="empty-state">
            没有找到匹配的端口转发规则
          </div>
        ) : (
          <div className="port-forwards-table-container">
            <table className="port-forwards-table">
              <thead>
                <tr>
                  <th>虚拟机</th>
                  <th>协议</th>
                  <th>源端口</th>
                  <th>目标IP</th>
                  <th>目标端口</th>
                  <th>状态</th>
                  <th>备注</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredPortForwards.map((portForward) => {
                  const vm = getVMInfo(portForward.vmId);
                  return (
                    <tr key={portForward.id} className="port-forward-row">
                      <td className="port-forward-vm">
                        {vm.name} (VMID: {vm.vmid})
                      </td>
                      
                      <td className="port-forward-protocol">
                        <span className="protocol-badge">{portForward.protocol}</span>
                      </td>
                      
                      <td className="port-forward-source-port">
                        {portForward.sourcePort}
                      </td>
                      
                      <td className="port-forward-destination-ip">
                        {portForward.destinationIp}
                      </td>
                      
                      <td className="port-forward-destination-port">
                        {portForward.destinationPort}
                      </td>
                      
                      <td className="port-forward-status">
                        <div className="status-indicator">
                          <div className={`status-dot ${portForward.enabled ? 'enabled' : 'disabled'}`}></div>
                          <span className="status-text">{portForward.enabled ? '已启用' : '已禁用'}</span>
                        </div>
                      </td>
                      
                      <td className="port-forward-comment">{portForward.comment || '-'}</td>
                      
                      <td className="port-forward-actions">
                        <div className="action-buttons">
                          <button 
                            className="action-button toggle"
                            onClick={() => handleTogglePortForwardStatus(portForward.id)}
                            title={portForward.enabled ? '禁用' : '启用'}
                          >
                            {portForward.enabled ? '🔴' : '🟢'}
                          </button>
                          <button 
                            className="action-button edit"
                            onClick={() => handleOpenEditDialog(portForward)}
                            title="编辑"
                          >
                            ✏️
                          </button>
                          <button 
                            className="action-button delete"
                            onClick={() => handleDeletePortForward(portForward.id)}
                            title="删除"
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
      
      {/* 创建/编辑规则对话框 */}
      {isDialogOpen && (
        <div className="dialog-overlay">
          <div className="dialog-content">
            <div className="dialog-header">
              <h2>{isEditMode ? '编辑端口转发规则' : '创建新端口转发规则'}</h2>
              <button 
                className="close-button"
                onClick={() => setIsDialogOpen(false)}
              >
                ×
              </button>
            </div>
            
            <div className="dialog-body">
              <div className="form-section">
                <label className="form-label">虚拟机</label>
                <select
                  value={portForwardFormData.vmId}
                  onChange={(e) => {
                    const selectedVmId = e.target.value;
                    const selectedVm = vms.find(vm => vm.id === selectedVmId);
                    setPortForwardFormData({
                      ...portForwardFormData, 
                      vmId: selectedVmId,
                      destinationIp: selectedVm?.ip || portForwardFormData.destinationIp
                    });
                  }}
                  className="form-select"
                  required
                >
                  <option value="">选择虚拟机</option>
                  {vms.map(vm => (
                    <option key={vm.id} value={vm.id}>
                      {vm.name} (VMID: {vm.vmid})
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="form-row">
                <div className="form-section half">
                  <label className="form-label">协议</label>
                  <select
                    value={portForwardFormData.protocol}
                    onChange={(e) => setPortForwardFormData({ ...portForwardFormData, protocol: e.target.value as PortForward['protocol'] })}
                    className="form-select"
                    required
                  >
                    <option value="TCP">TCP</option>
                    <option value="UDP">UDP</option>
                    <option value="BOTH">BOTH</option>
                  </select>
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-section half">
                  <label className="form-label">源端口</label>
                  <input
                    type="number"
                    value={portForwardFormData.sourcePort}
                    onChange={(e) => setPortForwardFormData({ ...portForwardFormData, sourcePort: parseInt(e.target.value) || 0 })}
                    className="form-input"
                    min="1"
                    max="65535"
                    required
                  />
                </div>
                
                <div className="form-section half">
                  <label className="form-label">目标端口</label>
                  <input
                    type="number"
                    value={portForwardFormData.destinationPort}
                    onChange={(e) => setPortForwardFormData({ ...portForwardFormData, destinationPort: parseInt(e.target.value) || 0 })}
                    className="form-input"
                    min="1"
                    max="65535"
                    required
                  />
                </div>
              </div>
              
              <div className="form-section">
                <label className="form-label">目标IP</label>
                <input
                  type="text"
                  value={portForwardFormData.destinationIp}
                  onChange={(e) => setPortForwardFormData({ ...portForwardFormData, destinationIp: e.target.value })}
                  className="form-input"
                  placeholder="输入目标IP地址"
                  required
                />
              </div>
              
              <div className="form-section">
                <label className="form-label">备注</label>
                <textarea
                  value={portForwardFormData.comment}
                  onChange={(e) => setPortForwardFormData({ ...portForwardFormData, comment: e.target.value })}
                  className="form-textarea"
                  placeholder="输入规则备注（可选）"
                  rows={3}
                />
              </div>
              
              <div className="form-section checkbox">
                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={portForwardFormData.enabled}
                    onChange={(e) => setPortForwardFormData({ ...portForwardFormData, enabled: e.target.checked })}
                  />
                  <span>启用规则</span>
                </label>
              </div>
            </div>
            
            <div className="dialog-footer">
              <button 
                className="cancel-button"
                onClick={() => setIsDialogOpen(false)}
              >
                取消
              </button>
              <button 
                className="create-button"
                onClick={handleSubmitPortForward}
                disabled={isLoading}
              >
                {isLoading ? '处理中...' : (isEditMode ? '更新规则' : '创建规则')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PortForwardsPage;
