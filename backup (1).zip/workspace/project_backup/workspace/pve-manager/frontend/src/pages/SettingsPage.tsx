import { useState } from 'react';
import { authService } from '../services/authService';
import { useAuthStore } from '../store/authStore';

const SettingsPage = () => {
  const { user, updateUser } = useAuthStore();
  
  // 用户名更新
  const [username, setUsername] = useState(user?.username || '');
  const [isUsernameLoading, setIsUsernameLoading] = useState(false);
  const [usernameMessage, setUsernameMessage] = useState<string | null>(null);
  
  // 邮箱更新
  const [email, setEmail] = useState(user?.email || '');
  const [isEmailLoading, setIsEmailLoading] = useState(false);
  const [emailMessage, setEmailMessage] = useState<string | null>(null);
  
  // 密码更新
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [isPasswordLoading, setIsPasswordLoading] = useState(false);
  const [passwordMessage, setPasswordMessage] = useState<string | null>(null);
  const [passwordError, setPasswordError] = useState<string | null>(null);
  
  // 更新用户名
  const handleUpdateUsername = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      setUsernameMessage('用户名不能为空');
      return;
    }
    
    try {
      setIsUsernameLoading(true);
      setUsernameMessage(null);
      
      const response = await authService.updateProfile({ username });
      updateUser(response.user);
      setUsernameMessage('用户名更新成功');
    } catch (error) {
      setUsernameMessage('用户名更新失败');
      console.error('更新用户名失败:', error);
    } finally {
      setIsUsernameLoading(false);
    }
  };
  
  // 更新邮箱
  const handleUpdateEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) {
      setEmailMessage('请输入有效的邮箱地址');
      return;
    }
    
    try {
      setIsEmailLoading(true);
      setEmailMessage(null);
      
      const response = await authService.updateProfile({ username });
      updateUser(response.user);
      setEmailMessage('邮箱更新成功');
    } catch (error) {
      setEmailMessage('邮箱更新失败');
      console.error('更新邮箱失败:', error);
    } finally {
      setIsEmailLoading(false);
    }
  };
  
  // 更新密码
  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // 表单验证
    if (!passwordForm.currentPassword || !passwordForm.newPassword || !passwordForm.confirmPassword) {
      setPasswordError('所有密码字段都不能为空');
      return;
    }
    
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      setPasswordError('新密码和确认密码不匹配');
      return;
    }
    
    try {
      setIsPasswordLoading(true);
      setPasswordError(null);
      setPasswordMessage(null);
      
      await authService.changePassword(
        passwordForm.currentPassword,
        passwordForm.newPassword,
        passwordForm.confirmPassword
      );
      
      setPasswordMessage('密码更新成功');
      // 重置密码表单
      setPasswordForm({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });
    } catch (error) {
      setPasswordError('密码更新失败，请检查当前密码是否正确');
      console.error('更新密码失败:', error);
    } finally {
      setIsPasswordLoading(false);
    }
  };
  
  return (
    <div className="settings-page">
      {/* 页面标题 */}
      <div className="page-header">
        <div>
          <h1 className="page-title">个人设置</h1>
          <p className="page-subtitle">更新您的账户信息和密码</p>
        </div>
      </div>
      
      <div className="settings-content">
        {/* 账户信息卡片 */}
        <div className="settings-card">
          <h2 className="settings-card-title">账户信息</h2>
          <div className="user-info-section">
            <div className="user-info-item">
              <span className="user-info-label">用户ID:</span>
              <span className="user-info-value">{user?.id || '-'}</span>
            </div>
            <div className="user-info-item">
              <span className="user-info-label">邮箱:</span>
              <span className="user-info-value">{user?.email || '-'}</span>
            </div>
            <div className="user-info-item">
              <span className="user-info-label">用户名:</span>
              <span className="user-info-value">{user?.username || '-'}</span>
            </div>
            <div className="user-info-item">
              <span className="user-info-label">角色:</span>
              <span className="user-info-value">{user?.role === 'ADMIN' ? '管理员' : '普通用户'}</span>
            </div>
            <div className="user-info-item">
              <span className="user-info-label">状态:</span>
              <span className="user-info-value">{user?.status === 'ACTIVE' ? '活跃' : user?.status || '-'}</span>
            </div>
            <div className="user-info-item">
              <span className="user-info-label">创建时间:</span>
              <span className="user-info-value">{user?.createdAt ? new Date(user.createdAt).toLocaleString() : '-'}</span>
            </div>
          </div>
        </div>
        
        {/* 更新用户名表单 */}
        <div className="settings-card">
          <h2 className="settings-card-title">更新用户名</h2>
          <form onSubmit={handleUpdateUsername} className="settings-form">
            <div className="form-section">
              <label className="form-label">用户名</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="form-input"
                placeholder="输入新的用户名"
                disabled={isUsernameLoading}
              />
            </div>
            
            {usernameMessage && (
              <div className="success-message">
                {usernameMessage}
              </div>
            )}
            
            <div className="form-actions">
              <button 
                type="submit" 
                className="btn btn-primary"
                disabled={isUsernameLoading}
              >
                {isUsernameLoading ? '更新中...' : '更新用户名'}
              </button>
            </div>
          </form>
        </div>
        
        {/* 更新邮箱表单 */}
        <div className="settings-card">
          <h2 className="settings-card-title">更新邮箱</h2>
          <form onSubmit={handleUpdateEmail} className="settings-form">
            <div className="form-section">
              <label className="form-label">邮箱</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="form-input"
                placeholder="输入新的邮箱地址"
                disabled={isEmailLoading}
              />
            </div>
            
            {emailMessage && (
              <div className="success-message">
                {emailMessage}
              </div>
            )}
            
            <div className="form-actions">
              <button 
                type="submit" 
                className="btn btn-primary"
                disabled={isEmailLoading}
              >
                {isEmailLoading ? '更新中...' : '更新邮箱'}
              </button>
            </div>
          </form>
        </div>
        
        {/* 修改密码表单 */}
        <div className="settings-card">
          <h2 className="settings-card-title">修改密码</h2>
          <form onSubmit={handleUpdatePassword} className="settings-form">
            <div className="form-section">
              <label className="form-label">当前密码</label>
              <input
                type="password"
                value={passwordForm.currentPassword}
                onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}
                className="form-input"
                placeholder="输入当前密码"
                disabled={isPasswordLoading}
              />
            </div>
            
            <div className="form-section">
              <label className="form-label">新密码</label>
              <input
                type="password"
                value={passwordForm.newPassword}
                onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                className="form-input"
                placeholder="输入新密码"
                disabled={isPasswordLoading}
              />
            </div>
            
            <div className="form-section">
              <label className="form-label">确认新密码</label>
              <input
                type="password"
                value={passwordForm.confirmPassword}
                onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                className="form-input"
                placeholder="确认新密码"
                disabled={isPasswordLoading}
              />
            </div>
            
            {passwordError && (
              <div className="error-message">
                {passwordError}
              </div>
            )}
            
            {passwordMessage && (
              <div className="success-message">
                {passwordMessage}
              </div>
            )}
            
            <div className="form-actions">
              <button 
                type="submit" 
                className="btn btn-primary"
                disabled={isPasswordLoading}
              >
                {isPasswordLoading ? '修改中...' : '修改密码'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
