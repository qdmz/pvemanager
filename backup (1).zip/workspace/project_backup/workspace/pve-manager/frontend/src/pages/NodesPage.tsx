import { useState, useEffect } from 'react';
import { useNodeStore } from '../store/nodeStore';
import type { Node } from '../types';

const NodesPage = () => {
  const { 
    nodes, 
    isLoading, 
    error, 
    getNodes, 
    createNode, 
    updateNode, 
    deleteNode, 
    updateNodeStatus 
  } = useNodeStore();
  
  // 搜索和筛选
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  
  // 创建/编辑节点对话框
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentNodeId, setCurrentNodeId] = useState<string | null>(null);
  const [nodeFormData, setNodeFormData] = useState({
    name: '',
    host: '',
    port: 8006,
    username: '',
    password: '',
    description: ''
  });
  
  // 加载节点列表
  useEffect(() => {
    getNodes();
  }, [getNodes]);
  
  // 筛选节点
  const filteredNodes = nodes.filter(node => {
    const matchesSearch = node.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         node.host.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || node.status === statusFilter;
    return matchesSearch && matchesStatus;
  });
  
  // 获取状态文本
  const getStatusText = (status: string) => {
    switch (status) {
      case 'ACTIVE': return '已连接';
      case 'INACTIVE': return '未连接';
      case 'ERROR': return '错误';
      default: return '未知';
    }
  };
  
  // 打开创建节点对话框
  const handleOpenCreateDialog = () => {
    setIsEditMode(false);
    setCurrentNodeId(null);
    setNodeFormData({
      name: '',
      host: '',
      port: 8006,
      username: '',
      password: '',
      description: ''
    });
    setIsDialogOpen(true);
  };
  
  // 打开编辑节点对话框
  const handleOpenEditDialog = (node: Node) => {
    setIsEditMode(true);
    setCurrentNodeId(node.id);
    setNodeFormData({
      name: node.name,
      host: node.host,
      port: node.port,
      username: node.username,
      password: '', // 不显示现有密码
      description: node.description || ''
    });
    setIsDialogOpen(true);
  };
  
  // 提交节点表单
  const handleSubmitNode = async () => {
    if (isEditMode && currentNodeId) {
      await updateNode(currentNodeId, nodeFormData);
    } else {
      await createNode(nodeFormData);
    }
    setIsDialogOpen(false);
  };
  
  // 处理节点删除
  const handleDeleteNode = async (id: string) => {
    if (window.confirm('确定要删除此节点吗？')) {
      await deleteNode(id);
    }
  };
  
  // 处理节点状态切换
  const handleToggleNodeStatus = async (id: string, currentStatus: Node['status']) => {
    const newStatus = currentStatus === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    await updateNodeStatus(id, newStatus);
  };

  return (
    <div className="nodes-page">
      {/* 页面标题 */}
      <div className="page-header">
        <div>
          <h1 className="page-title">节点管理</h1>
          <p className="page-subtitle">管理所有PVE节点连接</p>
        </div>
        <button 
          className="btn btn-primary"
          onClick={handleOpenCreateDialog}
        >
          创建节点
        </button>
      </div>
      
      {/* 错误提示 */}
      {error && (
        <div className="error-message">
          {error}
        </div>
      )}
      
      {/* 搜索和筛选 */}
      <div className="search-filter-section">
        <div className="search-box">
          <input
            type="text"
            placeholder="搜索节点名称或主机..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
        
        <div className="filter-section">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">所有状态</option>
            <option value="ACTIVE">已连接</option>
            <option value="INACTIVE">未连接</option>
            <option value="ERROR">错误</option>
          </select>
        </div>
      </div>
      
      {/* 节点列表 */}
      <div className="nodes-list-section">
        {isLoading ? (
          <div className="loading">加载中...</div>
        ) : filteredNodes.length === 0 ? (
          <div className="empty-state">
            没有找到匹配的节点
          </div>
        ) : (
          <div className="nodes-table-container">
            <table className="nodes-table">
              <thead>
                <tr>
                  <th>节点</th>
                  <th>状态</th>
                  <th>连接信息</th>
                  <th>资源使用</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredNodes.map((node) => (
                  <tr key={node.id} className="node-row">
                    <td className="node-name">
                      <div className="node-name-info">
                        <span className="node-icon">🏢</span>
                        <div>
                          <div className="node-display-name">{node.name}</div>
                          <div className="node-description">{node.description || '-'}</div>
                        </div>
                      </div>
                    </td>
                    
                    <td className="node-status">
                      <div className="status-indicator">
                        <div className={`status-dot ${node.status}`}></div>
                        <span className="status-text">{getStatusText(node.status)}</span>
                      </div>
                    </td>
                    
                    <td className="node-connection">
                      <div className="connection-item">
                        <span className="connection-label">主机:</span>
                        <span className="connection-value">{node.host}:{node.port}</span>
                      </div>
                      <div className="connection-item">
                        <span className="connection-label">用户名:</span>
                        <span className="connection-value">{node.username}</span>
                      </div>
                      {node.apiVersion && (
                        <div className="connection-item">
                          <span className="connection-label">API版本:</span>
                          <span className="connection-value">{node.apiVersion}</span>
                        </div>
                      )}
                    </td>
                    
                    <td className="node-resources">
                      {node.cpuUsage !== undefined && node.memoryTotal ? (
                        <>
                          <div className="resource-item">
                            <span className="resource-label">CPU:</span>
                            <span className="resource-value">{node.cpuUsage.toFixed(1)}%</span>
                          </div>
                          <div className="resource-item">
                            <span className="resource-label">内存:</span>
                            <span className="resource-value">
                              {(node.memoryUsed || 0 / 1024 / 1024 / 1024).toFixed(1)} / {(node.memoryTotal / 1024 / 1024 / 1024).toFixed(1)} GB
                            </span>
                          </div>
                        </>
                      ) : (
                        <div className="resource-item">
                          <span className="resource-value">未连接</span>
                        </div>
                      )}
                    </td>
                    
                    <td className="node-actions">
                      <div className="action-buttons">
                        <button 
                          className="action-button status"
                          onClick={() => handleToggleNodeStatus(node.id, node.status)}
                          title={node.status === 'ACTIVE' ? '断开连接' : '连接'}
                        >
                          {node.status === 'ACTIVE' ? '🔌' : '🔗'}
                        </button>
                        <button 
                          className="action-button edit"
                          onClick={() => handleOpenEditDialog(node)}
                          title="编辑"
                        >
                          ✏️
                        </button>
                        <button 
                          className="action-button delete"
                          onClick={() => handleDeleteNode(node.id)}
                          title="删除"
                        >
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      
      {/* 创建/编辑节点对话框 */}
      {isDialogOpen && (
        <div className="dialog-overlay">
          <div className="dialog-content">
            <div className="dialog-header">
              <h2>{isEditMode ? '编辑节点' : '创建新节点'}</h2>
              <button 
                className="close-button"
                onClick={() => setIsDialogOpen(false)}
              >
                ×
              </button>
            </div>
            
            <div className="dialog-body">
              <div className="form-section">
                <label className="form-label">节点名称</label>
                <input
                  type="text"
                  value={nodeFormData.name}
                  onChange={(e) => setNodeFormData({ ...nodeFormData, name: e.target.value })}
                  className="form-input"
                  placeholder="输入节点名称"
                  required
                />
              </div>
              
              <div className="form-row">
                <div className="form-section half">
                  <label className="form-label">主机</label>
                  <input
                    type="text"
                    value={nodeFormData.host}
                    onChange={(e) => setNodeFormData({ ...nodeFormData, host: e.target.value })}
                    className="form-input"
                    placeholder="输入PVE主机地址"
                    required
                  />
                </div>
                
                <div className="form-section half">
                  <label className="form-label">端口</label>
                  <input
                    type="number"
                    value={nodeFormData.port}
                    onChange={(e) => setNodeFormData({ ...nodeFormData, port: parseInt(e.target.value) || 8006 })}
                    className="form-input"
                    min="1"
                    max="65535"
                    required
                  />
                </div>
              </div>
              
              <div className="form-section">
                <label className="form-label">用户名</label>
                <input
                  type="text"
                  value={nodeFormData.username}
                  onChange={(e) => setNodeFormData({ ...nodeFormData, username: e.target.value })}
                  className="form-input"
                  placeholder="输入PVE用户名"
                  required
                />
              </div>
              
              <div className="form-section">
                <label className="form-label">密码</label>
                <input
                  type="password"
                  value={nodeFormData.password}
                  onChange={(e) => setNodeFormData({ ...nodeFormData, password: e.target.value })}
                  className="form-input"
                  placeholder={isEditMode ? '留空表示不修改密码' : '输入PVE密码'}
                  required={!isEditMode}
                />
              </div>
              
              <div className="form-section">
                <label className="form-label">描述</label>
                <textarea
                  value={nodeFormData.description}
                  onChange={(e) => setNodeFormData({ ...nodeFormData, description: e.target.value })}
                  className="form-textarea"
                  placeholder="输入节点描述（可选）"
                  rows={3}
                />
              </div>
            </div>
            
            <div className="dialog-footer">
              <button 
            className="btn btn-secondary"
            onClick={() => setIsDialogOpen(false)}
          >
            取消
          </button>
          <button 
            className="btn btn-primary"
            onClick={handleSubmitNode}
            disabled={isLoading}
          >
            {isLoading ? '处理中...' : (isEditMode ? '更新节点' : '创建节点')}
          </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NodesPage;
