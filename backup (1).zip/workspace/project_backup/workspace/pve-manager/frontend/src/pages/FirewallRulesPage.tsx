import { useState, useEffect } from 'react';
import { useFirewallRulesStore } from '../store/firewallRulesStore';
import type { FirewallRule } from '../types';

const FirewallRulesPage = () => {
  const { 
    rules, 
    isLoading, 
    error, 
    getVMRules, 
    getAllRules, 
    createRule, 
    updateRule, 
    deleteRule, 
    toggleRuleStatus 
  } = useFirewallRulesStore();
  
  // 筛选和搜索
  const [vmFilter, setVmFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  
  // 创建/编辑规则对话框
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentRuleId, setCurrentRuleId] = useState<string | null>(null);
  const [ruleFormData, setRuleFormData] = useState({
    vmId: '',
    position: 1,
    action: 'ACCEPT' as const,
    protocol: 'TCP' as const,
    source: '',
    destination: '',
    dport: undefined,
    sport: undefined,
    comment: '',
    enabled: true
  });
  
  // 模拟虚拟机数据
  const vms = [
    { id: '1', name: 'web-01', vmid: 100 },
    { id: '2', name: 'db-01', vmid: 101 },
    { id: '3', name: 'app-01', vmid: 102 }
  ];
  
  // 加载规则列表
  useEffect(() => {
    getAllRules();
  }, [getAllRules]);
  
  // 根据选择的虚拟机筛选规则
  useEffect(() => {
    if (vmFilter !== 'all') {
      getVMRules(vmFilter);
    } else {
      getAllRules();
    }
  }, [vmFilter, getVMRules, getAllRules]);
  
  // 筛选规则
  const filteredRules = rules.filter(rule => {
    const matchesSearch = 
      (!rule.source || rule.source.includes(searchTerm)) ||
      (!rule.destination || rule.destination.includes(searchTerm)) ||
      (!rule.comment || rule.comment.includes(searchTerm));
    const matchesStatus = statusFilter === 'all' || 
      (statusFilter === 'enabled' && rule.enabled) ||
      (statusFilter === 'disabled' && !rule.enabled);
    return matchesSearch && matchesStatus;
  });
  
  // 打开创建规则对话框
  const handleOpenCreateDialog = () => {
    setIsEditMode(false);
    setCurrentRuleId(null);
    setRuleFormData({
      vmId: vmFilter !== 'all' ? vmFilter : '',
      position: filteredRules.length + 1,
      action: 'ACCEPT',
      protocol: 'TCP',
      source: '',
      destination: '',
      dport: undefined,
      sport: undefined,
      comment: '',
      enabled: true
    });
    setIsDialogOpen(true);
  };
  
  // 打开编辑规则对话框
  const handleOpenEditDialog = (rule: FirewallRule) => {
    setIsEditMode(true);
    setCurrentRuleId(rule.id);
    setRuleFormData({
      vmId: rule.vmId,
      position: rule.position,
      action: rule.action,
      protocol: rule.protocol,
      source: rule.source || '',
      destination: rule.destination || '',
      dport: rule.dport,
      sport: rule.sport,
      comment: rule.comment || '',
      enabled: rule.enabled
    });
    setIsDialogOpen(true);
  };
  
  // 提交规则表单
  const handleSubmitRule = async () => {
    if (isEditMode && currentRuleId) {
      await updateRule(currentRuleId, ruleFormData);
    } else {
      await createRule(ruleFormData);
    }
    setIsDialogOpen(false);
  };
  
  // 处理规则删除
  const handleDeleteRule = async (id: string) => {
    if (window.confirm('确定要删除此防火墙规则吗？')) {
      await deleteRule(id);
    }
  };
  
  // 处理规则状态切换
  const handleToggleRuleStatus = async (id: string) => {
    await toggleRuleStatus(id);
  };

  return (
    <div className="firewall-rules-page">
      {/* 页面标题 */}
      <div className="page-header">
        <div>
          <h1 className="page-title">防火墙规则管理</h1>
          <p className="page-subtitle">管理所有虚拟机的防火墙规则</p>
        </div>
        <button 
          className="create-rule-button"
          onClick={handleOpenCreateDialog}
        >
          创建规则
        </button>
      </div>
      
      {/* 错误提示 */}
      {error && (
        <div className="error-message">
          {error}
        </div>
      )}
      
      {/* 搜索和筛选 */}
      <div className="search-filter-section">
        <div className="search-box">
          <input
            type="text"
            placeholder="搜索源地址、目标地址或备注..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
        
        <div className="filter-section">
          <select
            value={vmFilter}
            onChange={(e) => setVmFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">所有虚拟机</option>
            {vms.map(vm => (
              <option key={vm.id} value={vm.id}>
                {vm.name} (VMID: {vm.vmid})
              </option>
            ))}
          </select>
          
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">所有状态</option>
            <option value="enabled">已启用</option>
            <option value="disabled">已禁用</option>
          </select>
        </div>
      </div>
      
      {/* 防火墙规则列表 */}
      <div className="rules-list-section">
        {isLoading ? (
          <div className="loading">加载中...</div>
        ) : filteredRules.length === 0 ? (
          <div className="empty-state">
            没有找到匹配的防火墙规则
          </div>
        ) : (
          <div className="rules-table-container">
            <table className="rules-table">
              <thead>
                <tr>
                  <th>位置</th>
                  <th>虚拟机</th>
                  <th>动作</th>
                  <th>协议</th>
                  <th>源地址</th>
                  <th>源端口</th>
                  <th>目标地址</th>
                  <th>目标端口</th>
                  <th>状态</th>
                  <th>备注</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredRules.map((rule) => {
                  const vm = vms.find(v => v.id === rule.vmId);
                  return (
                    <tr key={rule.id} className="rule-row">
                      <td className="rule-position">{rule.position}</td>
                      
                      <td className="rule-vm">
                        {vm ? `${vm.name} (${vm.vmid})` : rule.vmId}
                      </td>
                      
                      <td className="rule-action">
                        <span className={`action-badge ${rule.action.toLowerCase()}`}>
                          {rule.action}
                        </span>
                      </td>
                      
                      <td className="rule-protocol">
                        <span className="protocol-badge">{rule.protocol}</span>
                      </td>
                      
                      <td className="rule-source">{rule.source || '-'}</td>
                      <td className="rule-sport">{rule.sport || '-'}</td>
                      <td className="rule-destination">{rule.destination || '-'}</td>
                      <td className="rule-dport">{rule.dport || '-'}</td>
                      
                      <td className="rule-status">
                        <div className="status-indicator">
                          <div className={`status-dot ${rule.enabled ? 'enabled' : 'disabled'}`}></div>
                          <span className="status-text">{rule.enabled ? '已启用' : '已禁用'}</span>
                        </div>
                      </td>
                      
                      <td className="rule-comment">{rule.comment || '-'}</td>
                      
                      <td className="rule-actions">
                        <div className="action-buttons">
                          <button 
                            className="action-button toggle"
                            onClick={() => handleToggleRuleStatus(rule.id)}
                            title={rule.enabled ? '禁用' : '启用'}
                          >
                            {rule.enabled ? '🔴' : '🟢'}
                          </button>
                          <button 
                            className="action-button edit"
                            onClick={() => handleOpenEditDialog(rule)}
                            title="编辑"
                          >
                            ✏️
                          </button>
                          <button 
                            className="action-button delete"
                            onClick={() => handleDeleteRule(rule.id)}
                            title="删除"
                          >
                            🗑️
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
      
      {/* 创建/编辑规则对话框 */}
      {isDialogOpen && (
        <div className="dialog-overlay">
          <div className="dialog-content">
            <div className="dialog-header">
              <h2>{isEditMode ? '编辑防火墙规则' : '创建新防火墙规则'}</h2>
              <button 
                className="close-button"
                onClick={() => setIsDialogOpen(false)}
              >
                ×
              </button>
            </div>
            
            <div className="dialog-body">
              <div className="form-section">
                <label className="form-label">虚拟机</label>
                <select
                  value={ruleFormData.vmId}
                  onChange={(e) => setRuleFormData({ ...ruleFormData, vmId: e.target.value })}
                  className="form-select"
                  required
                >
                  <option value="">选择虚拟机</option>
                  {vms.map(vm => (
                    <option key={vm.id} value={vm.id}>
                      {vm.name} (VMID: {vm.vmid})
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="form-section">
                <label className="form-label">位置</label>
                <input
                  type="number"
                  value={ruleFormData.position}
                  onChange={(e) => setRuleFormData({ ...ruleFormData, position: parseInt(e.target.value) || 1 })}
                  className="form-input"
                  min="1"
                  required
                />
              </div>
              
              <div className="form-row">
                <div className="form-section half">
                  <label className="form-label">动作</label>
                  <select
                    value={ruleFormData.action}
                    onChange={(e) => setRuleFormData({ ...ruleFormData, action: e.target.value as FirewallRule['action'] })}
                    className="form-select"
                    required
                  >
                    <option value="ACCEPT">ACCEPT</option>
                    <option value="DROP">DROP</option>
                    <option value="REJECT">REJECT</option>
                  </select>
                </div>
                
                <div className="form-section half">
                  <label className="form-label">协议</label>
                  <select
                    value={ruleFormData.protocol}
                    onChange={(e) => setRuleFormData({ ...ruleFormData, protocol: e.target.value as FirewallRule['protocol'] })}
                    className="form-select"
                    required
                  >
                    <option value="TCP">TCP</option>
                    <option value="UDP">UDP</option>
                    <option value="ICMP">ICMP</option>
                    <option value="ANY">ANY</option>
                  </select>
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-section half">
                  <label className="form-label">源地址</label>
                  <input
                    type="text"
                    value={ruleFormData.source}
                    onChange={(e) => setRuleFormData({ ...ruleFormData, source: e.target.value })}
                    className="form-input"
                    placeholder="例如：192.168.1.0/24 或 ANY"
                  />
                </div>
                
                <div className="form-section half">
                  <label className="form-label">源端口</label>
                  <input
                    type="number"
                    value={ruleFormData.sport || ''}
                    onChange={(e) => setRuleFormData({ ...ruleFormData, sport: e.target.value ? parseInt(e.target.value) : undefined })}
                    className="form-input"
                    min="1"
                    max="65535"
                    placeholder="可选"
                  />
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-section half">
                  <label className="form-label">目标地址</label>
                  <input
                    type="text"
                    value={ruleFormData.destination}
                    onChange={(e) => setRuleFormData({ ...ruleFormData, destination: e.target.value })}
                    className="form-input"
                    placeholder="例如：192.168.1.100 或 ANY"
                  />
                </div>
                
                <div className="form-section half">
                  <label className="form-label">目标端口</label>
                  <input
                    type="number"
                    value={ruleFormData.dport || ''}
                    onChange={(e) => setRuleFormData({ ...ruleFormData, dport: e.target.value ? parseInt(e.target.value) : undefined })}
                    className="form-input"
                    min="1"
                    max="65535"
                    placeholder="可选"
                  />
                </div>
              </div>
              
              <div className="form-section">
                <label className="form-label">备注</label>
                <textarea
                  value={ruleFormData.comment}
                  onChange={(e) => setRuleFormData({ ...ruleFormData, comment: e.target.value })}
                  className="form-textarea"
                  placeholder="输入规则备注（可选）"
                  rows={3}
                />
              </div>
              
              <div className="form-section checkbox">
                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={ruleFormData.enabled}
                    onChange={(e) => setRuleFormData({ ...ruleFormData, enabled: e.target.checked })}
                  />
                  <span>启用规则</span>
                </label>
              </div>
            </div>
            
            <div className="dialog-footer">
              <button 
                className="cancel-button"
                onClick={() => setIsDialogOpen(false)}
              >
                取消
              </button>
              <button 
                className="create-button"
                onClick={handleSubmitRule}
                disabled={isLoading}
              >
                {isLoading ? '处理中...' : (isEditMode ? '更新规则' : '创建规则')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FirewallRulesPage;
