import { useState, useEffect } from 'react';
import { userService } from '../services/userService';
import type { User } from '../types';

const AdminPage = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // 搜索和筛选
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [roleFilter, setRoleFilter] = useState('all');
  
  // 创建/编辑用户对话框
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userFormData, setUserFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'USER' as 'ADMIN' | 'USER',
    status: 'ACTIVE' as 'ACTIVE' | 'INACTIVE' | 'PENDING',
    vmQuota: 5
  });
  
  // 批量操作
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  
  // 用户统计
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    inactive: 0,
    pending: 0,
    admins: 0,
    users: 0
  });
  
  // 加载用户列表
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setLoading(true);
        const response = await userService.getUsers();
        setUsers(response.users);
        
        // 获取用户统计
        const statsResponse = await userService.getUserStats();
        setStats(statsResponse);
        
        setError(null);
      } catch (err) {
        setError('Failed to fetch users');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchUsers();
  }, []);
  
  // 筛选用户
  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || user.status === statusFilter;
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    return matchesSearch && matchesStatus && matchesRole;
  });
  
  // 格式化日期
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };
  
  // 处理创建用户
  const handleCreateUser = async () => {
    try {
      setLoading(true);
      
      // 这里应该调用注册API，而不是用户管理API
      // 因为注册会处理密码哈希等
      // 暂时使用mock数据
      const newUser: User = {
        id: `user-${Date.now()}`,
        username: userFormData.username,
        email: userFormData.email,
        role: userFormData.role,
        status: userFormData.status,
        vmQuota: userFormData.vmQuota,
        vmCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        lastLoginAt: undefined,
        emailVerified: false
      };
      
      // 模拟API调用延迟
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setUsers([...users, newUser]);
      
      // 重置表单
      resetForm();
      setIsDialogOpen(false);
      setError(null);
    } catch (err) {
      setError('Failed to create user');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  // 处理更新用户
  const handleUpdateUser = async () => {
    try {
      setLoading(true);
      
      if (!currentUser) return;
      
      const updatedUser = await userService.updateUser(currentUser.id, userFormData);
      
      setUsers(users.map(user => 
        user.id === updatedUser.user.id ? updatedUser.user : user
      ));
      
      // 重置表单
      resetForm();
      setIsDialogOpen(false);
      setIsEditing(false);
      setCurrentUser(null);
      setError(null);
    } catch (err) {
      setError('Failed to update user');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  // 处理删除用户
  const handleDeleteUser = async (id: string) => {
    try {
      if (window.confirm('确定要删除此用户吗？')) {
        setLoading(true);
        await userService.deleteUser(id);
        
        setUsers(users.filter(user => user.id !== id));
        setError(null);
      }
    } catch (err) {
      setError('Failed to delete user');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  // 处理批量删除
  const handleBulkDelete = async () => {
    try {
      if (selectedUsers.length === 0) return;
      
      if (window.confirm(`确定要删除选中的 ${selectedUsers.length} 个用户吗？`)) {
        setLoading(true);
        
        // 批量删除用户
        for (const id of selectedUsers) {
          await userService.deleteUser(id);
        }
        
        setUsers(users.filter(user => !selectedUsers.includes(user.id)));
        setSelectedUsers([]);
        setError(null);
      }
    } catch (err) {
      setError('Failed to delete users');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  // 处理批量更新状态
  const handleBulkUpdateStatus = async (status: 'ACTIVE' | 'INACTIVE' | 'PENDING') => {
    try {
      if (selectedUsers.length === 0) return;
      
      setLoading(true);
      
      // 批量更新用户状态
      for (const id of selectedUsers) {
        await userService.updateUser(id, { status });
      }
      
      setUsers(users.map(user => 
        selectedUsers.includes(user.id) ? { ...user, status } : user
      ));
      setSelectedUsers([]);
      setError(null);
    } catch (err) {
      setError('Failed to update users');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  // 处理打开编辑对话框
  const handleEditUser = (user: User) => {
    setIsEditing(true);
    setCurrentUser(user);
    setUserFormData({
      username: user.username,
      email: user.email,
      password: '',
      confirmPassword: '',
      role: user.role,
      status: user.status,
      vmQuota: user.vmQuota
    });
    setIsDialogOpen(true);
  };
  
  // 处理打开创建对话框
  const handleOpenCreateDialog = () => {
    resetForm();
    setIsEditing(false);
    setCurrentUser(null);
    setIsDialogOpen(true);
  };
  
  // 重置表单
  const resetForm = () => {
    setUserFormData({
      username: '',
      email: '',
      password: '',
      confirmPassword: '',
      role: 'USER',
      status: 'ACTIVE',
      vmQuota: 5
    });
  };
  
  // 处理选择用户
  const handleSelectUser = (id: string) => {
    setSelectedUsers(prev => 
      prev.includes(id) 
        ? prev.filter(userId => userId !== id) 
        : [...prev, id]
    );
  };
  
  // 处理全选/取消全选
  const handleSelectAll = () => {
    if (selectedUsers.length === filteredUsers.length) {
      setSelectedUsers([]);
    } else {
      setSelectedUsers(filteredUsers.map(user => user.id));
    }
  };

  return (
    <div className="admin-page">
      {/* 页面标题 */}
      <div className="page-header">
        <div>
          <h1 className="page-title">用户管理</h1>
          <p className="page-subtitle">管理系统用户和权限</p>
        </div>
        <button 
          className="create-user-button"
          onClick={handleOpenCreateDialog}
          disabled={loading}
        >
          创建用户
        </button>
      </div>
      
      {/* 错误提示 */}
      {error && (
        <div className="error-message">
          {error}
        </div>
      )}
      
      {/* 用户统计 */}
      <div className="users-stats">
        <div className="stat-card">
          <div className="stat-header">
            <h3 className="stat-title">总用户数</h3>
            <div className="stat-icon">👥</div>
          </div>
          <div className="stat-value">{stats.total}</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-header">
            <h3 className="stat-title">活跃用户</h3>
            <div className="stat-icon">✅</div>
          </div>
          <div className="stat-value">{stats.active}</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-header">
            <h3 className="stat-title">管理员</h3>
            <div className="stat-icon">👑</div>
          </div>
          <div className="stat-value">{stats.admins}</div>
        </div>
        
        <div className="stat-card">
          <div className="stat-header">
            <h3 className="stat-title">普通用户</h3>
            <div className="stat-icon">👤</div>
          </div>
          <div className="stat-value">{stats.users}</div>
        </div>
      </div>
      
      {/* 搜索和筛选 */}
      <div className="search-filter-section">
        <div className="search-box">
          <input
            type="text"
            placeholder="搜索用户名或邮箱..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
        
        <div className="filter-section">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">所有状态</option>
            <option value="ACTIVE">活跃</option>
            <option value="INACTIVE">禁用</option>
            <option value="PENDING">待验证</option>
          </select>
          
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="filter-select"
          >
            <option value="all">所有角色</option>
            <option value="ADMIN">管理员</option>
            <option value="USER">普通用户</option>
          </select>
        </div>
      </div>
      
      {/* 批量操作 */}
      {selectedUsers.length > 0 && (
        <div className="bulk-actions">
          <div className="selected-count">
            已选择 {selectedUsers.length} 个用户
          </div>
          <div className="action-buttons">
            <button 
              className="action-button activate"
              onClick={() => handleBulkUpdateStatus('ACTIVE')}
              disabled={loading}
            >
              激活
            </button>
            <button 
              className="action-button deactivate"
              onClick={() => handleBulkUpdateStatus('INACTIVE')}
              disabled={loading}
            >
              禁用
            </button>
            <button 
              className="action-button delete"
              onClick={handleBulkDelete}
              disabled={loading}
            >
              删除
            </button>
          </div>
        </div>
      )}
      
      {/* 用户列表 */}
      <div className="users-list-section">
        {loading ? (
          <div className="loading">加载中...</div>
        ) : filteredUsers.length === 0 ? (
          <div className="empty-state">
            没有找到匹配的用户
          </div>
        ) : (
          <div className="users-table-container">
            <table className="users-table">
              <thead>
                <tr>
                  <th className="select-column">
                    <input
                      type="checkbox"
                      checked={selectedUsers.length === filteredUsers.length && filteredUsers.length > 0}
                      onChange={handleSelectAll}
                    />
                  </th>
                  <th>用户名</th>
                  <th>邮箱</th>
                  <th>角色</th>
                  <th>状态</th>
                  <th>VM配额</th>
                  <th>VM数量</th>
                  <th>创建时间</th>
                  <th>最后登录</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="user-row">
                    <td className="select-column">
                      <input
                        type="checkbox"
                        checked={selectedUsers.includes(user.id)}
                        onChange={() => handleSelectUser(user.id)}
                      />
                    </td>
                    
                    <td className="user-username">
                      <span className="username-text">{user.username}</span>
                    </td>
                    
                    <td className="user-email">
                      {user.email}
                    </td>
                    
                    <td className="user-role">
                      <span className={`role-badge ${user.role}`}>
                        {user.role === 'ADMIN' ? '管理员' : '普通用户'}
                      </span>
                    </td>
                    
                    <td className="user-status">
                      <span className={`status-badge ${user.status}`}>
                        {user.status === 'ACTIVE' ? '活跃' : user.status === 'INACTIVE' ? '禁用' : '待验证'}
                      </span>
                    </td>
                    
                    <td className="user-vm-quota">
                      {user.vmQuota}
                    </td>
                    
                    <td className="user-vm-count">
                      {user.vmCount}
                    </td>
                    
                    <td className="user-created">
                      {formatDate(user.createdAt)}
                    </td>
                    
                    <td className="user-last-login">
                      {user.lastLoginAt ? formatDate(user.lastLoginAt) : '从未登录'}
                    </td>
                    
                    <td className="user-actions">
                      <div className="action-buttons">
                        <button 
                          className="action-button edit"
                          onClick={() => handleEditUser(user)}
                          title="编辑"
                        >
                          ✏️
                        </button>
                        <button 
                          className="action-button delete"
                          onClick={() => handleDeleteUser(user.id)}
                          title="删除"
                        >
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      
      {/* 创建/编辑用户对话框 */}
      {isDialogOpen && (
        <div className="dialog-overlay">
          <div className="dialog-content">
            <div className="dialog-header">
              <h2>{isEditing ? '编辑用户' : '创建新用户'}</h2>
              <button 
                className="close-button"
                onClick={() => setIsDialogOpen(false)}
              >
                ×
              </button>
            </div>
            
            <div className="dialog-body">
              <div className="form-section">
                <label className="form-label">用户名</label>
                <input
                  type="text"
                  value={userFormData.username}
                  onChange={(e) => setUserFormData({ ...userFormData, username: e.target.value })}
                  className="form-input"
                  placeholder="输入用户名"
                />
              </div>
              
              <div className="form-section">
                <label className="form-label">邮箱</label>
                <input
                  type="email"
                  value={userFormData.email}
                  onChange={(e) => setUserFormData({ ...userFormData, email: e.target.value })}
                  className="form-input"
                  placeholder="输入邮箱"
                />
              </div>
              
              {!isEditing && (
                <>
                  <div className="form-section">
                    <label className="form-label">密码</label>
                    <input
                      type="password"
                      value={userFormData.password}
                      onChange={(e) => setUserFormData({ ...userFormData, password: e.target.value })}
                      className="form-input"
                      placeholder="输入密码"
                    />
                  </div>
                  
                  <div className="form-section">
                    <label className="form-label">确认密码</label>
                    <input
                      type="password"
                      value={userFormData.confirmPassword}
                      onChange={(e) => setUserFormData({ ...userFormData, confirmPassword: e.target.value })}
                      className="form-input"
                      placeholder="确认密码"
                    />
                  </div>
                </>
              )}
              
              <div className="form-section">
                <label className="form-label">角色</label>
                <select
                  value={userFormData.role}
                  onChange={(e) => setUserFormData({ ...userFormData, role: e.target.value as 'ADMIN' | 'USER' })}
                  className="form-select"
                >
                  <option value="ADMIN">管理员</option>
                  <option value="USER">普通用户</option>
                </select>
              </div>
              
              <div className="form-section">
                <label className="form-label">状态</label>
                <select
                  value={userFormData.status}
                  onChange={(e) => setUserFormData({ ...userFormData, status: e.target.value as 'ACTIVE' | 'INACTIVE' | 'PENDING' })}
                  className="form-select"
                >
                  <option value="ACTIVE">活跃</option>
                  <option value="INACTIVE">禁用</option>
                  <option value="PENDING">待验证</option>
                </select>
              </div>
              
              <div className="form-section">
                <label className="form-label">VM配额</label>
                <input
                  type="number"
                  value={userFormData.vmQuota}
                  onChange={(e) => setUserFormData({ ...userFormData, vmQuota: parseInt(e.target.value) || 0 })}
                  className="form-input"
                  min="0"
                  step="1"
                />
              </div>
            </div>
            
            <div className="dialog-footer">
              <button 
                className="cancel-button"
                onClick={() => setIsDialogOpen(false)}
              >
                取消
              </button>
              <button 
                className="save-button"
                onClick={isEditing ? handleUpdateUser : handleCreateUser}
                disabled={loading || !userFormData.username || !userFormData.email}
              >
                {loading ? '保存中...' : '保存'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPage;