# PVE虚拟机用户API管理系统

一个功能完善的Proxmox VE虚拟机管理系统，提供用户管理、虚拟机全生命周期管理、API凭证管理和操作日志审计等功能。

> **最新更新**: 已配置 Docker Hub 自动推送，镜像地址：qdmz/pve-manager-backend 和 qdmz/pve-manager-frontend

## ✨ 功能特性

### 🔐 用户认证与授权
- 用户注册与登录（JWT认证）
- 基于角色的访问控制（RBAC）
- 管理员/普通用户权限分离
- 个人设置管理

### 👥 用户管理
- 用户列表与管理（管理员）
- VM配额控制
- 用户状态管理
- 批量操作

### 🖥️ 虚拟机管理
- **生命周期管理**: 创建、启动、停止、重启、暂停、恢复、删除
- **配置管理**: CPU、内存、磁盘扩容
- **快照管理**: 创建、恢复、删除快照
- **备份管理**: 自动备份、备份恢复
- **网络管理**: 防火墙规则、端口转发
- **监控**: 实时资源使用监控

### 🔑 API密钥管理
- 创建自定义API密钥
- 细粒度权限控制
- 密钥有效期设置
- 使用统计与审计

### 📊 操作日志与审计
- 完整的操作记录
- 多维度日志筛选
- 审计追踪
- 日志导出

### 🖥️ 用户自助服务
- 个人仪表盘
- 名下虚拟机管理
- Web VNC/SSH终端访问
- 文件管理（SFTP）

## 🚀 快速开始

### 环境要求
- Docker 20.10+
- Docker Compose 2.0+
- Proxmox VE 7.0+

### 一键安装

```bash
# 克隆仓库
git clone https://github.com/yourusername/pve-management-system.git
cd pve-management-system

# 运行安装脚本
sudo ./install.sh
```

安装脚本会自动：
- 检查并安装必要的依赖（Docker、Docker Compose等）
- 配置环境变量
- 构建并启动所有服务
- 创建默认管理员账户

### 手动安装

#### 1. 配置环境变量
```bash
cp backend/.env.example .env
# 编辑 .env 文件，填入你的PVE连接信息
```

#### 2. 启动服务
```bash
docker-compose up -d
```

#### 3. 运行数据库迁移
```bash
docker-compose exec backend npx prisma migrate deploy
```

#### 4. 创建管理员用户
```bash
docker-compose exec backend node dist/scripts/createAdmin.js
```

## 🔧 配置说明

### 环境变量配置

编辑 `.env` 文件：

```env
# PVE连接信息
PVE_HOST=your-pve-host.com
PVE_USERNAME=root
PVE_PASSWORD=your-password
PVE_REALM=pam

# JWT密钥（随机生成）
JWT_SECRET=your-random-secret
JWT_REFRESH_SECRET=your-refresh-secret

# 默认VM配额
DEFAULT_VM_QUOTA=5

# 功能开关
ENABLE_REGISTRATION=true
ENABLE_EMAIL_VERIFICATION=false
```

### 网络配置

系统默认使用以下端口：
- 80: 前端Web界面
- 5000: 后端API服务
- 5432: PostgreSQL数据库
- 6379: Redis缓存
- 9090: Prometheus监控（可选）
- 3001: Grafana仪表板（可选）

## 📖 API文档

启动系统后，访问 http://localhost:5000/api-docs 查看完整的API文档（Swagger UI）。

### API端点概览

#### 认证相关
- `POST /api/auth/register` - 用户注册
- `POST /api/auth/login` - 用户登录
- `POST /api/auth/refresh` - 刷新访问令牌
- `GET /api/auth/profile` - 获取用户信息
- `PUT /api/auth/profile` - 更新用户信息

#### 虚拟机管理
- `GET /api/vms` - 获取虚拟机列表
- `POST /api/vms` - 创建虚拟机
- `GET /api/vms/:id` - 获取虚拟机详情
- `PUT /api/vms/:id` - 更新虚拟机
- `DELETE /api/vms/:id` - 删除虚拟机
- `POST /api/vms/:id/start` - 启动虚拟机
- `POST /api/vms/:id/stop` - 停止虚拟机
- `POST /api/vms/:id/restart` - 重启虚拟机

#### 快照管理
- `GET /api/vms/:id/snapshots` - 获取快照列表
- `POST /api/vms/:id/snapshots` - 创建快照
- `POST /api/vms/:id/snapshots/:name/rollback` - 恢复快照
- `DELETE /api/vms/:id/snapshots/:name` - 删除快照

#### 防火墙管理
- `GET /api/vms/:id/firewall/rules` - 获取防火墙规则
- `POST /api/vms/:id/firewall/rules` - 创建防火墙规则
- `PUT /api/vms/:id/firewall/rules/:pos` - 更新防火墙规则
- `DELETE /api/vms/:id/firewall/rules/:pos` - 删除防火墙规则

#### 端口转发
- `GET /api/vms/:id/port-forwards` - 获取端口转发列表
- `POST /api/vms/:id/port-forwards` - 创建端口转发
- `PUT /api/vms/:id/port-forwards/:id` - 更新端口转发
- `DELETE /api/vms/:id/port-forwards/:id` - 删除端口转发

#### API密钥管理
- `GET /api/api-keys` - 获取API密钥列表
- `POST /api/api-keys` - 创建API密钥
- `DELETE /api/api-keys/:id` - 撤销API密钥

#### 操作日志
- `GET /api/logs` - 获取操作日志
- `GET /api/logs/:id` - 获取日志详情

## 🔐 默认账户

安装完成后，系统会自动创建默认管理员账户：

- **用户名**: admin@example.com
- **密码**: admin123

**⚠️ 重要：首次登录后请立即修改默认密码！**

## 📁 项目结构

```
pve-management-system/
├── frontend/                 # React前端应用
│   ├── src/
│   │   ├── components/      # 可复用组件
│   │   ├── pages/           # 页面组件
│   │   ├── hooks/           # 自定义Hooks
│   │   ├── services/        # API服务
│   │   ├── store/           # 状态管理
│   │   └── utils/           # 工具函数
│   ├── public/
│   └── Dockerfile
│
├── backend/                 # Node.js后端API
│   ├── src/
│   │   ├── routes/          # API路由
│   │   ├── models/          # 数据模型
│   │   ├── middleware/      # 中间件
│   │   ├── services/        # 业务服务
│   │   └── utils/           # 工具函数
│   ├── prisma/              # 数据库Schema
│   └── Dockerfile
│
├── nginx/                   # Nginx配置
│   ├── nginx.conf
│   └── ssl/
│
├── monitoring/              # 监控配置
│   ├── prometheus.yml
│   └── grafana/
│
├── docker-compose.yml       # Docker编排
├── install.sh              # 安装脚本
└── README.md               # 本文档
```

## 🔒 安全特性

- **密码安全**: bcrypt加密存储
- **JWT认证**: 无状态认证，支持令牌刷新
- **CSRF保护**: 防止跨站请求伪造
- **输入验证**: 严格的输入验证和过滤
- **SQL注入防护**: 使用ORM参数化查询
- **XSS防护**: 内容安全策略(CSP)
- **速率限制**: API调用频率限制
- **审计日志**: 所有敏感操作记录

## 📊 监控与日志

### 监控指标
- CPU使用率
- 内存使用率
- 磁盘使用率
- 网络流量
- API响应时间
- 错误率

### 日志类型
- 应用日志
- 访问日志
- 错误日志
- 审计日志

## 🛠️ 开发指南

### 本地开发

#### 后端开发
```bash
cd backend
npm install
npm run dev
```

#### 前端开发
```bash
cd frontend
npm install
npm run dev
```

### 数据库迁移
```bash
# 创建迁移
docker-compose exec backend npx prisma migrate dev

# 应用迁移
docker-compose exec backend npx prisma migrate deploy

# 生成客户端
docker-compose exec backend npx prisma generate
```

### 备份与恢复

#### 数据库备份
```bash
# 创建数据库备份
docker-compose exec postgres pg_dump -U postgres pvemanager > backup.sql

# 恢复数据库备份
docker-compose exec -T postgres psql -U postgres pvemanager < backup.sql
```

#### 完整系统备份
```bash
# 停止服务
docker-compose down

# 备份数据卷
docker run --rm -v pvemanager_postgres_data:/data -v $(pwd):/backup alpine tar czf /backup/postgres_backup.tar.gz /data

# 重启服务
docker-compose up -d
```

## 🐛 故障排除

### 常见问题

#### 1. 无法连接到PVE
- 检查PVE主机地址和凭据是否正确
- 确保PVE API服务正在运行
- 检查防火墙设置

#### 2. 数据库连接失败
- 检查PostgreSQL服务是否运行
- 验证数据库连接字符串
- 检查网络连接

#### 3. 前端无法加载
- 检查Nginx服务是否运行
- 验证前端构建是否成功
- 检查端口是否被占用

#### 4. 认证失败
- 检查JWT密钥配置
- 验证用户凭据
- 检查令牌是否过期

### 日志查看
```bash
# 查看所有服务日志
docker-compose logs

# 查看特定服务日志
docker-compose logs backend
docker-compose logs frontend
docker-compose logs postgres

# 实时跟踪日志
docker-compose logs -f backend
```

## 🤝 贡献指南

1. Fork 项目
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

## 📜 许可证

本项目采用 MIT 许可证 - 详见 [LICENSE](LICENSE) 文件。

## 🙏 致谢

- [Proxmox VE](https://www.proxmox.com/) - 强大的开源虚拟化平台
- [React](https://reactjs.org/) - 前端框架
- [Node.js](https://nodejs.org/) - 后端运行时
- [Prisma](https://www.prisma.io/) - 现代数据库工具
- [Docker](https://www.docker.com/) - 容器化平台

## 📞 支持

如有问题或建议，请通过以下方式联系：
- 提交 Issue: [GitHub Issues](https://github.com/yourusername/pve-management-system/issues)
- 发送邮件: support@yourdomain.com

---

**注意**: 这是一个功能完整的PVE管理系统设计方案和代码实现。实际部署前，请根据你的具体需求进行配置调整。
