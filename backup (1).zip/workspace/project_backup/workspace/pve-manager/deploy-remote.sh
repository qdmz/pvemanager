#!/bin/bash

# PVE管理系统远程部署脚本
# 在远程服务器上执行此脚本

set -e

echo "========================================="
echo "  PVE管理系统远程部署脚本"
echo "========================================="

# 检查是否为root用户
if [ "$EUID" -ne 0 ]; then 
    echo "请使用root用户执行此脚本"
    exit 1
fi

# 更新系统
echo "正在更新系统..."
apt update && apt upgrade -y

# 安装必要工具
echo "正在安装必要工具..."
apt install -y curl git nginx ufw

# 安装Node.js 20.x
echo "正在安装Node.js..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt install -y nodejs
else
    echo "Node.js已安装: $(node -v)"
fi

# 安装PM2
echo "正在安装PM2..."
npm install -g pm2

# 创建项目目录
PROJECT_DIR="/root/pve-manager"
echo "正在创建项目目录: $PROJECT_DIR"
mkdir -p $PROJECT_DIR

# 复制项目文件（假设项目文件已上传到服务器）
echo "请确保项目文件已上传到 $PROJECT_DIR"
echo "如果未上传，请先上传项目文件到服务器"

# 进入项目目录
cd $PROJECT_DIR

# 安装后端依赖
echo "正在安装后端依赖..."
cd backend
npm install

# 运行数据库迁移
echo "正在运行数据库迁移..."
npx prisma migrate deploy

# 启动后端服务
echo "正在启动后端服务..."
pm2 start npm --name "pve-backend" -- start
pm2 save
pm2 startup

# 构建前端
echo "正在构建前端..."
cd ../frontend
npm install
npm run build

# 配置Nginx
echo "正在配置Nginx..."
cat > /etc/nginx/sites-available/pve-manager << 'EOF'
server {
    listen 80;
    server_name _;

    # 前端静态文件
    location / {
        root /root/pve-manager/frontend/dist;
        try_files $uri $uri/ /index.html;
    }

    # 后端API代理
    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # WebSocket支持
    location /socket.io {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
EOF

# 启用Nginx配置
ln -sf /etc/nginx/sites-available/pve-manager /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

# 配置防火墙
echo "正在配置防火墙..."
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

# 设置开机自启
systemctl enable nginx
systemctl enable pm2-root

echo "========================================="
echo "  部署完成！"
echo "========================================="
echo "访问地址: http://154.9.237.203"
echo "默认账号: admin@example.com"
echo "默认密码: admin123"
echo ""
echo "后端服务状态:"
pm2 status
echo ""
echo "Nginx状态:"
systemctl status nginx --no-pager
echo ""
echo "⚠️  请立即修改默认密码！"
echo "========================================="
