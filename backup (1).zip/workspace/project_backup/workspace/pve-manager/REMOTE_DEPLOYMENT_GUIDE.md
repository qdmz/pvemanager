# PVE管理系统远程部署指南

## 服务器信息
- IP地址: 154.9.237.203
- 用户: root
- 密码: thanks123A#

## 部署步骤

### 方法一：使用部署脚本（推荐）

1. **上传项目到远程服务器**

在本地机器执行：
```bash
# 压缩项目文件
cd /home/admin/workspace
tar -czf pve-manager.tar.gz pve-manager/

# 上传到远程服务器
scp pve-manager.tar.gz root@154.9.237.203:/root/
```

2. **SSH登录到远程服务器**
```bash
ssh root@154.9.237.203
# 输入密码: thanks123A#
```

3. **解压项目文件**
```bash
cd /root
tar -xzf pve-manager.tar.gz
cd pve-manager
```

4. **执行部署脚本**
```bash
chmod +x deploy-remote.sh
./deploy-remote.sh
```

### 方法二：手动部署

1. **SSH登录到远程服务器**
```bash
ssh root@154.9.237.203
# 输入密码: thanks123A#
```

2. **更新系统并安装必要工具**
```bash
apt update && apt upgrade -y
apt install -y curl git nginx ufw
```

3. **安装Node.js 20.x**
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs
```

4. **安装PM2**
```bash
npm install -g pm2
```

5. **上传项目文件**
```bash
# 在本地机器执行
cd /home/admin/workspace
scp -r pve-manager root@154.9.237.203:/root/
```

6. **在远程服务器安装后端依赖**
```bash
cd /root/pve-manager/backend
npm install
```

7. **运行数据库迁移**
```bash
npx prisma migrate deploy
```

8. **启动后端服务**
```bash
pm2 start npm --name "pve-backend" -- start
pm2 save
pm2 startup
```

9. **构建前端**
```bash
cd /root/pve-manager/frontend
npm install
npm run build
```

10. **配置Nginx**
```bash
cat > /etc/nginx/sites-available/pve-manager << 'EOF'
server {
    listen 80;
    server_name _;

    location / {
        root /root/pve-manager/frontend/dist;
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    location /socket.io {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
EOF

ln -sf /etc/nginx/sites-available/pve-manager /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
```

11. **配置防火墙**
```bash
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable
```

12. **设置开机自启**
```bash
systemctl enable nginx
systemctl enable pm2-root
```

## 验证部署

1. **检查后端服务**
```bash
pm2 status
```

2. **检查Nginx服务**
```bash
systemctl status nginx
```

3. **访问系统**
- 访问地址: http://154.9.237.203
- 默认账号: admin@example.com
- 默认密码: admin123

## 常用命令

### 查看后端日志
```bash
pm2 logs pve-backend
```

### 重启后端服务
```bash
pm2 restart pve-backend
```

### 查看Nginx日志
```bash
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

### 重启Nginx
```bash
systemctl restart nginx
```

## 注意事项

1. ⚠️ 部署完成后请立即修改默认密码
2. 确保服务器防火墙已开放80和443端口
3. 建议配置SSL证书（使用Let's Encrypt）
4. 定期备份数据库文件
5. 监控服务器资源使用情况

## 故障排查

### 后端服务无法启动
```bash
pm2 logs pve-backend
```

### Nginx配置错误
```bash
nginx -t
```

### 端口被占用
```bash
netstat -tlnp | grep 5000
netstat -tlnp | grep 80
```

### 数据库连接失败
```bash
cd /root/pve-manager/backend
npx prisma migrate deploy
```
