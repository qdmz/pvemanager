# PVE虚拟机用户API管理系统 - 完整设计方案

## 项目概述

一个功能完善的Proxmox VE虚拟机管理系统，提供用户管理、虚拟机全生命周期管理、API凭证管理和操作日志审计等功能。

## 技术栈

### 前端
- **框架**: React 18 + TypeScript
- **构建工具**: Vite
- **UI组件库**: shadcn/ui + Radix UI
- **样式**: Tailwind CSS
- **状态管理**: Zustand
- **路由**: React Router
- **图表**: Recharts
- **表单**: React Hook Form + Zod

### 后端
- **框架**: Node.js + Express + TypeScript
- **数据库**: PostgreSQL + Prisma ORM
- **认证**: JWT + bcrypt
- **WebSocket**: Socket.io (用于终端/VNC)
- **API文档**: Swagger/OpenAPI

### 基础设施
- **容器化**: Docker + Docker Compose
- **反向代理**: Nginx
- **监控**: Prometheus + Grafana

## 核心功能模块

### 1. 用户认证与授权系统

#### 功能特性
- **用户注册**: 邮箱验证、密码强度检查
- **用户登录**: JWT令牌、刷新令牌机制
- **权限控制**: 基于角色的访问控制(RBAC)
  - 管理员: 完全访问权限
  - 普通用户: 仅限自有资源
- **个人设置**: 修改密码、个人资料、API密钥管理

#### 数据库模型
```typescript
interface User {
  id: string;
  email: string;
  username: string;
  password: string; // bcrypt加密
  role: 'admin' | 'user';
  status: 'active' | 'inactive' | 'pending';
  vmQuota: number;
  createdAt: Date;
  updatedAt: Date;
  lastLoginAt: Date;
  emailVerified: boolean;
}
```

### 2. 管理员设置面板

#### 系统配置
- **PVE节点管理**: 添加/删除/监控PVE节点
- **系统设置**: 邮件配置、存储配置、网络配置
- **配额管理**: 设置用户默认VM配额
- **审计日志**: 查看所有用户操作记录

#### 用户管理
- **用户列表**: 搜索、筛选、排序
- **用户详情**: 查看用户VM、API密钥、操作日志
- **用户操作**: 启用/禁用、重置密码、修改配额
- **批量操作**: 批量导入/导出用户

### 3. 虚拟机完整管理

#### VM生命周期管理
- **创建虚拟机**:
  - 选择节点和存储
  - 配置CPU、内存、磁盘
  - 选择操作系统模板或ISO
  - 网络配置（桥接、NAT）
  - 云初始化配置
- **VM操作**:
  - 启动/停止/重启/暂停/恢复
  - 克隆/迁移/删除
  - 快照管理（创建/恢复/删除）
  - 备份管理

#### VM配置修改
- **硬件配置**:
  - CPU核心数、内存大小调整
  - 磁盘扩容/添加新磁盘
  - 网络接口添加/修改
  - PCI设备直通
- **系统配置**:
  - 主机名修改
  - 启动顺序调整
  - BIOS/UEFI设置

#### 网络管理
- **防火墙规则**:
  - 安全组管理
  - IP/端口访问控制
  - ICMP/TCP/UDP规则
- **端口转发**:
  - NAT端口映射
  - 负载均衡配置
- **IP管理**:
  - IP分配/释放
  - MAC地址绑定

#### 监控与统计
- **实时状态**: CPU、内存、磁盘、网络使用率
- **历史数据**: 资源使用趋势图
- **告警设置**: 资源阈值告警

### 4. 用户自助管理

#### 个人仪表盘
- **资源概览**: VM数量、资源使用情况
- **快捷操作**: 常用VM快速访问
- **最近活动**: 最近操作记录

#### 我的虚拟机
- **VM列表**: 名下所有虚拟机
- **VM详情**: 配置信息、监控数据、快照列表
- **VM操作**: 启动/停止/重启等基本操作
- **终端访问**:
  - Web-based VNC客户端
  - WebSSH终端
  - NoVNC集成
- **文件管理**:
  - SFTP文件上传/下载
  - 文件浏览器

#### API密钥管理
- **创建API密钥**: 自定义名称、权限范围、有效期
- **密钥列表**: 查看、撤销、删除
- **使用统计**: API调用次数、最后使用时间

### 5. API接口系统

#### RESTful API
```
# 用户认证
POST   /api/auth/register
POST   /api/auth/login
POST   /api/auth/logout
POST   /api/auth/refresh
GET    /api/auth/profile
PUT    /api/auth/profile

# 用户管理 (Admin)
GET    /api/users
POST   /api/users
GET    /api/users/:id
PUT    /api/users/:id
DELETE /api/users/:id

# 虚拟机管理
GET    /api/vms
POST   /api/vms
GET    /api/vms/:id
PUT    /api/vms/:id
DELETE /api/vms/:id
POST   /api/vms/:id/start
POST   /api/vms/:id/stop
POST   /api/vms/:id/restart
POST   /api/vms/:id/suspend
POST   /api/vms/:id/resume
POST   /api/vms/:id/snapshot
POST   /api/vms/:id/backup

# VM配置
PUT    /api/vms/:id/config/cpu
PUT    /api/vms/:id/config/memory
PUT    /api/vms/:id/config/disk
POST   /api/vms/:id/config/network

# 防火墙管理
GET    /api/vms/:id/firewall/rules
POST   /api/vms/:id/firewall/rules
PUT    /api/vms/:id/firewall/rules/:ruleId
DELETE /api/vms/:id/firewall/rules/:ruleId

# 端口转发
GET    /api/vms/:id/port-forward
POST   /api/vms/:id/port-forward
PUT    /api/vms/:id/port-forward/:id
DELETE /api/vms/:id/port-forward/:id

# API密钥管理
GET    /api/api-keys
POST   /api/api-keys
DELETE /api/api-keys/:id

# 操作日志
GET    /api/logs
GET    /api/logs/:id

# 系统管理 (Admin)
GET    /api/admin/nodes
POST   /api/admin/nodes
GET    /api/admin/settings
PUT    /api/admin/settings
GET    /api/admin/stats
```

#### WebSocket接口
```
# VNC连接
/ws/vnc/:vmId

# SSH终端
/ws/ssh/:vmId

# 实时监控
/ws/monitor/:vmId
```

### 6. 操作日志与审计

#### 日志记录
- **操作类型**: 创建、修改、删除、登录等
- **操作对象**: 用户、VM、API密钥等
- **操作结果**: 成功/失败，错误信息
- **上下文**: IP地址、用户代理、操作时间

#### 审计功能
- **日志查询**: 多维度筛选（时间、用户、操作类型）
- **日志导出**: CSV/PDF格式导出
- **合规性**: 支持审计追踪和数据保留策略

## 界面设计

### 整体布局
- **侧边栏导航**: 可折叠，图标+文字
- **顶部栏**: 搜索、通知、用户菜单
- **面包屑**: 当前位置导航
- **响应式设计**: 适配桌面、平板、手机

### 页面设计

#### 登录/注册页面
- 现代化登录表单
- 支持邮箱/用户名登录
- 忘记密码功能
- 注册表单（邮箱验证）

#### 仪表盘
- 统计卡片（用户数、VM数、节点状态）
- 图表（资源使用趋势）
- 最近活动列表
- 快捷操作入口

#### 用户管理
- 数据表格（搜索、筛选、分页）
- 用户详情抽屉
- 批量操作工具栏

#### 虚拟机管理
- VM列表（状态图标、快速操作）
- VM详情标签页（概览、配置、监控、快照、备份）
- 创建VM向导（多步骤表单）
- 终端/VNC弹窗

#### 设置页面
- 标签页布局（个人设置、系统设置、安全设置）
- 表单验证和错误提示

## 部署方案

### Docker Compose部署
```yaml
version: '3.8'
services:
  frontend:
    build: ./frontend
    ports:
      - "3000:80"
    depends_on:
      - backend
    environment:
      - REACT_APP_API_URL=http://localhost:5000

  backend:
    build: ./backend
    ports:
      - "5000:5000"
    depends_on:
      - postgres
      - redis
    environment:
      - DATABASE_URL=postgresql://user:password@postgres:5432/pvemanager
      - REDIS_URL=redis://redis:6379
      - JWT_SECRET=your-jwt-secret

  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: pvemanager
      POSTGRES_USER: user
      POSTGRES_PASSWORD: password
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - frontend
      - backend

volumes:
  postgres_data:
```

### 安装脚本
```bash
#!/bin/bash
# install.sh

echo "开始安装PVE管理系统..."

# 检查Docker和Docker Compose
if ! command -v docker &> /dev/null; then
    echo "请先安装Docker"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "请先安装Docker Compose"
    exit 1
fi

# 创建配置文件
cp .env.example .env
echo "请编辑 .env 文件配置环境变量"

# 构建镜像
docker-compose build

# 启动服务
docker-compose up -d

# 数据库迁移
docker-compose exec backend npx prisma migrate dev

# 创建管理员用户
echo "创建管理员用户..."
docker-compose exec backend node scripts/create-admin.js

echo "安装完成！"
echo "访问地址: http://localhost"
echo "管理员账号: admin@example.com"
echo "默认密码: admin123"
```

## 开发计划

### 第一阶段（基础功能）
1. ✅ 项目初始化和基础架构
2. ✅ 用户认证系统（注册、登录、JWT）
3. ✅ 基础用户管理（增删改查）
4. ✅ 仪表盘和导航

### 第二阶段（虚拟机管理）
5. ⚠️ VM列表和基本操作（启动/停止）
6. ⚠️ VM创建向导
7. ⚠️ VM配置修改
8. ⚠️ 快照和备份管理

### 第三阶段（高级功能）
9. ⏳ 防火墙规则管理
10. ⏳ 端口转发配置
11. ⏳ Web终端/VNC集成
12. ⏳ API密钥管理

### 第四阶段（优化和部署）
13. ⏳ 性能优化
14. ⏳ 测试和文档
15. ⏳ Docker部署
16. ⏳ CI/CD集成

## 技术亮点

1. **现代化技术栈**: React 18 + TypeScript + Tailwind CSS
2. **组件化设计**: 可复用的UI组件库
3. **类型安全**: 全栈TypeScript，编译时错误检查
4. **响应式设计**: 移动优先，适配各种设备
5. **实时通信**: WebSocket实现实时终端和监控
6. **容器化部署**: Docker Compose一键部署
7. **API文档**: Swagger自动生成API文档
8. **权限控制**: 细粒度的RBAC权限系统
9. **审计日志**: 完整的操作记录和审计功能
10. **高可用性**: 支持多PVE节点管理

## 安全特性

1. **密码安全**: bcrypt加密存储
2. **JWT认证**: 无状态认证，支持令牌刷新
3. **CSRF保护**: 防止跨站请求伪造
4. **输入验证**: 严格的输入验证和过滤
5. **SQL注入防护**: 使用ORM参数化查询
6. **XSS防护**: 内容安全策略(CSP)
7. **速率限制**: API调用频率限制
8. **审计日志**: 所有敏感操作记录

## 性能优化

1. **代码分割**: 按需加载，减小初始包大小
2. **虚拟滚动**: 大数据列表优化
3. **缓存策略**: Redis缓存热点数据
4. **数据库优化**: 索引优化、查询优化
5. **CDN加速**: 静态资源CDN分发
6. **图片优化**: 懒加载、WebP格式
7. **请求合并**: GraphQL或批量API请求
8. **压缩传输**: Gzip/Brotli压缩

## 扩展性考虑

1. **插件系统**: 支持第三方插件扩展
2. **多租户**: 支持多组织/团队隔离
3. **多语言**: i18n国际化支持
4. **主题系统**: 支持自定义主题
5. **API版本控制**: 向后兼容的API设计
6. **微服务**: 可拆分为独立服务
7. **数据库分片**: 支持水平扩展
8. **消息队列**: 异步任务处理

---

这个设计方案涵盖了PVE管理系统的所有核心功能，可以作为开发的详细指导文档。实际开发时可以根据需求优先级分阶段实现。
