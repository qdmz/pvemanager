#!/bin/bash

# PVE Management System Installation Script
# This script installs the complete PVE management system

set -e

echo "=========================================="
echo "PVE Management System Installation"
echo "=========================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo -e "ℹ $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root"
        exit 1
    fi
}

# Check system requirements
check_requirements() {
    print_info "Checking system requirements..."
    
    # Check OS
    if [[ ! -f /etc/debian_version ]]; then
        print_error "This script only supports Debian/Ubuntu systems"
        exit 1
    fi
    
    # Check if Docker is installed
    if ! command -v docker &> /dev/null; then
        print_info "Docker not found. Installing Docker..."
        curl -fsSL https://get.docker.com | sh
        systemctl enable docker
        systemctl start docker
        print_success "Docker installed"
    else
        print_success "Docker is already installed"
    fi
    
    # Check if Docker Compose is installed
    if ! command -v docker-compose &> /dev/null; then
        print_info "Docker Compose not found. Installing Docker Compose..."
        curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
        chmod +x /usr/local/bin/docker-compose
        print_success "Docker Compose installed"
    else
        print_success "Docker Compose is already installed"
    fi
    
    # Check if Git is installed
    if ! command -v git &> /dev/null; then
        print_info "Installing Git..."
        apt-get update && apt-get install -y git
        print_success "Git installed"
    else
        print_success "Git is already installed"
    fi
}

# Get user input for configuration
get_user_input() {
    print_info "Configuring PVE Management System..."
    
    # Check if .env file exists
    if [[ -f .env ]]; then
        print_warning ".env file already exists. Do you want to overwrite it? (y/N)"
        read -r overwrite
        if [[ ! $overwrite =~ ^[Yy]$ ]]; then
            print_info "Using existing .env file"
            return
        fi
    fi
    
    # Get PVE connection details
    echo "Enter your Proxmox VE details:"
    read -p "PVE Host (e.g., pve.example.com or IP): " PVE_HOST
    read -p "PVE Username (default: root): " PVE_USERNAME
    PVE_USERNAME=${PVE_USERNAME:-root}
    read -s -p "PVE Password: " PVE_PASSWORD
    echo
    read -p "PVE Realm (default: pam): " PVE_REALM
    PVE_REALM=${PVE_REALM:-pam}
    
    # Get JWT secrets
    JWT_SECRET=$(openssl rand -base64 32)
    JWT_REFRESH_SECRET=$(openssl rand -base64 32)
    
    # Create .env file
    cat > .env << EOF
# Database
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/pvemanager"

# Server
PORT=5000
NODE_ENV=production
FRONTEND_URL=http://localhost:3000

# JWT Secrets
JWT_SECRET=$JWT_SECRET
JWT_REFRESH_SECRET=$JWT_REFRESH_SECRET
JWT_EXPIRES_IN=15m
JWT_REFRESH_EXPIRES_IN=7d

# PVE Configuration
PVE_HOST=$PVE_HOST
PVE_USERNAME=$PVE_USERNAME
PVE_PASSWORD=$PVE_PASSWORD
PVE_REALM=$PVE_REALM

# Default Settings
DEFAULT_VM_QUOTA=5
DEFAULT_STORAGE=local
DEFAULT_BRIDGE=vmbr0

# Email Configuration (optional)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=
SMTP_PASS=
FROM_EMAIL=noreply@yourdomain.com

# Redis
REDIS_URL=redis://localhost:6379

# Features
ENABLE_REGISTRATION=true
ENABLE_EMAIL_VERIFICATION=false
ENABLE_TWO_FACTOR_AUTH=false
EOF
    
    print_success ".env file created"
}

# Create necessary directories
create_directories() {
    print_info "Creating necessary directories..."
    
    mkdir -p backend/logs
    mkdir -p backend/uploads
    mkdir -p nginx/logs
    mkdir -p nginx/ssl
    mkdir -p monitoring/grafana/provisioning
    mkdir -p monitoring/prometheus
    
    print_success "Directories created"
}

# Build and start services
start_services() {
    print_info "Building and starting services..."
    
    # Pull latest images
    docker-compose pull
    
    # Build services
    docker-compose build
    
    # Start services
    docker-compose up -d
    
    # Wait for services to be ready
    print_info "Waiting for services to be ready..."
    sleep 30
    
    # Run database migrations
    print_info "Running database migrations..."
    docker-compose exec backend npx prisma migrate deploy
    
    # Create admin user
    print_info "Creating admin user..."
    docker-compose exec backend node dist/scripts/createAdmin.js
    
    print_success "Services started successfully"
}

# Show status
show_status() {
    print_info "Checking service status..."
    docker-compose ps
    
    echo
    print_success "PVE Management System is now running!"
    echo
    print_info "Access URLs:"
    echo "  - Frontend: http://localhost"
    echo "  - Backend API: http://localhost:5000"
    echo "  - API Documentation: http://localhost:5000/api-docs"
    echo "  - Monitoring (if enabled): http://localhost:3001"
    echo
    print_info "Default Admin Account:"
    echo "  - Email: admin@example.com"
    echo "  - Password: admin123"
    echo
    print_warning "Please change the default admin password immediately!"
}

# Main execution
main() {
    echo "Starting installation..."
    
    check_root
    check_requirements
    get_user_input
    create_directories
    start_services
    show_status
    
    print_success "Installation completed successfully!"
}

# Run main function
main "$@"
